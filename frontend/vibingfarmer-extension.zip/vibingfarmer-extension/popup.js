import{v as Xr,W as ty,Q as ry,w as gr,K as Jh,p as ep,_ as ny,H as tp,S as na,N as rp,l as iy,F as mu,O as oy,a as Ic,a5 as ay,Z as ly,y as sy,x as uy,a3 as fy,n as Dc,E as cy,u as dy}from"./assets/client-DEGlo4hs.js";import{H as hy}from"./assets/server-DlJZkW5s.js";import{j as np,B as ip,M as py}from"./assets/transaction_builder-m1Pp7Fbz.js";var op={exports:{}},bl={},ap={exports:{}},Fe={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Do=Symbol.for("react.element"),vy=Symbol.for("react.portal"),yy=Symbol.for("react.fragment"),gy=Symbol.for("react.strict_mode"),my=Symbol.for("react.profiler"),xy=Symbol.for("react.provider"),by=Symbol.for("react.context"),wy=Symbol.for("react.forward_ref"),_y=Symbol.for("react.suspense"),ky=Symbol.for("react.memo"),Sy=Symbol.for("react.lazy"),Uc=Symbol.iterator;function Ey(e){return e===null||typeof e!="object"?null:(e=Uc&&e[Uc]||e["@@iterator"],typeof e=="function"?e:null)}var lp={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},sp=Object.assign,up={};function Ti(e,t,r){this.props=e,this.context=t,this.refs=up,this.updater=r||lp}Ti.prototype.isReactComponent={};Ti.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};Ti.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function fp(){}fp.prototype=Ti.prototype;function Cf(e,t,r){this.props=e,this.context=t,this.refs=up,this.updater=r||lp}var Af=Cf.prototype=new fp;Af.constructor=Cf;sp(Af,Ti.prototype);Af.isPureReactComponent=!0;var Fc=Array.isArray,cp=Object.prototype.hasOwnProperty,Nf={current:null},dp={key:!0,ref:!0,__self:!0,__source:!0};function hp(e,t,r){var n,i={},o=null,a=null;if(t!=null)for(n in t.ref!==void 0&&(a=t.ref),t.key!==void 0&&(o=""+t.key),t)cp.call(t,n)&&!dp.hasOwnProperty(n)&&(i[n]=t[n]);var s=arguments.length-2;if(s===1)i.children=r;else if(1<s){for(var u=Array(s),d=0;d<s;d++)u[d]=arguments[d+2];i.children=u}if(e&&e.defaultProps)for(n in s=e.defaultProps,s)i[n]===void 0&&(i[n]=s[n]);return{$$typeof:Do,type:e,key:o,ref:a,props:i,_owner:Nf.current}}function jy(e,t){return{$$typeof:Do,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function Rf(e){return typeof e=="object"&&e!==null&&e.$$typeof===Do}function Cy(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(r){return t[r]})}var zc=/\/+/g;function ns(e,t){return typeof e=="object"&&e!==null&&e.key!=null?Cy(""+e.key):t.toString(36)}function ja(e,t,r,n,i){var o=typeof e;(o==="undefined"||o==="boolean")&&(e=null);var a=!1;if(e===null)a=!0;else switch(o){case"string":case"number":a=!0;break;case"object":switch(e.$$typeof){case Do:case vy:a=!0}}if(a)return a=e,i=i(a),e=n===""?"."+ns(a,0):n,Fc(i)?(r="",e!=null&&(r=e.replace(zc,"$&/")+"/"),ja(i,t,r,"",function(d){return d})):i!=null&&(Rf(i)&&(i=jy(i,r+(!i.key||a&&a.key===i.key?"":(""+i.key).replace(zc,"$&/")+"/")+e)),t.push(i)),1;if(a=0,n=n===""?".":n+":",Fc(e))for(var s=0;s<e.length;s++){o=e[s];var u=n+ns(o,s);a+=ja(o,t,r,u,i)}else if(u=Ey(e),typeof u=="function")for(e=u.call(e),s=0;!(o=e.next()).done;)o=o.value,u=n+ns(o,s++),a+=ja(o,t,r,u,i);else if(o==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return a}function ia(e,t,r){if(e==null)return e;var n=[],i=0;return ja(e,n,"","",function(o){return t.call(r,o,i++)}),n}function Ay(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(r){(e._status===0||e._status===-1)&&(e._status=1,e._result=r)},function(r){(e._status===0||e._status===-1)&&(e._status=2,e._result=r)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var Gt={current:null},Ca={transition:null},Ny={ReactCurrentDispatcher:Gt,ReactCurrentBatchConfig:Ca,ReactCurrentOwner:Nf};function pp(){throw Error("act(...) is not supported in production builds of React.")}Fe.Children={map:ia,forEach:function(e,t,r){ia(e,function(){t.apply(this,arguments)},r)},count:function(e){var t=0;return ia(e,function(){t++}),t},toArray:function(e){return ia(e,function(t){return t})||[]},only:function(e){if(!Rf(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};Fe.Component=Ti;Fe.Fragment=yy;Fe.Profiler=my;Fe.PureComponent=Cf;Fe.StrictMode=gy;Fe.Suspense=_y;Fe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Ny;Fe.act=pp;Fe.cloneElement=function(e,t,r){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var n=sp({},e.props),i=e.key,o=e.ref,a=e._owner;if(t!=null){if(t.ref!==void 0&&(o=t.ref,a=Nf.current),t.key!==void 0&&(i=""+t.key),e.type&&e.type.defaultProps)var s=e.type.defaultProps;for(u in t)cp.call(t,u)&&!dp.hasOwnProperty(u)&&(n[u]=t[u]===void 0&&s!==void 0?s[u]:t[u])}var u=arguments.length-2;if(u===1)n.children=r;else if(1<u){s=Array(u);for(var d=0;d<u;d++)s[d]=arguments[d+2];n.children=s}return{$$typeof:Do,type:e.type,key:i,ref:o,props:n,_owner:a}};Fe.createContext=function(e){return e={$$typeof:by,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:xy,_context:e},e.Consumer=e};Fe.createElement=hp;Fe.createFactory=function(e){var t=hp.bind(null,e);return t.type=e,t};Fe.createRef=function(){return{current:null}};Fe.forwardRef=function(e){return{$$typeof:wy,render:e}};Fe.isValidElement=Rf;Fe.lazy=function(e){return{$$typeof:Sy,_payload:{_status:-1,_result:e},_init:Ay}};Fe.memo=function(e,t){return{$$typeof:ky,type:e,compare:t===void 0?null:t}};Fe.startTransition=function(e){var t=Ca.transition;Ca.transition={};try{e()}finally{Ca.transition=t}};Fe.unstable_act=pp;Fe.useCallback=function(e,t){return Gt.current.useCallback(e,t)};Fe.useContext=function(e){return Gt.current.useContext(e)};Fe.useDebugValue=function(){};Fe.useDeferredValue=function(e){return Gt.current.useDeferredValue(e)};Fe.useEffect=function(e,t){return Gt.current.useEffect(e,t)};Fe.useId=function(){return Gt.current.useId()};Fe.useImperativeHandle=function(e,t,r){return Gt.current.useImperativeHandle(e,t,r)};Fe.useInsertionEffect=function(e,t){return Gt.current.useInsertionEffect(e,t)};Fe.useLayoutEffect=function(e,t){return Gt.current.useLayoutEffect(e,t)};Fe.useMemo=function(e,t){return Gt.current.useMemo(e,t)};Fe.useReducer=function(e,t,r){return Gt.current.useReducer(e,t,r)};Fe.useRef=function(e){return Gt.current.useRef(e)};Fe.useState=function(e){return Gt.current.useState(e)};Fe.useSyncExternalStore=function(e,t,r){return Gt.current.useSyncExternalStore(e,t,r)};Fe.useTransition=function(){return Gt.current.useTransition()};Fe.version="18.3.1";ap.exports=Fe;var xe=ap.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ry=xe,Ty=Symbol.for("react.element"),Ly=Symbol.for("react.fragment"),By=Object.prototype.hasOwnProperty,Py=Ry.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,My={key:!0,ref:!0,__self:!0,__source:!0};function vp(e,t,r){var n,i={},o=null,a=null;r!==void 0&&(o=""+r),t.key!==void 0&&(o=""+t.key),t.ref!==void 0&&(a=t.ref);for(n in t)By.call(t,n)&&!My.hasOwnProperty(n)&&(i[n]=t[n]);if(e&&e.defaultProps)for(n in t=e.defaultProps,t)i[n]===void 0&&(i[n]=t[n]);return{$$typeof:Ty,type:e,key:o,ref:a,props:i,_owner:Py.current}}bl.Fragment=Ly;bl.jsx=vp;bl.jsxs=vp;op.exports=bl;var f=op.exports;typeof globalThis.process>"u"&&(globalThis.process={env:{},browser:!0,version:"v18.0.0",versions:{},nextTick:(e,...t)=>queueMicrotask(()=>e(...t)),stdout:null,stderr:null});typeof globalThis.Buffer>"u"&&(globalThis.Buffer=Xr.Buffer);var yp={exports:{}},ur={},gp={exports:{}},mp={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(A,D){var J=A.length;A.push(D);e:for(;0<J;){var le=J-1>>>1,de=A[le];if(0<i(de,D))A[le]=D,A[J]=de,J=le;else break e}}function r(A){return A.length===0?null:A[0]}function n(A){if(A.length===0)return null;var D=A[0],J=A.pop();if(J!==D){A[0]=J;e:for(var le=0,de=A.length,Ne=de>>>1;le<Ne;){var Re=2*(le+1)-1,ge=A[Re],T=Re+1,h=A[T];if(0>i(ge,J))T<de&&0>i(h,ge)?(A[le]=h,A[T]=J,le=T):(A[le]=ge,A[Re]=J,le=Re);else if(T<de&&0>i(h,J))A[le]=h,A[T]=J,le=T;else break e}}return D}function i(A,D){var J=A.sortIndex-D.sortIndex;return J!==0?J:A.id-D.id}if(typeof performance=="object"&&typeof performance.now=="function"){var o=performance;e.unstable_now=function(){return o.now()}}else{var a=Date,s=a.now();e.unstable_now=function(){return a.now()-s}}var u=[],d=[],_=1,m=null,E=3,B=!1,R=!1,N=!1,P=typeof setTimeout=="function"?setTimeout:null,p=typeof clearTimeout=="function"?clearTimeout:null,v=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function x(A){for(var D=r(d);D!==null;){if(D.callback===null)n(d);else if(D.startTime<=A)n(d),D.sortIndex=D.expirationTime,t(u,D);else break;D=r(d)}}function C(A){if(N=!1,x(A),!R)if(r(u)!==null)R=!0,tt(O);else{var D=r(d);D!==null&&I(C,D.startTime-A)}}function O(A,D){R=!1,N&&(N=!1,p(V),V=-1),B=!0;var J=E;try{for(x(D),m=r(u);m!==null&&(!(m.expirationTime>D)||A&&!De());){var le=m.callback;if(typeof le=="function"){m.callback=null,E=m.priorityLevel;var de=le(m.expirationTime<=D);D=e.unstable_now(),typeof de=="function"?m.callback=de:m===r(u)&&n(u),x(D)}else n(u);m=r(u)}if(m!==null)var Ne=!0;else{var Re=r(d);Re!==null&&I(C,Re.startTime-D),Ne=!1}return Ne}finally{m=null,E=J,B=!1}}var H=!1,Q=null,V=-1,X=5,pe=-1;function De(){return!(e.unstable_now()-pe<X)}function $e(){if(Q!==null){var A=e.unstable_now();pe=A;var D=!0;try{D=Q(!0,A)}finally{D?_e():(H=!1,Q=null)}}else H=!1}var _e;if(typeof v=="function")_e=function(){v($e)};else if(typeof MessageChannel<"u"){var He=new MessageChannel,nt=He.port2;He.port1.onmessage=$e,_e=function(){nt.postMessage(null)}}else _e=function(){P($e,0)};function tt(A){Q=A,H||(H=!0,_e())}function I(A,D){V=P(function(){A(e.unstable_now())},D)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(A){A.callback=null},e.unstable_continueExecution=function(){R||B||(R=!0,tt(O))},e.unstable_forceFrameRate=function(A){0>A||125<A?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):X=0<A?Math.floor(1e3/A):5},e.unstable_getCurrentPriorityLevel=function(){return E},e.unstable_getFirstCallbackNode=function(){return r(u)},e.unstable_next=function(A){switch(E){case 1:case 2:case 3:var D=3;break;default:D=E}var J=E;E=D;try{return A()}finally{E=J}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(A,D){switch(A){case 1:case 2:case 3:case 4:case 5:break;default:A=3}var J=E;E=A;try{return D()}finally{E=J}},e.unstable_scheduleCallback=function(A,D,J){var le=e.unstable_now();switch(typeof J=="object"&&J!==null?(J=J.delay,J=typeof J=="number"&&0<J?le+J:le):J=le,A){case 1:var de=-1;break;case 2:de=250;break;case 5:de=1073741823;break;case 4:de=1e4;break;default:de=5e3}return de=J+de,A={id:_++,callback:D,priorityLevel:A,startTime:J,expirationTime:de,sortIndex:-1},J>le?(A.sortIndex=J,t(d,A),r(u)===null&&A===r(d)&&(N?(p(V),V=-1):N=!0,I(C,J-le))):(A.sortIndex=de,t(u,A),R||B||(R=!0,tt(O))),A},e.unstable_shouldYield=De,e.unstable_wrapCallback=function(A){var D=E;return function(){var J=E;E=D;try{return A.apply(this,arguments)}finally{E=J}}}})(mp);gp.exports=mp;var Oy=gp.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Iy=xe,sr=Oy;function te(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,r=1;r<arguments.length;r++)t+="&args[]="+encodeURIComponent(arguments[r]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var xp=new Set,yo={};function zn(e,t){xi(e,t),xi(e+"Capture",t)}function xi(e,t){for(yo[e]=t,e=0;e<t.length;e++)xp.add(t[e])}var Vr=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),xu=Object.prototype.hasOwnProperty,Dy=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,$c={},Hc={};function Uy(e){return xu.call(Hc,e)?!0:xu.call($c,e)?!1:Dy.test(e)?Hc[e]=!0:($c[e]=!0,!1)}function Fy(e,t,r,n){if(r!==null&&r.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return n?!1:r!==null?!r.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function zy(e,t,r,n){if(t===null||typeof t>"u"||Fy(e,t,r,n))return!0;if(n)return!1;if(r!==null)switch(r.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function Yt(e,t,r,n,i,o,a){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=n,this.attributeNamespace=i,this.mustUseProperty=r,this.propertyName=e,this.type=t,this.sanitizeURL=o,this.removeEmptyString=a}var Lt={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){Lt[e]=new Yt(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];Lt[t]=new Yt(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){Lt[e]=new Yt(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){Lt[e]=new Yt(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){Lt[e]=new Yt(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){Lt[e]=new Yt(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){Lt[e]=new Yt(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){Lt[e]=new Yt(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){Lt[e]=new Yt(e,5,!1,e.toLowerCase(),null,!1,!1)});var Tf=/[\-:]([a-z])/g;function Lf(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(Tf,Lf);Lt[t]=new Yt(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(Tf,Lf);Lt[t]=new Yt(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(Tf,Lf);Lt[t]=new Yt(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){Lt[e]=new Yt(e,1,!1,e.toLowerCase(),null,!1,!1)});Lt.xlinkHref=new Yt("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){Lt[e]=new Yt(e,1,!1,e.toLowerCase(),null,!0,!0)});function Bf(e,t,r,n){var i=Lt.hasOwnProperty(t)?Lt[t]:null;(i!==null?i.type!==0:n||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(zy(t,r,i,n)&&(r=null),n||i===null?Uy(t)&&(r===null?e.removeAttribute(t):e.setAttribute(t,""+r)):i.mustUseProperty?e[i.propertyName]=r===null?i.type===3?!1:"":r:(t=i.attributeName,n=i.attributeNamespace,r===null?e.removeAttribute(t):(i=i.type,r=i===3||i===4&&r===!0?"":""+r,n?e.setAttributeNS(n,t,r):e.setAttribute(t,r))))}var Zr=Iy.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,oa=Symbol.for("react.element"),Zn=Symbol.for("react.portal"),Jn=Symbol.for("react.fragment"),Pf=Symbol.for("react.strict_mode"),bu=Symbol.for("react.profiler"),bp=Symbol.for("react.provider"),wp=Symbol.for("react.context"),Mf=Symbol.for("react.forward_ref"),wu=Symbol.for("react.suspense"),_u=Symbol.for("react.suspense_list"),Of=Symbol.for("react.memo"),on=Symbol.for("react.lazy"),_p=Symbol.for("react.offscreen"),Wc=Symbol.iterator;function Fi(e){return e===null||typeof e!="object"?null:(e=Wc&&e[Wc]||e["@@iterator"],typeof e=="function"?e:null)}var ft=Object.assign,is;function to(e){if(is===void 0)try{throw Error()}catch(r){var t=r.stack.trim().match(/\n( *(at )?)/);is=t&&t[1]||""}return`
`+is+e}var os=!1;function as(e,t){if(!e||os)return"";os=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(d){var n=d}Reflect.construct(e,[],t)}else{try{t.call()}catch(d){n=d}e.call(t.prototype)}else{try{throw Error()}catch(d){n=d}e()}}catch(d){if(d&&n&&typeof d.stack=="string"){for(var i=d.stack.split(`
`),o=n.stack.split(`
`),a=i.length-1,s=o.length-1;1<=a&&0<=s&&i[a]!==o[s];)s--;for(;1<=a&&0<=s;a--,s--)if(i[a]!==o[s]){if(a!==1||s!==1)do if(a--,s--,0>s||i[a]!==o[s]){var u=`
`+i[a].replace(" at new "," at ");return e.displayName&&u.includes("<anonymous>")&&(u=u.replace("<anonymous>",e.displayName)),u}while(1<=a&&0<=s);break}}}finally{os=!1,Error.prepareStackTrace=r}return(e=e?e.displayName||e.name:"")?to(e):""}function $y(e){switch(e.tag){case 5:return to(e.type);case 16:return to("Lazy");case 13:return to("Suspense");case 19:return to("SuspenseList");case 0:case 2:case 15:return e=as(e.type,!1),e;case 11:return e=as(e.type.render,!1),e;case 1:return e=as(e.type,!0),e;default:return""}}function ku(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Jn:return"Fragment";case Zn:return"Portal";case bu:return"Profiler";case Pf:return"StrictMode";case wu:return"Suspense";case _u:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case wp:return(e.displayName||"Context")+".Consumer";case bp:return(e._context.displayName||"Context")+".Provider";case Mf:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Of:return t=e.displayName||null,t!==null?t:ku(e.type)||"Memo";case on:t=e._payload,e=e._init;try{return ku(e(t))}catch{}}return null}function Hy(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return ku(t);case 8:return t===Pf?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function xn(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function kp(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Wy(e){var t=kp(e)?"checked":"value",r=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),n=""+e[t];if(!e.hasOwnProperty(t)&&typeof r<"u"&&typeof r.get=="function"&&typeof r.set=="function"){var i=r.get,o=r.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return i.call(this)},set:function(a){n=""+a,o.call(this,a)}}),Object.defineProperty(e,t,{enumerable:r.enumerable}),{getValue:function(){return n},setValue:function(a){n=""+a},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function aa(e){e._valueTracker||(e._valueTracker=Wy(e))}function Sp(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var r=t.getValue(),n="";return e&&(n=kp(e)?e.checked?"true":"false":e.value),e=n,e!==r?(t.setValue(e),!0):!1}function Ha(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function Su(e,t){var r=t.checked;return ft({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:r??e._wrapperState.initialChecked})}function Vc(e,t){var r=t.defaultValue==null?"":t.defaultValue,n=t.checked!=null?t.checked:t.defaultChecked;r=xn(t.value!=null?t.value:r),e._wrapperState={initialChecked:n,initialValue:r,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function Ep(e,t){t=t.checked,t!=null&&Bf(e,"checked",t,!1)}function Eu(e,t){Ep(e,t);var r=xn(t.value),n=t.type;if(r!=null)n==="number"?(r===0&&e.value===""||e.value!=r)&&(e.value=""+r):e.value!==""+r&&(e.value=""+r);else if(n==="submit"||n==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?ju(e,t.type,r):t.hasOwnProperty("defaultValue")&&ju(e,t.type,xn(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function Kc(e,t,r){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var n=t.type;if(!(n!=="submit"&&n!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,r||t===e.value||(e.value=t),e.defaultValue=t}r=e.name,r!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,r!==""&&(e.name=r)}function ju(e,t,r){(t!=="number"||Ha(e.ownerDocument)!==e)&&(r==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+r&&(e.defaultValue=""+r))}var ro=Array.isArray;function fi(e,t,r,n){if(e=e.options,t){t={};for(var i=0;i<r.length;i++)t["$"+r[i]]=!0;for(r=0;r<e.length;r++)i=t.hasOwnProperty("$"+e[r].value),e[r].selected!==i&&(e[r].selected=i),i&&n&&(e[r].defaultSelected=!0)}else{for(r=""+xn(r),t=null,i=0;i<e.length;i++){if(e[i].value===r){e[i].selected=!0,n&&(e[i].defaultSelected=!0);return}t!==null||e[i].disabled||(t=e[i])}t!==null&&(t.selected=!0)}}function Cu(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(te(91));return ft({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function qc(e,t){var r=t.value;if(r==null){if(r=t.children,t=t.defaultValue,r!=null){if(t!=null)throw Error(te(92));if(ro(r)){if(1<r.length)throw Error(te(93));r=r[0]}t=r}t==null&&(t=""),r=t}e._wrapperState={initialValue:xn(r)}}function jp(e,t){var r=xn(t.value),n=xn(t.defaultValue);r!=null&&(r=""+r,r!==e.value&&(e.value=r),t.defaultValue==null&&e.defaultValue!==r&&(e.defaultValue=r)),n!=null&&(e.defaultValue=""+n)}function Gc(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function Cp(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function Au(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?Cp(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var la,Ap=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,r,n,i){MSApp.execUnsafeLocalFunction(function(){return e(t,r,n,i)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(la=la||document.createElement("div"),la.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=la.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function go(e,t){if(t){var r=e.firstChild;if(r&&r===e.lastChild&&r.nodeType===3){r.nodeValue=t;return}}e.textContent=t}var ao={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Vy=["Webkit","ms","Moz","O"];Object.keys(ao).forEach(function(e){Vy.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),ao[t]=ao[e]})});function Np(e,t,r){return t==null||typeof t=="boolean"||t===""?"":r||typeof t!="number"||t===0||ao.hasOwnProperty(e)&&ao[e]?(""+t).trim():t+"px"}function Rp(e,t){e=e.style;for(var r in t)if(t.hasOwnProperty(r)){var n=r.indexOf("--")===0,i=Np(r,t[r],n);r==="float"&&(r="cssFloat"),n?e.setProperty(r,i):e[r]=i}}var Ky=ft({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Nu(e,t){if(t){if(Ky[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(te(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(te(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(te(61))}if(t.style!=null&&typeof t.style!="object")throw Error(te(62))}}function Ru(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Tu=null;function If(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Lu=null,ci=null,di=null;function Yc(e){if(e=zo(e)){if(typeof Lu!="function")throw Error(te(280));var t=e.stateNode;t&&(t=El(t),Lu(e.stateNode,e.type,t))}}function Tp(e){ci?di?di.push(e):di=[e]:ci=e}function Lp(){if(ci){var e=ci,t=di;if(di=ci=null,Yc(e),t)for(e=0;e<t.length;e++)Yc(t[e])}}function Bp(e,t){return e(t)}function Pp(){}var ls=!1;function Mp(e,t,r){if(ls)return e(t,r);ls=!0;try{return Bp(e,t,r)}finally{ls=!1,(ci!==null||di!==null)&&(Pp(),Lp())}}function mo(e,t){var r=e.stateNode;if(r===null)return null;var n=El(r);if(n===null)return null;r=n[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(n=!n.disabled)||(e=e.type,n=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!n;break e;default:e=!1}if(e)return null;if(r&&typeof r!="function")throw Error(te(231,t,typeof r));return r}var Bu=!1;if(Vr)try{var zi={};Object.defineProperty(zi,"passive",{get:function(){Bu=!0}}),window.addEventListener("test",zi,zi),window.removeEventListener("test",zi,zi)}catch{Bu=!1}function qy(e,t,r,n,i,o,a,s,u){var d=Array.prototype.slice.call(arguments,3);try{t.apply(r,d)}catch(_){this.onError(_)}}var lo=!1,Wa=null,Va=!1,Pu=null,Gy={onError:function(e){lo=!0,Wa=e}};function Yy(e,t,r,n,i,o,a,s,u){lo=!1,Wa=null,qy.apply(Gy,arguments)}function Qy(e,t,r,n,i,o,a,s,u){if(Yy.apply(this,arguments),lo){if(lo){var d=Wa;lo=!1,Wa=null}else throw Error(te(198));Va||(Va=!0,Pu=d)}}function $n(e){var t=e,r=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(r=t.return),e=t.return;while(e)}return t.tag===3?r:null}function Op(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Qc(e){if($n(e)!==e)throw Error(te(188))}function Xy(e){var t=e.alternate;if(!t){if(t=$n(e),t===null)throw Error(te(188));return t!==e?null:e}for(var r=e,n=t;;){var i=r.return;if(i===null)break;var o=i.alternate;if(o===null){if(n=i.return,n!==null){r=n;continue}break}if(i.child===o.child){for(o=i.child;o;){if(o===r)return Qc(i),e;if(o===n)return Qc(i),t;o=o.sibling}throw Error(te(188))}if(r.return!==n.return)r=i,n=o;else{for(var a=!1,s=i.child;s;){if(s===r){a=!0,r=i,n=o;break}if(s===n){a=!0,n=i,r=o;break}s=s.sibling}if(!a){for(s=o.child;s;){if(s===r){a=!0,r=o,n=i;break}if(s===n){a=!0,n=o,r=i;break}s=s.sibling}if(!a)throw Error(te(189))}}if(r.alternate!==n)throw Error(te(190))}if(r.tag!==3)throw Error(te(188));return r.stateNode.current===r?e:t}function Ip(e){return e=Xy(e),e!==null?Dp(e):null}function Dp(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=Dp(e);if(t!==null)return t;e=e.sibling}return null}var Up=sr.unstable_scheduleCallback,Xc=sr.unstable_cancelCallback,Zy=sr.unstable_shouldYield,Jy=sr.unstable_requestPaint,xt=sr.unstable_now,eg=sr.unstable_getCurrentPriorityLevel,Df=sr.unstable_ImmediatePriority,Fp=sr.unstable_UserBlockingPriority,Ka=sr.unstable_NormalPriority,tg=sr.unstable_LowPriority,zp=sr.unstable_IdlePriority,wl=null,Or=null;function rg(e){if(Or&&typeof Or.onCommitFiberRoot=="function")try{Or.onCommitFiberRoot(wl,e,void 0,(e.current.flags&128)===128)}catch{}}var jr=Math.clz32?Math.clz32:og,ng=Math.log,ig=Math.LN2;function og(e){return e>>>=0,e===0?32:31-(ng(e)/ig|0)|0}var sa=64,ua=4194304;function no(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function qa(e,t){var r=e.pendingLanes;if(r===0)return 0;var n=0,i=e.suspendedLanes,o=e.pingedLanes,a=r&268435455;if(a!==0){var s=a&~i;s!==0?n=no(s):(o&=a,o!==0&&(n=no(o)))}else a=r&~i,a!==0?n=no(a):o!==0&&(n=no(o));if(n===0)return 0;if(t!==0&&t!==n&&!(t&i)&&(i=n&-n,o=t&-t,i>=o||i===16&&(o&4194240)!==0))return t;if(n&4&&(n|=r&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=n;0<t;)r=31-jr(t),i=1<<r,n|=e[r],t&=~i;return n}function ag(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function lg(e,t){for(var r=e.suspendedLanes,n=e.pingedLanes,i=e.expirationTimes,o=e.pendingLanes;0<o;){var a=31-jr(o),s=1<<a,u=i[a];u===-1?(!(s&r)||s&n)&&(i[a]=ag(s,t)):u<=t&&(e.expiredLanes|=s),o&=~s}}function Mu(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function $p(){var e=sa;return sa<<=1,!(sa&4194240)&&(sa=64),e}function ss(e){for(var t=[],r=0;31>r;r++)t.push(e);return t}function Uo(e,t,r){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-jr(t),e[t]=r}function sg(e,t){var r=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var n=e.eventTimes;for(e=e.expirationTimes;0<r;){var i=31-jr(r),o=1<<i;t[i]=0,n[i]=-1,e[i]=-1,r&=~o}}function Uf(e,t){var r=e.entangledLanes|=t;for(e=e.entanglements;r;){var n=31-jr(r),i=1<<n;i&t|e[n]&t&&(e[n]|=t),r&=~i}}var et=0;function Hp(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Wp,Ff,Vp,Kp,qp,Ou=!1,fa=[],cn=null,dn=null,hn=null,xo=new Map,bo=new Map,ln=[],ug="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Zc(e,t){switch(e){case"focusin":case"focusout":cn=null;break;case"dragenter":case"dragleave":dn=null;break;case"mouseover":case"mouseout":hn=null;break;case"pointerover":case"pointerout":xo.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":bo.delete(t.pointerId)}}function $i(e,t,r,n,i,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:r,eventSystemFlags:n,nativeEvent:o,targetContainers:[i]},t!==null&&(t=zo(t),t!==null&&Ff(t)),e):(e.eventSystemFlags|=n,t=e.targetContainers,i!==null&&t.indexOf(i)===-1&&t.push(i),e)}function fg(e,t,r,n,i){switch(t){case"focusin":return cn=$i(cn,e,t,r,n,i),!0;case"dragenter":return dn=$i(dn,e,t,r,n,i),!0;case"mouseover":return hn=$i(hn,e,t,r,n,i),!0;case"pointerover":var o=i.pointerId;return xo.set(o,$i(xo.get(o)||null,e,t,r,n,i)),!0;case"gotpointercapture":return o=i.pointerId,bo.set(o,$i(bo.get(o)||null,e,t,r,n,i)),!0}return!1}function Gp(e){var t=An(e.target);if(t!==null){var r=$n(t);if(r!==null){if(t=r.tag,t===13){if(t=Op(r),t!==null){e.blockedOn=t,qp(e.priority,function(){Vp(r)});return}}else if(t===3&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Aa(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var r=Iu(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(r===null){r=e.nativeEvent;var n=new r.constructor(r.type,r);Tu=n,r.target.dispatchEvent(n),Tu=null}else return t=zo(r),t!==null&&Ff(t),e.blockedOn=r,!1;t.shift()}return!0}function Jc(e,t,r){Aa(e)&&r.delete(t)}function cg(){Ou=!1,cn!==null&&Aa(cn)&&(cn=null),dn!==null&&Aa(dn)&&(dn=null),hn!==null&&Aa(hn)&&(hn=null),xo.forEach(Jc),bo.forEach(Jc)}function Hi(e,t){e.blockedOn===t&&(e.blockedOn=null,Ou||(Ou=!0,sr.unstable_scheduleCallback(sr.unstable_NormalPriority,cg)))}function wo(e){function t(i){return Hi(i,e)}if(0<fa.length){Hi(fa[0],e);for(var r=1;r<fa.length;r++){var n=fa[r];n.blockedOn===e&&(n.blockedOn=null)}}for(cn!==null&&Hi(cn,e),dn!==null&&Hi(dn,e),hn!==null&&Hi(hn,e),xo.forEach(t),bo.forEach(t),r=0;r<ln.length;r++)n=ln[r],n.blockedOn===e&&(n.blockedOn=null);for(;0<ln.length&&(r=ln[0],r.blockedOn===null);)Gp(r),r.blockedOn===null&&ln.shift()}var hi=Zr.ReactCurrentBatchConfig,Ga=!0;function dg(e,t,r,n){var i=et,o=hi.transition;hi.transition=null;try{et=1,zf(e,t,r,n)}finally{et=i,hi.transition=o}}function hg(e,t,r,n){var i=et,o=hi.transition;hi.transition=null;try{et=4,zf(e,t,r,n)}finally{et=i,hi.transition=o}}function zf(e,t,r,n){if(Ga){var i=Iu(e,t,r,n);if(i===null)ms(e,t,n,Ya,r),Zc(e,n);else if(fg(i,e,t,r,n))n.stopPropagation();else if(Zc(e,n),t&4&&-1<ug.indexOf(e)){for(;i!==null;){var o=zo(i);if(o!==null&&Wp(o),o=Iu(e,t,r,n),o===null&&ms(e,t,n,Ya,r),o===i)break;i=o}i!==null&&n.stopPropagation()}else ms(e,t,n,null,r)}}var Ya=null;function Iu(e,t,r,n){if(Ya=null,e=If(n),e=An(e),e!==null)if(t=$n(e),t===null)e=null;else if(r=t.tag,r===13){if(e=Op(t),e!==null)return e;e=null}else if(r===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return Ya=e,null}function Yp(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(eg()){case Df:return 1;case Fp:return 4;case Ka:case tg:return 16;case zp:return 536870912;default:return 16}default:return 16}}var un=null,$f=null,Na=null;function Qp(){if(Na)return Na;var e,t=$f,r=t.length,n,i="value"in un?un.value:un.textContent,o=i.length;for(e=0;e<r&&t[e]===i[e];e++);var a=r-e;for(n=1;n<=a&&t[r-n]===i[o-n];n++);return Na=i.slice(e,1<n?1-n:void 0)}function Ra(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function ca(){return!0}function ed(){return!1}function fr(e){function t(r,n,i,o,a){this._reactName=r,this._targetInst=i,this.type=n,this.nativeEvent=o,this.target=a,this.currentTarget=null;for(var s in e)e.hasOwnProperty(s)&&(r=e[s],this[s]=r?r(o):o[s]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?ca:ed,this.isPropagationStopped=ed,this}return ft(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=ca)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=ca)},persist:function(){},isPersistent:ca}),t}var Li={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Hf=fr(Li),Fo=ft({},Li,{view:0,detail:0}),pg=fr(Fo),us,fs,Wi,_l=ft({},Fo,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Wf,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Wi&&(Wi&&e.type==="mousemove"?(us=e.screenX-Wi.screenX,fs=e.screenY-Wi.screenY):fs=us=0,Wi=e),us)},movementY:function(e){return"movementY"in e?e.movementY:fs}}),td=fr(_l),vg=ft({},_l,{dataTransfer:0}),yg=fr(vg),gg=ft({},Fo,{relatedTarget:0}),cs=fr(gg),mg=ft({},Li,{animationName:0,elapsedTime:0,pseudoElement:0}),xg=fr(mg),bg=ft({},Li,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),wg=fr(bg),_g=ft({},Li,{data:0}),rd=fr(_g),kg={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Sg={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Eg={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function jg(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Eg[e])?!!t[e]:!1}function Wf(){return jg}var Cg=ft({},Fo,{key:function(e){if(e.key){var t=kg[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Ra(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Sg[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Wf,charCode:function(e){return e.type==="keypress"?Ra(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Ra(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Ag=fr(Cg),Ng=ft({},_l,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),nd=fr(Ng),Rg=ft({},Fo,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Wf}),Tg=fr(Rg),Lg=ft({},Li,{propertyName:0,elapsedTime:0,pseudoElement:0}),Bg=fr(Lg),Pg=ft({},_l,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Mg=fr(Pg),Og=[9,13,27,32],Vf=Vr&&"CompositionEvent"in window,so=null;Vr&&"documentMode"in document&&(so=document.documentMode);var Ig=Vr&&"TextEvent"in window&&!so,Xp=Vr&&(!Vf||so&&8<so&&11>=so),id=" ",od=!1;function Zp(e,t){switch(e){case"keyup":return Og.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Jp(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var ei=!1;function Dg(e,t){switch(e){case"compositionend":return Jp(t);case"keypress":return t.which!==32?null:(od=!0,id);case"textInput":return e=t.data,e===id&&od?null:e;default:return null}}function Ug(e,t){if(ei)return e==="compositionend"||!Vf&&Zp(e,t)?(e=Qp(),Na=$f=un=null,ei=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Xp&&t.locale!=="ko"?null:t.data;default:return null}}var Fg={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function ad(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Fg[e.type]:t==="textarea"}function e0(e,t,r,n){Tp(n),t=Qa(t,"onChange"),0<t.length&&(r=new Hf("onChange","change",null,r,n),e.push({event:r,listeners:t}))}var uo=null,_o=null;function zg(e){c0(e,0)}function kl(e){var t=ni(e);if(Sp(t))return e}function $g(e,t){if(e==="change")return t}var t0=!1;if(Vr){var ds;if(Vr){var hs="oninput"in document;if(!hs){var ld=document.createElement("div");ld.setAttribute("oninput","return;"),hs=typeof ld.oninput=="function"}ds=hs}else ds=!1;t0=ds&&(!document.documentMode||9<document.documentMode)}function sd(){uo&&(uo.detachEvent("onpropertychange",r0),_o=uo=null)}function r0(e){if(e.propertyName==="value"&&kl(_o)){var t=[];e0(t,_o,e,If(e)),Mp(zg,t)}}function Hg(e,t,r){e==="focusin"?(sd(),uo=t,_o=r,uo.attachEvent("onpropertychange",r0)):e==="focusout"&&sd()}function Wg(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return kl(_o)}function Vg(e,t){if(e==="click")return kl(t)}function Kg(e,t){if(e==="input"||e==="change")return kl(t)}function qg(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Ar=typeof Object.is=="function"?Object.is:qg;function ko(e,t){if(Ar(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var r=Object.keys(e),n=Object.keys(t);if(r.length!==n.length)return!1;for(n=0;n<r.length;n++){var i=r[n];if(!xu.call(t,i)||!Ar(e[i],t[i]))return!1}return!0}function ud(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function fd(e,t){var r=ud(e);e=0;for(var n;r;){if(r.nodeType===3){if(n=e+r.textContent.length,e<=t&&n>=t)return{node:r,offset:t-e};e=n}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=ud(r)}}function n0(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?n0(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function i0(){for(var e=window,t=Ha();t instanceof e.HTMLIFrameElement;){try{var r=typeof t.contentWindow.location.href=="string"}catch{r=!1}if(r)e=t.contentWindow;else break;t=Ha(e.document)}return t}function Kf(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function Gg(e){var t=i0(),r=e.focusedElem,n=e.selectionRange;if(t!==r&&r&&r.ownerDocument&&n0(r.ownerDocument.documentElement,r)){if(n!==null&&Kf(r)){if(t=n.start,e=n.end,e===void 0&&(e=t),"selectionStart"in r)r.selectionStart=t,r.selectionEnd=Math.min(e,r.value.length);else if(e=(t=r.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var i=r.textContent.length,o=Math.min(n.start,i);n=n.end===void 0?o:Math.min(n.end,i),!e.extend&&o>n&&(i=n,n=o,o=i),i=fd(r,o);var a=fd(r,n);i&&a&&(e.rangeCount!==1||e.anchorNode!==i.node||e.anchorOffset!==i.offset||e.focusNode!==a.node||e.focusOffset!==a.offset)&&(t=t.createRange(),t.setStart(i.node,i.offset),e.removeAllRanges(),o>n?(e.addRange(t),e.extend(a.node,a.offset)):(t.setEnd(a.node,a.offset),e.addRange(t)))}}for(t=[],e=r;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof r.focus=="function"&&r.focus(),r=0;r<t.length;r++)e=t[r],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Yg=Vr&&"documentMode"in document&&11>=document.documentMode,ti=null,Du=null,fo=null,Uu=!1;function cd(e,t,r){var n=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;Uu||ti==null||ti!==Ha(n)||(n=ti,"selectionStart"in n&&Kf(n)?n={start:n.selectionStart,end:n.selectionEnd}:(n=(n.ownerDocument&&n.ownerDocument.defaultView||window).getSelection(),n={anchorNode:n.anchorNode,anchorOffset:n.anchorOffset,focusNode:n.focusNode,focusOffset:n.focusOffset}),fo&&ko(fo,n)||(fo=n,n=Qa(Du,"onSelect"),0<n.length&&(t=new Hf("onSelect","select",null,t,r),e.push({event:t,listeners:n}),t.target=ti)))}function da(e,t){var r={};return r[e.toLowerCase()]=t.toLowerCase(),r["Webkit"+e]="webkit"+t,r["Moz"+e]="moz"+t,r}var ri={animationend:da("Animation","AnimationEnd"),animationiteration:da("Animation","AnimationIteration"),animationstart:da("Animation","AnimationStart"),transitionend:da("Transition","TransitionEnd")},ps={},o0={};Vr&&(o0=document.createElement("div").style,"AnimationEvent"in window||(delete ri.animationend.animation,delete ri.animationiteration.animation,delete ri.animationstart.animation),"TransitionEvent"in window||delete ri.transitionend.transition);function Sl(e){if(ps[e])return ps[e];if(!ri[e])return e;var t=ri[e],r;for(r in t)if(t.hasOwnProperty(r)&&r in o0)return ps[e]=t[r];return e}var a0=Sl("animationend"),l0=Sl("animationiteration"),s0=Sl("animationstart"),u0=Sl("transitionend"),f0=new Map,dd="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function wn(e,t){f0.set(e,t),zn(t,[e])}for(var vs=0;vs<dd.length;vs++){var ys=dd[vs],Qg=ys.toLowerCase(),Xg=ys[0].toUpperCase()+ys.slice(1);wn(Qg,"on"+Xg)}wn(a0,"onAnimationEnd");wn(l0,"onAnimationIteration");wn(s0,"onAnimationStart");wn("dblclick","onDoubleClick");wn("focusin","onFocus");wn("focusout","onBlur");wn(u0,"onTransitionEnd");xi("onMouseEnter",["mouseout","mouseover"]);xi("onMouseLeave",["mouseout","mouseover"]);xi("onPointerEnter",["pointerout","pointerover"]);xi("onPointerLeave",["pointerout","pointerover"]);zn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));zn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));zn("onBeforeInput",["compositionend","keypress","textInput","paste"]);zn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));zn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));zn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var io="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Zg=new Set("cancel close invalid load scroll toggle".split(" ").concat(io));function hd(e,t,r){var n=e.type||"unknown-event";e.currentTarget=r,Qy(n,t,void 0,e),e.currentTarget=null}function c0(e,t){t=(t&4)!==0;for(var r=0;r<e.length;r++){var n=e[r],i=n.event;n=n.listeners;e:{var o=void 0;if(t)for(var a=n.length-1;0<=a;a--){var s=n[a],u=s.instance,d=s.currentTarget;if(s=s.listener,u!==o&&i.isPropagationStopped())break e;hd(i,s,d),o=u}else for(a=0;a<n.length;a++){if(s=n[a],u=s.instance,d=s.currentTarget,s=s.listener,u!==o&&i.isPropagationStopped())break e;hd(i,s,d),o=u}}}if(Va)throw e=Pu,Va=!1,Pu=null,e}function ot(e,t){var r=t[Wu];r===void 0&&(r=t[Wu]=new Set);var n=e+"__bubble";r.has(n)||(d0(t,e,2,!1),r.add(n))}function gs(e,t,r){var n=0;t&&(n|=4),d0(r,e,n,t)}var ha="_reactListening"+Math.random().toString(36).slice(2);function So(e){if(!e[ha]){e[ha]=!0,xp.forEach(function(r){r!=="selectionchange"&&(Zg.has(r)||gs(r,!1,e),gs(r,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[ha]||(t[ha]=!0,gs("selectionchange",!1,t))}}function d0(e,t,r,n){switch(Yp(t)){case 1:var i=dg;break;case 4:i=hg;break;default:i=zf}r=i.bind(null,t,r,e),i=void 0,!Bu||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(i=!0),n?i!==void 0?e.addEventListener(t,r,{capture:!0,passive:i}):e.addEventListener(t,r,!0):i!==void 0?e.addEventListener(t,r,{passive:i}):e.addEventListener(t,r,!1)}function ms(e,t,r,n,i){var o=n;if(!(t&1)&&!(t&2)&&n!==null)e:for(;;){if(n===null)return;var a=n.tag;if(a===3||a===4){var s=n.stateNode.containerInfo;if(s===i||s.nodeType===8&&s.parentNode===i)break;if(a===4)for(a=n.return;a!==null;){var u=a.tag;if((u===3||u===4)&&(u=a.stateNode.containerInfo,u===i||u.nodeType===8&&u.parentNode===i))return;a=a.return}for(;s!==null;){if(a=An(s),a===null)return;if(u=a.tag,u===5||u===6){n=o=a;continue e}s=s.parentNode}}n=n.return}Mp(function(){var d=o,_=If(r),m=[];e:{var E=f0.get(e);if(E!==void 0){var B=Hf,R=e;switch(e){case"keypress":if(Ra(r)===0)break e;case"keydown":case"keyup":B=Ag;break;case"focusin":R="focus",B=cs;break;case"focusout":R="blur",B=cs;break;case"beforeblur":case"afterblur":B=cs;break;case"click":if(r.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":B=td;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":B=yg;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":B=Tg;break;case a0:case l0:case s0:B=xg;break;case u0:B=Bg;break;case"scroll":B=pg;break;case"wheel":B=Mg;break;case"copy":case"cut":case"paste":B=wg;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":B=nd}var N=(t&4)!==0,P=!N&&e==="scroll",p=N?E!==null?E+"Capture":null:E;N=[];for(var v=d,x;v!==null;){x=v;var C=x.stateNode;if(x.tag===5&&C!==null&&(x=C,p!==null&&(C=mo(v,p),C!=null&&N.push(Eo(v,C,x)))),P)break;v=v.return}0<N.length&&(E=new B(E,R,null,r,_),m.push({event:E,listeners:N}))}}if(!(t&7)){e:{if(E=e==="mouseover"||e==="pointerover",B=e==="mouseout"||e==="pointerout",E&&r!==Tu&&(R=r.relatedTarget||r.fromElement)&&(An(R)||R[Kr]))break e;if((B||E)&&(E=_.window===_?_:(E=_.ownerDocument)?E.defaultView||E.parentWindow:window,B?(R=r.relatedTarget||r.toElement,B=d,R=R?An(R):null,R!==null&&(P=$n(R),R!==P||R.tag!==5&&R.tag!==6)&&(R=null)):(B=null,R=d),B!==R)){if(N=td,C="onMouseLeave",p="onMouseEnter",v="mouse",(e==="pointerout"||e==="pointerover")&&(N=nd,C="onPointerLeave",p="onPointerEnter",v="pointer"),P=B==null?E:ni(B),x=R==null?E:ni(R),E=new N(C,v+"leave",B,r,_),E.target=P,E.relatedTarget=x,C=null,An(_)===d&&(N=new N(p,v+"enter",R,r,_),N.target=x,N.relatedTarget=P,C=N),P=C,B&&R)t:{for(N=B,p=R,v=0,x=N;x;x=Kn(x))v++;for(x=0,C=p;C;C=Kn(C))x++;for(;0<v-x;)N=Kn(N),v--;for(;0<x-v;)p=Kn(p),x--;for(;v--;){if(N===p||p!==null&&N===p.alternate)break t;N=Kn(N),p=Kn(p)}N=null}else N=null;B!==null&&pd(m,E,B,N,!1),R!==null&&P!==null&&pd(m,P,R,N,!0)}}e:{if(E=d?ni(d):window,B=E.nodeName&&E.nodeName.toLowerCase(),B==="select"||B==="input"&&E.type==="file")var O=$g;else if(ad(E))if(t0)O=Kg;else{O=Wg;var H=Hg}else(B=E.nodeName)&&B.toLowerCase()==="input"&&(E.type==="checkbox"||E.type==="radio")&&(O=Vg);if(O&&(O=O(e,d))){e0(m,O,r,_);break e}H&&H(e,E,d),e==="focusout"&&(H=E._wrapperState)&&H.controlled&&E.type==="number"&&ju(E,"number",E.value)}switch(H=d?ni(d):window,e){case"focusin":(ad(H)||H.contentEditable==="true")&&(ti=H,Du=d,fo=null);break;case"focusout":fo=Du=ti=null;break;case"mousedown":Uu=!0;break;case"contextmenu":case"mouseup":case"dragend":Uu=!1,cd(m,r,_);break;case"selectionchange":if(Yg)break;case"keydown":case"keyup":cd(m,r,_)}var Q;if(Vf)e:{switch(e){case"compositionstart":var V="onCompositionStart";break e;case"compositionend":V="onCompositionEnd";break e;case"compositionupdate":V="onCompositionUpdate";break e}V=void 0}else ei?Zp(e,r)&&(V="onCompositionEnd"):e==="keydown"&&r.keyCode===229&&(V="onCompositionStart");V&&(Xp&&r.locale!=="ko"&&(ei||V!=="onCompositionStart"?V==="onCompositionEnd"&&ei&&(Q=Qp()):(un=_,$f="value"in un?un.value:un.textContent,ei=!0)),H=Qa(d,V),0<H.length&&(V=new rd(V,e,null,r,_),m.push({event:V,listeners:H}),Q?V.data=Q:(Q=Jp(r),Q!==null&&(V.data=Q)))),(Q=Ig?Dg(e,r):Ug(e,r))&&(d=Qa(d,"onBeforeInput"),0<d.length&&(_=new rd("onBeforeInput","beforeinput",null,r,_),m.push({event:_,listeners:d}),_.data=Q))}c0(m,t)})}function Eo(e,t,r){return{instance:e,listener:t,currentTarget:r}}function Qa(e,t){for(var r=t+"Capture",n=[];e!==null;){var i=e,o=i.stateNode;i.tag===5&&o!==null&&(i=o,o=mo(e,r),o!=null&&n.unshift(Eo(e,o,i)),o=mo(e,t),o!=null&&n.push(Eo(e,o,i))),e=e.return}return n}function Kn(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function pd(e,t,r,n,i){for(var o=t._reactName,a=[];r!==null&&r!==n;){var s=r,u=s.alternate,d=s.stateNode;if(u!==null&&u===n)break;s.tag===5&&d!==null&&(s=d,i?(u=mo(r,o),u!=null&&a.unshift(Eo(r,u,s))):i||(u=mo(r,o),u!=null&&a.push(Eo(r,u,s)))),r=r.return}a.length!==0&&e.push({event:t,listeners:a})}var Jg=/\r\n?/g,em=/\u0000|\uFFFD/g;function vd(e){return(typeof e=="string"?e:""+e).replace(Jg,`
`).replace(em,"")}function pa(e,t,r){if(t=vd(t),vd(e)!==t&&r)throw Error(te(425))}function Xa(){}var Fu=null,zu=null;function $u(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Hu=typeof setTimeout=="function"?setTimeout:void 0,tm=typeof clearTimeout=="function"?clearTimeout:void 0,yd=typeof Promise=="function"?Promise:void 0,rm=typeof queueMicrotask=="function"?queueMicrotask:typeof yd<"u"?function(e){return yd.resolve(null).then(e).catch(nm)}:Hu;function nm(e){setTimeout(function(){throw e})}function xs(e,t){var r=t,n=0;do{var i=r.nextSibling;if(e.removeChild(r),i&&i.nodeType===8)if(r=i.data,r==="/$"){if(n===0){e.removeChild(i),wo(t);return}n--}else r!=="$"&&r!=="$?"&&r!=="$!"||n++;r=i}while(r);wo(t)}function pn(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function gd(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="$"||r==="$!"||r==="$?"){if(t===0)return e;t--}else r==="/$"&&t++}e=e.previousSibling}return null}var Bi=Math.random().toString(36).slice(2),Mr="__reactFiber$"+Bi,jo="__reactProps$"+Bi,Kr="__reactContainer$"+Bi,Wu="__reactEvents$"+Bi,im="__reactListeners$"+Bi,om="__reactHandles$"+Bi;function An(e){var t=e[Mr];if(t)return t;for(var r=e.parentNode;r;){if(t=r[Kr]||r[Mr]){if(r=t.alternate,t.child!==null||r!==null&&r.child!==null)for(e=gd(e);e!==null;){if(r=e[Mr])return r;e=gd(e)}return t}e=r,r=e.parentNode}return null}function zo(e){return e=e[Mr]||e[Kr],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function ni(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(te(33))}function El(e){return e[jo]||null}var Vu=[],ii=-1;function _n(e){return{current:e}}function at(e){0>ii||(e.current=Vu[ii],Vu[ii]=null,ii--)}function it(e,t){ii++,Vu[ii]=e.current,e.current=t}var bn={},Ht=_n(bn),Jt=_n(!1),Mn=bn;function bi(e,t){var r=e.type.contextTypes;if(!r)return bn;var n=e.stateNode;if(n&&n.__reactInternalMemoizedUnmaskedChildContext===t)return n.__reactInternalMemoizedMaskedChildContext;var i={},o;for(o in r)i[o]=t[o];return n&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=i),i}function er(e){return e=e.childContextTypes,e!=null}function Za(){at(Jt),at(Ht)}function md(e,t,r){if(Ht.current!==bn)throw Error(te(168));it(Ht,t),it(Jt,r)}function h0(e,t,r){var n=e.stateNode;if(t=t.childContextTypes,typeof n.getChildContext!="function")return r;n=n.getChildContext();for(var i in n)if(!(i in t))throw Error(te(108,Hy(e)||"Unknown",i));return ft({},r,n)}function Ja(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||bn,Mn=Ht.current,it(Ht,e),it(Jt,Jt.current),!0}function xd(e,t,r){var n=e.stateNode;if(!n)throw Error(te(169));r?(e=h0(e,t,Mn),n.__reactInternalMemoizedMergedChildContext=e,at(Jt),at(Ht),it(Ht,e)):at(Jt),it(Jt,r)}var zr=null,jl=!1,bs=!1;function p0(e){zr===null?zr=[e]:zr.push(e)}function am(e){jl=!0,p0(e)}function kn(){if(!bs&&zr!==null){bs=!0;var e=0,t=et;try{var r=zr;for(et=1;e<r.length;e++){var n=r[e];do n=n(!0);while(n!==null)}zr=null,jl=!1}catch(i){throw zr!==null&&(zr=zr.slice(e+1)),Up(Df,kn),i}finally{et=t,bs=!1}}return null}var oi=[],ai=0,el=null,tl=0,hr=[],pr=0,On=null,$r=1,Hr="";function jn(e,t){oi[ai++]=tl,oi[ai++]=el,el=e,tl=t}function v0(e,t,r){hr[pr++]=$r,hr[pr++]=Hr,hr[pr++]=On,On=e;var n=$r;e=Hr;var i=32-jr(n)-1;n&=~(1<<i),r+=1;var o=32-jr(t)+i;if(30<o){var a=i-i%5;o=(n&(1<<a)-1).toString(32),n>>=a,i-=a,$r=1<<32-jr(t)+i|r<<i|n,Hr=o+e}else $r=1<<o|r<<i|n,Hr=e}function qf(e){e.return!==null&&(jn(e,1),v0(e,1,0))}function Gf(e){for(;e===el;)el=oi[--ai],oi[ai]=null,tl=oi[--ai],oi[ai]=null;for(;e===On;)On=hr[--pr],hr[pr]=null,Hr=hr[--pr],hr[pr]=null,$r=hr[--pr],hr[pr]=null}var lr=null,ar=null,lt=!1,Er=null;function y0(e,t){var r=vr(5,null,null,0);r.elementType="DELETED",r.stateNode=t,r.return=e,t=e.deletions,t===null?(e.deletions=[r],e.flags|=16):t.push(r)}function bd(e,t){switch(e.tag){case 5:var r=e.type;return t=t.nodeType!==1||r.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,lr=e,ar=pn(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,lr=e,ar=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(r=On!==null?{id:$r,overflow:Hr}:null,e.memoizedState={dehydrated:t,treeContext:r,retryLane:1073741824},r=vr(18,null,null,0),r.stateNode=t,r.return=e,e.child=r,lr=e,ar=null,!0):!1;default:return!1}}function Ku(e){return(e.mode&1)!==0&&(e.flags&128)===0}function qu(e){if(lt){var t=ar;if(t){var r=t;if(!bd(e,t)){if(Ku(e))throw Error(te(418));t=pn(r.nextSibling);var n=lr;t&&bd(e,t)?y0(n,r):(e.flags=e.flags&-4097|2,lt=!1,lr=e)}}else{if(Ku(e))throw Error(te(418));e.flags=e.flags&-4097|2,lt=!1,lr=e}}}function wd(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;lr=e}function va(e){if(e!==lr)return!1;if(!lt)return wd(e),lt=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!$u(e.type,e.memoizedProps)),t&&(t=ar)){if(Ku(e))throw g0(),Error(te(418));for(;t;)y0(e,t),t=pn(t.nextSibling)}if(wd(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(te(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var r=e.data;if(r==="/$"){if(t===0){ar=pn(e.nextSibling);break e}t--}else r!=="$"&&r!=="$!"&&r!=="$?"||t++}e=e.nextSibling}ar=null}}else ar=lr?pn(e.stateNode.nextSibling):null;return!0}function g0(){for(var e=ar;e;)e=pn(e.nextSibling)}function wi(){ar=lr=null,lt=!1}function Yf(e){Er===null?Er=[e]:Er.push(e)}var lm=Zr.ReactCurrentBatchConfig;function Vi(e,t,r){if(e=r.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(r._owner){if(r=r._owner,r){if(r.tag!==1)throw Error(te(309));var n=r.stateNode}if(!n)throw Error(te(147,e));var i=n,o=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===o?t.ref:(t=function(a){var s=i.refs;a===null?delete s[o]:s[o]=a},t._stringRef=o,t)}if(typeof e!="string")throw Error(te(284));if(!r._owner)throw Error(te(290,e))}return e}function ya(e,t){throw e=Object.prototype.toString.call(t),Error(te(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function _d(e){var t=e._init;return t(e._payload)}function m0(e){function t(p,v){if(e){var x=p.deletions;x===null?(p.deletions=[v],p.flags|=16):x.push(v)}}function r(p,v){if(!e)return null;for(;v!==null;)t(p,v),v=v.sibling;return null}function n(p,v){for(p=new Map;v!==null;)v.key!==null?p.set(v.key,v):p.set(v.index,v),v=v.sibling;return p}function i(p,v){return p=mn(p,v),p.index=0,p.sibling=null,p}function o(p,v,x){return p.index=x,e?(x=p.alternate,x!==null?(x=x.index,x<v?(p.flags|=2,v):x):(p.flags|=2,v)):(p.flags|=1048576,v)}function a(p){return e&&p.alternate===null&&(p.flags|=2),p}function s(p,v,x,C){return v===null||v.tag!==6?(v=Cs(x,p.mode,C),v.return=p,v):(v=i(v,x),v.return=p,v)}function u(p,v,x,C){var O=x.type;return O===Jn?_(p,v,x.props.children,C,x.key):v!==null&&(v.elementType===O||typeof O=="object"&&O!==null&&O.$$typeof===on&&_d(O)===v.type)?(C=i(v,x.props),C.ref=Vi(p,v,x),C.return=p,C):(C=Ia(x.type,x.key,x.props,null,p.mode,C),C.ref=Vi(p,v,x),C.return=p,C)}function d(p,v,x,C){return v===null||v.tag!==4||v.stateNode.containerInfo!==x.containerInfo||v.stateNode.implementation!==x.implementation?(v=As(x,p.mode,C),v.return=p,v):(v=i(v,x.children||[]),v.return=p,v)}function _(p,v,x,C,O){return v===null||v.tag!==7?(v=Bn(x,p.mode,C,O),v.return=p,v):(v=i(v,x),v.return=p,v)}function m(p,v,x){if(typeof v=="string"&&v!==""||typeof v=="number")return v=Cs(""+v,p.mode,x),v.return=p,v;if(typeof v=="object"&&v!==null){switch(v.$$typeof){case oa:return x=Ia(v.type,v.key,v.props,null,p.mode,x),x.ref=Vi(p,null,v),x.return=p,x;case Zn:return v=As(v,p.mode,x),v.return=p,v;case on:var C=v._init;return m(p,C(v._payload),x)}if(ro(v)||Fi(v))return v=Bn(v,p.mode,x,null),v.return=p,v;ya(p,v)}return null}function E(p,v,x,C){var O=v!==null?v.key:null;if(typeof x=="string"&&x!==""||typeof x=="number")return O!==null?null:s(p,v,""+x,C);if(typeof x=="object"&&x!==null){switch(x.$$typeof){case oa:return x.key===O?u(p,v,x,C):null;case Zn:return x.key===O?d(p,v,x,C):null;case on:return O=x._init,E(p,v,O(x._payload),C)}if(ro(x)||Fi(x))return O!==null?null:_(p,v,x,C,null);ya(p,x)}return null}function B(p,v,x,C,O){if(typeof C=="string"&&C!==""||typeof C=="number")return p=p.get(x)||null,s(v,p,""+C,O);if(typeof C=="object"&&C!==null){switch(C.$$typeof){case oa:return p=p.get(C.key===null?x:C.key)||null,u(v,p,C,O);case Zn:return p=p.get(C.key===null?x:C.key)||null,d(v,p,C,O);case on:var H=C._init;return B(p,v,x,H(C._payload),O)}if(ro(C)||Fi(C))return p=p.get(x)||null,_(v,p,C,O,null);ya(v,C)}return null}function R(p,v,x,C){for(var O=null,H=null,Q=v,V=v=0,X=null;Q!==null&&V<x.length;V++){Q.index>V?(X=Q,Q=null):X=Q.sibling;var pe=E(p,Q,x[V],C);if(pe===null){Q===null&&(Q=X);break}e&&Q&&pe.alternate===null&&t(p,Q),v=o(pe,v,V),H===null?O=pe:H.sibling=pe,H=pe,Q=X}if(V===x.length)return r(p,Q),lt&&jn(p,V),O;if(Q===null){for(;V<x.length;V++)Q=m(p,x[V],C),Q!==null&&(v=o(Q,v,V),H===null?O=Q:H.sibling=Q,H=Q);return lt&&jn(p,V),O}for(Q=n(p,Q);V<x.length;V++)X=B(Q,p,V,x[V],C),X!==null&&(e&&X.alternate!==null&&Q.delete(X.key===null?V:X.key),v=o(X,v,V),H===null?O=X:H.sibling=X,H=X);return e&&Q.forEach(function(De){return t(p,De)}),lt&&jn(p,V),O}function N(p,v,x,C){var O=Fi(x);if(typeof O!="function")throw Error(te(150));if(x=O.call(x),x==null)throw Error(te(151));for(var H=O=null,Q=v,V=v=0,X=null,pe=x.next();Q!==null&&!pe.done;V++,pe=x.next()){Q.index>V?(X=Q,Q=null):X=Q.sibling;var De=E(p,Q,pe.value,C);if(De===null){Q===null&&(Q=X);break}e&&Q&&De.alternate===null&&t(p,Q),v=o(De,v,V),H===null?O=De:H.sibling=De,H=De,Q=X}if(pe.done)return r(p,Q),lt&&jn(p,V),O;if(Q===null){for(;!pe.done;V++,pe=x.next())pe=m(p,pe.value,C),pe!==null&&(v=o(pe,v,V),H===null?O=pe:H.sibling=pe,H=pe);return lt&&jn(p,V),O}for(Q=n(p,Q);!pe.done;V++,pe=x.next())pe=B(Q,p,V,pe.value,C),pe!==null&&(e&&pe.alternate!==null&&Q.delete(pe.key===null?V:pe.key),v=o(pe,v,V),H===null?O=pe:H.sibling=pe,H=pe);return e&&Q.forEach(function($e){return t(p,$e)}),lt&&jn(p,V),O}function P(p,v,x,C){if(typeof x=="object"&&x!==null&&x.type===Jn&&x.key===null&&(x=x.props.children),typeof x=="object"&&x!==null){switch(x.$$typeof){case oa:e:{for(var O=x.key,H=v;H!==null;){if(H.key===O){if(O=x.type,O===Jn){if(H.tag===7){r(p,H.sibling),v=i(H,x.props.children),v.return=p,p=v;break e}}else if(H.elementType===O||typeof O=="object"&&O!==null&&O.$$typeof===on&&_d(O)===H.type){r(p,H.sibling),v=i(H,x.props),v.ref=Vi(p,H,x),v.return=p,p=v;break e}r(p,H);break}else t(p,H);H=H.sibling}x.type===Jn?(v=Bn(x.props.children,p.mode,C,x.key),v.return=p,p=v):(C=Ia(x.type,x.key,x.props,null,p.mode,C),C.ref=Vi(p,v,x),C.return=p,p=C)}return a(p);case Zn:e:{for(H=x.key;v!==null;){if(v.key===H)if(v.tag===4&&v.stateNode.containerInfo===x.containerInfo&&v.stateNode.implementation===x.implementation){r(p,v.sibling),v=i(v,x.children||[]),v.return=p,p=v;break e}else{r(p,v);break}else t(p,v);v=v.sibling}v=As(x,p.mode,C),v.return=p,p=v}return a(p);case on:return H=x._init,P(p,v,H(x._payload),C)}if(ro(x))return R(p,v,x,C);if(Fi(x))return N(p,v,x,C);ya(p,x)}return typeof x=="string"&&x!==""||typeof x=="number"?(x=""+x,v!==null&&v.tag===6?(r(p,v.sibling),v=i(v,x),v.return=p,p=v):(r(p,v),v=Cs(x,p.mode,C),v.return=p,p=v),a(p)):r(p,v)}return P}var _i=m0(!0),x0=m0(!1),rl=_n(null),nl=null,li=null,Qf=null;function Xf(){Qf=li=nl=null}function Zf(e){var t=rl.current;at(rl),e._currentValue=t}function Gu(e,t,r){for(;e!==null;){var n=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,n!==null&&(n.childLanes|=t)):n!==null&&(n.childLanes&t)!==t&&(n.childLanes|=t),e===r)break;e=e.return}}function pi(e,t){nl=e,Qf=li=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(Zt=!0),e.firstContext=null)}function mr(e){var t=e._currentValue;if(Qf!==e)if(e={context:e,memoizedValue:t,next:null},li===null){if(nl===null)throw Error(te(308));li=e,nl.dependencies={lanes:0,firstContext:e}}else li=li.next=e;return t}var Nn=null;function Jf(e){Nn===null?Nn=[e]:Nn.push(e)}function b0(e,t,r,n){var i=t.interleaved;return i===null?(r.next=r,Jf(t)):(r.next=i.next,i.next=r),t.interleaved=r,qr(e,n)}function qr(e,t){e.lanes|=t;var r=e.alternate;for(r!==null&&(r.lanes|=t),r=e,e=e.return;e!==null;)e.childLanes|=t,r=e.alternate,r!==null&&(r.childLanes|=t),r=e,e=e.return;return r.tag===3?r.stateNode:null}var an=!1;function ec(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function w0(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function Wr(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function vn(e,t,r){var n=e.updateQueue;if(n===null)return null;if(n=n.shared,Qe&2){var i=n.pending;return i===null?t.next=t:(t.next=i.next,i.next=t),n.pending=t,qr(e,r)}return i=n.interleaved,i===null?(t.next=t,Jf(n)):(t.next=i.next,i.next=t),n.interleaved=t,qr(e,r)}function Ta(e,t,r){if(t=t.updateQueue,t!==null&&(t=t.shared,(r&4194240)!==0)){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,Uf(e,r)}}function kd(e,t){var r=e.updateQueue,n=e.alternate;if(n!==null&&(n=n.updateQueue,r===n)){var i=null,o=null;if(r=r.firstBaseUpdate,r!==null){do{var a={eventTime:r.eventTime,lane:r.lane,tag:r.tag,payload:r.payload,callback:r.callback,next:null};o===null?i=o=a:o=o.next=a,r=r.next}while(r!==null);o===null?i=o=t:o=o.next=t}else i=o=t;r={baseState:n.baseState,firstBaseUpdate:i,lastBaseUpdate:o,shared:n.shared,effects:n.effects},e.updateQueue=r;return}e=r.lastBaseUpdate,e===null?r.firstBaseUpdate=t:e.next=t,r.lastBaseUpdate=t}function il(e,t,r,n){var i=e.updateQueue;an=!1;var o=i.firstBaseUpdate,a=i.lastBaseUpdate,s=i.shared.pending;if(s!==null){i.shared.pending=null;var u=s,d=u.next;u.next=null,a===null?o=d:a.next=d,a=u;var _=e.alternate;_!==null&&(_=_.updateQueue,s=_.lastBaseUpdate,s!==a&&(s===null?_.firstBaseUpdate=d:s.next=d,_.lastBaseUpdate=u))}if(o!==null){var m=i.baseState;a=0,_=d=u=null,s=o;do{var E=s.lane,B=s.eventTime;if((n&E)===E){_!==null&&(_=_.next={eventTime:B,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});e:{var R=e,N=s;switch(E=t,B=r,N.tag){case 1:if(R=N.payload,typeof R=="function"){m=R.call(B,m,E);break e}m=R;break e;case 3:R.flags=R.flags&-65537|128;case 0:if(R=N.payload,E=typeof R=="function"?R.call(B,m,E):R,E==null)break e;m=ft({},m,E);break e;case 2:an=!0}}s.callback!==null&&s.lane!==0&&(e.flags|=64,E=i.effects,E===null?i.effects=[s]:E.push(s))}else B={eventTime:B,lane:E,tag:s.tag,payload:s.payload,callback:s.callback,next:null},_===null?(d=_=B,u=m):_=_.next=B,a|=E;if(s=s.next,s===null){if(s=i.shared.pending,s===null)break;E=s,s=E.next,E.next=null,i.lastBaseUpdate=E,i.shared.pending=null}}while(!0);if(_===null&&(u=m),i.baseState=u,i.firstBaseUpdate=d,i.lastBaseUpdate=_,t=i.shared.interleaved,t!==null){i=t;do a|=i.lane,i=i.next;while(i!==t)}else o===null&&(i.shared.lanes=0);Dn|=a,e.lanes=a,e.memoizedState=m}}function Sd(e,t,r){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var n=e[t],i=n.callback;if(i!==null){if(n.callback=null,n=r,typeof i!="function")throw Error(te(191,i));i.call(n)}}}var $o={},Ir=_n($o),Co=_n($o),Ao=_n($o);function Rn(e){if(e===$o)throw Error(te(174));return e}function tc(e,t){switch(it(Ao,t),it(Co,e),it(Ir,$o),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:Au(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=Au(t,e)}at(Ir),it(Ir,t)}function ki(){at(Ir),at(Co),at(Ao)}function _0(e){Rn(Ao.current);var t=Rn(Ir.current),r=Au(t,e.type);t!==r&&(it(Co,e),it(Ir,r))}function rc(e){Co.current===e&&(at(Ir),at(Co))}var st=_n(0);function ol(e){for(var t=e;t!==null;){if(t.tag===13){var r=t.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||r.data==="$?"||r.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ws=[];function nc(){for(var e=0;e<ws.length;e++)ws[e]._workInProgressVersionPrimary=null;ws.length=0}var La=Zr.ReactCurrentDispatcher,_s=Zr.ReactCurrentBatchConfig,In=0,ut=null,kt=null,Ct=null,al=!1,co=!1,No=0,sm=0;function Ot(){throw Error(te(321))}function ic(e,t){if(t===null)return!1;for(var r=0;r<t.length&&r<e.length;r++)if(!Ar(e[r],t[r]))return!1;return!0}function oc(e,t,r,n,i,o){if(In=o,ut=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,La.current=e===null||e.memoizedState===null?dm:hm,e=r(n,i),co){o=0;do{if(co=!1,No=0,25<=o)throw Error(te(301));o+=1,Ct=kt=null,t.updateQueue=null,La.current=pm,e=r(n,i)}while(co)}if(La.current=ll,t=kt!==null&&kt.next!==null,In=0,Ct=kt=ut=null,al=!1,t)throw Error(te(300));return e}function ac(){var e=No!==0;return No=0,e}function Br(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Ct===null?ut.memoizedState=Ct=e:Ct=Ct.next=e,Ct}function xr(){if(kt===null){var e=ut.alternate;e=e!==null?e.memoizedState:null}else e=kt.next;var t=Ct===null?ut.memoizedState:Ct.next;if(t!==null)Ct=t,kt=e;else{if(e===null)throw Error(te(310));kt=e,e={memoizedState:kt.memoizedState,baseState:kt.baseState,baseQueue:kt.baseQueue,queue:kt.queue,next:null},Ct===null?ut.memoizedState=Ct=e:Ct=Ct.next=e}return Ct}function Ro(e,t){return typeof t=="function"?t(e):t}function ks(e){var t=xr(),r=t.queue;if(r===null)throw Error(te(311));r.lastRenderedReducer=e;var n=kt,i=n.baseQueue,o=r.pending;if(o!==null){if(i!==null){var a=i.next;i.next=o.next,o.next=a}n.baseQueue=i=o,r.pending=null}if(i!==null){o=i.next,n=n.baseState;var s=a=null,u=null,d=o;do{var _=d.lane;if((In&_)===_)u!==null&&(u=u.next={lane:0,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null}),n=d.hasEagerState?d.eagerState:e(n,d.action);else{var m={lane:_,action:d.action,hasEagerState:d.hasEagerState,eagerState:d.eagerState,next:null};u===null?(s=u=m,a=n):u=u.next=m,ut.lanes|=_,Dn|=_}d=d.next}while(d!==null&&d!==o);u===null?a=n:u.next=s,Ar(n,t.memoizedState)||(Zt=!0),t.memoizedState=n,t.baseState=a,t.baseQueue=u,r.lastRenderedState=n}if(e=r.interleaved,e!==null){i=e;do o=i.lane,ut.lanes|=o,Dn|=o,i=i.next;while(i!==e)}else i===null&&(r.lanes=0);return[t.memoizedState,r.dispatch]}function Ss(e){var t=xr(),r=t.queue;if(r===null)throw Error(te(311));r.lastRenderedReducer=e;var n=r.dispatch,i=r.pending,o=t.memoizedState;if(i!==null){r.pending=null;var a=i=i.next;do o=e(o,a.action),a=a.next;while(a!==i);Ar(o,t.memoizedState)||(Zt=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),r.lastRenderedState=o}return[o,n]}function k0(){}function S0(e,t){var r=ut,n=xr(),i=t(),o=!Ar(n.memoizedState,i);if(o&&(n.memoizedState=i,Zt=!0),n=n.queue,lc(C0.bind(null,r,n,e),[e]),n.getSnapshot!==t||o||Ct!==null&&Ct.memoizedState.tag&1){if(r.flags|=2048,To(9,j0.bind(null,r,n,i,t),void 0,null),At===null)throw Error(te(349));In&30||E0(r,t,i)}return i}function E0(e,t,r){e.flags|=16384,e={getSnapshot:t,value:r},t=ut.updateQueue,t===null?(t={lastEffect:null,stores:null},ut.updateQueue=t,t.stores=[e]):(r=t.stores,r===null?t.stores=[e]:r.push(e))}function j0(e,t,r,n){t.value=r,t.getSnapshot=n,A0(t)&&N0(e)}function C0(e,t,r){return r(function(){A0(t)&&N0(e)})}function A0(e){var t=e.getSnapshot;e=e.value;try{var r=t();return!Ar(e,r)}catch{return!0}}function N0(e){var t=qr(e,1);t!==null&&Cr(t,e,1,-1)}function Ed(e){var t=Br();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Ro,lastRenderedState:e},t.queue=e,e=e.dispatch=cm.bind(null,ut,e),[t.memoizedState,e]}function To(e,t,r,n){return e={tag:e,create:t,destroy:r,deps:n,next:null},t=ut.updateQueue,t===null?(t={lastEffect:null,stores:null},ut.updateQueue=t,t.lastEffect=e.next=e):(r=t.lastEffect,r===null?t.lastEffect=e.next=e:(n=r.next,r.next=e,e.next=n,t.lastEffect=e)),e}function R0(){return xr().memoizedState}function Ba(e,t,r,n){var i=Br();ut.flags|=e,i.memoizedState=To(1|t,r,void 0,n===void 0?null:n)}function Cl(e,t,r,n){var i=xr();n=n===void 0?null:n;var o=void 0;if(kt!==null){var a=kt.memoizedState;if(o=a.destroy,n!==null&&ic(n,a.deps)){i.memoizedState=To(t,r,o,n);return}}ut.flags|=e,i.memoizedState=To(1|t,r,o,n)}function jd(e,t){return Ba(8390656,8,e,t)}function lc(e,t){return Cl(2048,8,e,t)}function T0(e,t){return Cl(4,2,e,t)}function L0(e,t){return Cl(4,4,e,t)}function B0(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function P0(e,t,r){return r=r!=null?r.concat([e]):null,Cl(4,4,B0.bind(null,t,e),r)}function sc(){}function M0(e,t){var r=xr();t=t===void 0?null:t;var n=r.memoizedState;return n!==null&&t!==null&&ic(t,n[1])?n[0]:(r.memoizedState=[e,t],e)}function O0(e,t){var r=xr();t=t===void 0?null:t;var n=r.memoizedState;return n!==null&&t!==null&&ic(t,n[1])?n[0]:(e=e(),r.memoizedState=[e,t],e)}function I0(e,t,r){return In&21?(Ar(r,t)||(r=$p(),ut.lanes|=r,Dn|=r,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,Zt=!0),e.memoizedState=r)}function um(e,t){var r=et;et=r!==0&&4>r?r:4,e(!0);var n=_s.transition;_s.transition={};try{e(!1),t()}finally{et=r,_s.transition=n}}function D0(){return xr().memoizedState}function fm(e,t,r){var n=gn(e);if(r={lane:n,action:r,hasEagerState:!1,eagerState:null,next:null},U0(e))F0(t,r);else if(r=b0(e,t,r,n),r!==null){var i=qt();Cr(r,e,n,i),z0(r,t,n)}}function cm(e,t,r){var n=gn(e),i={lane:n,action:r,hasEagerState:!1,eagerState:null,next:null};if(U0(e))F0(t,i);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var a=t.lastRenderedState,s=o(a,r);if(i.hasEagerState=!0,i.eagerState=s,Ar(s,a)){var u=t.interleaved;u===null?(i.next=i,Jf(t)):(i.next=u.next,u.next=i),t.interleaved=i;return}}catch{}finally{}r=b0(e,t,i,n),r!==null&&(i=qt(),Cr(r,e,n,i),z0(r,t,n))}}function U0(e){var t=e.alternate;return e===ut||t!==null&&t===ut}function F0(e,t){co=al=!0;var r=e.pending;r===null?t.next=t:(t.next=r.next,r.next=t),e.pending=t}function z0(e,t,r){if(r&4194240){var n=t.lanes;n&=e.pendingLanes,r|=n,t.lanes=r,Uf(e,r)}}var ll={readContext:mr,useCallback:Ot,useContext:Ot,useEffect:Ot,useImperativeHandle:Ot,useInsertionEffect:Ot,useLayoutEffect:Ot,useMemo:Ot,useReducer:Ot,useRef:Ot,useState:Ot,useDebugValue:Ot,useDeferredValue:Ot,useTransition:Ot,useMutableSource:Ot,useSyncExternalStore:Ot,useId:Ot,unstable_isNewReconciler:!1},dm={readContext:mr,useCallback:function(e,t){return Br().memoizedState=[e,t===void 0?null:t],e},useContext:mr,useEffect:jd,useImperativeHandle:function(e,t,r){return r=r!=null?r.concat([e]):null,Ba(4194308,4,B0.bind(null,t,e),r)},useLayoutEffect:function(e,t){return Ba(4194308,4,e,t)},useInsertionEffect:function(e,t){return Ba(4,2,e,t)},useMemo:function(e,t){var r=Br();return t=t===void 0?null:t,e=e(),r.memoizedState=[e,t],e},useReducer:function(e,t,r){var n=Br();return t=r!==void 0?r(t):t,n.memoizedState=n.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},n.queue=e,e=e.dispatch=fm.bind(null,ut,e),[n.memoizedState,e]},useRef:function(e){var t=Br();return e={current:e},t.memoizedState=e},useState:Ed,useDebugValue:sc,useDeferredValue:function(e){return Br().memoizedState=e},useTransition:function(){var e=Ed(!1),t=e[0];return e=um.bind(null,e[1]),Br().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,r){var n=ut,i=Br();if(lt){if(r===void 0)throw Error(te(407));r=r()}else{if(r=t(),At===null)throw Error(te(349));In&30||E0(n,t,r)}i.memoizedState=r;var o={value:r,getSnapshot:t};return i.queue=o,jd(C0.bind(null,n,o,e),[e]),n.flags|=2048,To(9,j0.bind(null,n,o,r,t),void 0,null),r},useId:function(){var e=Br(),t=At.identifierPrefix;if(lt){var r=Hr,n=$r;r=(n&~(1<<32-jr(n)-1)).toString(32)+r,t=":"+t+"R"+r,r=No++,0<r&&(t+="H"+r.toString(32)),t+=":"}else r=sm++,t=":"+t+"r"+r.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},hm={readContext:mr,useCallback:M0,useContext:mr,useEffect:lc,useImperativeHandle:P0,useInsertionEffect:T0,useLayoutEffect:L0,useMemo:O0,useReducer:ks,useRef:R0,useState:function(){return ks(Ro)},useDebugValue:sc,useDeferredValue:function(e){var t=xr();return I0(t,kt.memoizedState,e)},useTransition:function(){var e=ks(Ro)[0],t=xr().memoizedState;return[e,t]},useMutableSource:k0,useSyncExternalStore:S0,useId:D0,unstable_isNewReconciler:!1},pm={readContext:mr,useCallback:M0,useContext:mr,useEffect:lc,useImperativeHandle:P0,useInsertionEffect:T0,useLayoutEffect:L0,useMemo:O0,useReducer:Ss,useRef:R0,useState:function(){return Ss(Ro)},useDebugValue:sc,useDeferredValue:function(e){var t=xr();return kt===null?t.memoizedState=e:I0(t,kt.memoizedState,e)},useTransition:function(){var e=Ss(Ro)[0],t=xr().memoizedState;return[e,t]},useMutableSource:k0,useSyncExternalStore:S0,useId:D0,unstable_isNewReconciler:!1};function kr(e,t){if(e&&e.defaultProps){t=ft({},t),e=e.defaultProps;for(var r in e)t[r]===void 0&&(t[r]=e[r]);return t}return t}function Yu(e,t,r,n){t=e.memoizedState,r=r(n,t),r=r==null?t:ft({},t,r),e.memoizedState=r,e.lanes===0&&(e.updateQueue.baseState=r)}var Al={isMounted:function(e){return(e=e._reactInternals)?$n(e)===e:!1},enqueueSetState:function(e,t,r){e=e._reactInternals;var n=qt(),i=gn(e),o=Wr(n,i);o.payload=t,r!=null&&(o.callback=r),t=vn(e,o,i),t!==null&&(Cr(t,e,i,n),Ta(t,e,i))},enqueueReplaceState:function(e,t,r){e=e._reactInternals;var n=qt(),i=gn(e),o=Wr(n,i);o.tag=1,o.payload=t,r!=null&&(o.callback=r),t=vn(e,o,i),t!==null&&(Cr(t,e,i,n),Ta(t,e,i))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var r=qt(),n=gn(e),i=Wr(r,n);i.tag=2,t!=null&&(i.callback=t),t=vn(e,i,n),t!==null&&(Cr(t,e,n,r),Ta(t,e,n))}};function Cd(e,t,r,n,i,o,a){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(n,o,a):t.prototype&&t.prototype.isPureReactComponent?!ko(r,n)||!ko(i,o):!0}function $0(e,t,r){var n=!1,i=bn,o=t.contextType;return typeof o=="object"&&o!==null?o=mr(o):(i=er(t)?Mn:Ht.current,n=t.contextTypes,o=(n=n!=null)?bi(e,i):bn),t=new t(r,o),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=Al,e.stateNode=t,t._reactInternals=e,n&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=i,e.__reactInternalMemoizedMaskedChildContext=o),t}function Ad(e,t,r,n){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(r,n),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(r,n),t.state!==e&&Al.enqueueReplaceState(t,t.state,null)}function Qu(e,t,r,n){var i=e.stateNode;i.props=r,i.state=e.memoizedState,i.refs={},ec(e);var o=t.contextType;typeof o=="object"&&o!==null?i.context=mr(o):(o=er(t)?Mn:Ht.current,i.context=bi(e,o)),i.state=e.memoizedState,o=t.getDerivedStateFromProps,typeof o=="function"&&(Yu(e,t,o,r),i.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof i.getSnapshotBeforeUpdate=="function"||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(t=i.state,typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount(),t!==i.state&&Al.enqueueReplaceState(i,i.state,null),il(e,r,i,n),i.state=e.memoizedState),typeof i.componentDidMount=="function"&&(e.flags|=4194308)}function Si(e,t){try{var r="",n=t;do r+=$y(n),n=n.return;while(n);var i=r}catch(o){i=`
Error generating stack: `+o.message+`
`+o.stack}return{value:e,source:t,stack:i,digest:null}}function Es(e,t,r){return{value:e,source:null,stack:r??null,digest:t??null}}function Xu(e,t){try{console.error(t.value)}catch(r){setTimeout(function(){throw r})}}var vm=typeof WeakMap=="function"?WeakMap:Map;function H0(e,t,r){r=Wr(-1,r),r.tag=3,r.payload={element:null};var n=t.value;return r.callback=function(){ul||(ul=!0,sf=n),Xu(e,t)},r}function W0(e,t,r){r=Wr(-1,r),r.tag=3;var n=e.type.getDerivedStateFromError;if(typeof n=="function"){var i=t.value;r.payload=function(){return n(i)},r.callback=function(){Xu(e,t)}}var o=e.stateNode;return o!==null&&typeof o.componentDidCatch=="function"&&(r.callback=function(){Xu(e,t),typeof n!="function"&&(yn===null?yn=new Set([this]):yn.add(this));var a=t.stack;this.componentDidCatch(t.value,{componentStack:a!==null?a:""})}),r}function Nd(e,t,r){var n=e.pingCache;if(n===null){n=e.pingCache=new vm;var i=new Set;n.set(t,i)}else i=n.get(t),i===void 0&&(i=new Set,n.set(t,i));i.has(r)||(i.add(r),e=Nm.bind(null,e,t,r),t.then(e,e))}function Rd(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function Td(e,t,r,n,i){return e.mode&1?(e.flags|=65536,e.lanes=i,e):(e===t?e.flags|=65536:(e.flags|=128,r.flags|=131072,r.flags&=-52805,r.tag===1&&(r.alternate===null?r.tag=17:(t=Wr(-1,1),t.tag=2,vn(r,t,1))),r.lanes|=1),e)}var ym=Zr.ReactCurrentOwner,Zt=!1;function Kt(e,t,r,n){t.child=e===null?x0(t,null,r,n):_i(t,e.child,r,n)}function Ld(e,t,r,n,i){r=r.render;var o=t.ref;return pi(t,i),n=oc(e,t,r,n,o,i),r=ac(),e!==null&&!Zt?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,Gr(e,t,i)):(lt&&r&&qf(t),t.flags|=1,Kt(e,t,n,i),t.child)}function Bd(e,t,r,n,i){if(e===null){var o=r.type;return typeof o=="function"&&!yc(o)&&o.defaultProps===void 0&&r.compare===null&&r.defaultProps===void 0?(t.tag=15,t.type=o,V0(e,t,o,n,i)):(e=Ia(r.type,null,n,t,t.mode,i),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!(e.lanes&i)){var a=o.memoizedProps;if(r=r.compare,r=r!==null?r:ko,r(a,n)&&e.ref===t.ref)return Gr(e,t,i)}return t.flags|=1,e=mn(o,n),e.ref=t.ref,e.return=t,t.child=e}function V0(e,t,r,n,i){if(e!==null){var o=e.memoizedProps;if(ko(o,n)&&e.ref===t.ref)if(Zt=!1,t.pendingProps=n=o,(e.lanes&i)!==0)e.flags&131072&&(Zt=!0);else return t.lanes=e.lanes,Gr(e,t,i)}return Zu(e,t,r,n,i)}function K0(e,t,r){var n=t.pendingProps,i=n.children,o=e!==null?e.memoizedState:null;if(n.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},it(ui,or),or|=r;else{if(!(r&1073741824))return e=o!==null?o.baseLanes|r:r,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,it(ui,or),or|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},n=o!==null?o.baseLanes:r,it(ui,or),or|=n}else o!==null?(n=o.baseLanes|r,t.memoizedState=null):n=r,it(ui,or),or|=n;return Kt(e,t,i,r),t.child}function q0(e,t){var r=t.ref;(e===null&&r!==null||e!==null&&e.ref!==r)&&(t.flags|=512,t.flags|=2097152)}function Zu(e,t,r,n,i){var o=er(r)?Mn:Ht.current;return o=bi(t,o),pi(t,i),r=oc(e,t,r,n,o,i),n=ac(),e!==null&&!Zt?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~i,Gr(e,t,i)):(lt&&n&&qf(t),t.flags|=1,Kt(e,t,r,i),t.child)}function Pd(e,t,r,n,i){if(er(r)){var o=!0;Ja(t)}else o=!1;if(pi(t,i),t.stateNode===null)Pa(e,t),$0(t,r,n),Qu(t,r,n,i),n=!0;else if(e===null){var a=t.stateNode,s=t.memoizedProps;a.props=s;var u=a.context,d=r.contextType;typeof d=="object"&&d!==null?d=mr(d):(d=er(r)?Mn:Ht.current,d=bi(t,d));var _=r.getDerivedStateFromProps,m=typeof _=="function"||typeof a.getSnapshotBeforeUpdate=="function";m||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(s!==n||u!==d)&&Ad(t,a,n,d),an=!1;var E=t.memoizedState;a.state=E,il(t,n,a,i),u=t.memoizedState,s!==n||E!==u||Jt.current||an?(typeof _=="function"&&(Yu(t,r,_,n),u=t.memoizedState),(s=an||Cd(t,r,s,n,E,u,d))?(m||typeof a.UNSAFE_componentWillMount!="function"&&typeof a.componentWillMount!="function"||(typeof a.componentWillMount=="function"&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount=="function"&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount=="function"&&(t.flags|=4194308)):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=n,t.memoizedState=u),a.props=n,a.state=u,a.context=d,n=s):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),n=!1)}else{a=t.stateNode,w0(e,t),s=t.memoizedProps,d=t.type===t.elementType?s:kr(t.type,s),a.props=d,m=t.pendingProps,E=a.context,u=r.contextType,typeof u=="object"&&u!==null?u=mr(u):(u=er(r)?Mn:Ht.current,u=bi(t,u));var B=r.getDerivedStateFromProps;(_=typeof B=="function"||typeof a.getSnapshotBeforeUpdate=="function")||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(s!==m||E!==u)&&Ad(t,a,n,u),an=!1,E=t.memoizedState,a.state=E,il(t,n,a,i);var R=t.memoizedState;s!==m||E!==R||Jt.current||an?(typeof B=="function"&&(Yu(t,r,B,n),R=t.memoizedState),(d=an||Cd(t,r,d,n,E,R,u)||!1)?(_||typeof a.UNSAFE_componentWillUpdate!="function"&&typeof a.componentWillUpdate!="function"||(typeof a.componentWillUpdate=="function"&&a.componentWillUpdate(n,R,u),typeof a.UNSAFE_componentWillUpdate=="function"&&a.UNSAFE_componentWillUpdate(n,R,u)),typeof a.componentDidUpdate=="function"&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof a.componentDidUpdate!="function"||s===e.memoizedProps&&E===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&E===e.memoizedState||(t.flags|=1024),t.memoizedProps=n,t.memoizedState=R),a.props=n,a.state=R,a.context=u,n=d):(typeof a.componentDidUpdate!="function"||s===e.memoizedProps&&E===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||s===e.memoizedProps&&E===e.memoizedState||(t.flags|=1024),n=!1)}return Ju(e,t,r,n,o,i)}function Ju(e,t,r,n,i,o){q0(e,t);var a=(t.flags&128)!==0;if(!n&&!a)return i&&xd(t,r,!1),Gr(e,t,o);n=t.stateNode,ym.current=t;var s=a&&typeof r.getDerivedStateFromError!="function"?null:n.render();return t.flags|=1,e!==null&&a?(t.child=_i(t,e.child,null,o),t.child=_i(t,null,s,o)):Kt(e,t,s,o),t.memoizedState=n.state,i&&xd(t,r,!0),t.child}function G0(e){var t=e.stateNode;t.pendingContext?md(e,t.pendingContext,t.pendingContext!==t.context):t.context&&md(e,t.context,!1),tc(e,t.containerInfo)}function Md(e,t,r,n,i){return wi(),Yf(i),t.flags|=256,Kt(e,t,r,n),t.child}var ef={dehydrated:null,treeContext:null,retryLane:0};function tf(e){return{baseLanes:e,cachePool:null,transitions:null}}function Y0(e,t,r){var n=t.pendingProps,i=st.current,o=!1,a=(t.flags&128)!==0,s;if((s=a)||(s=e!==null&&e.memoizedState===null?!1:(i&2)!==0),s?(o=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(i|=1),it(st,i&1),e===null)return qu(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(a=n.children,e=n.fallback,o?(n=t.mode,o=t.child,a={mode:"hidden",children:a},!(n&1)&&o!==null?(o.childLanes=0,o.pendingProps=a):o=Tl(a,n,0,null),e=Bn(e,n,r,null),o.return=t,e.return=t,o.sibling=e,t.child=o,t.child.memoizedState=tf(r),t.memoizedState=ef,e):uc(t,a));if(i=e.memoizedState,i!==null&&(s=i.dehydrated,s!==null))return gm(e,t,a,n,s,i,r);if(o){o=n.fallback,a=t.mode,i=e.child,s=i.sibling;var u={mode:"hidden",children:n.children};return!(a&1)&&t.child!==i?(n=t.child,n.childLanes=0,n.pendingProps=u,t.deletions=null):(n=mn(i,u),n.subtreeFlags=i.subtreeFlags&14680064),s!==null?o=mn(s,o):(o=Bn(o,a,r,null),o.flags|=2),o.return=t,n.return=t,n.sibling=o,t.child=n,n=o,o=t.child,a=e.child.memoizedState,a=a===null?tf(r):{baseLanes:a.baseLanes|r,cachePool:null,transitions:a.transitions},o.memoizedState=a,o.childLanes=e.childLanes&~r,t.memoizedState=ef,n}return o=e.child,e=o.sibling,n=mn(o,{mode:"visible",children:n.children}),!(t.mode&1)&&(n.lanes=r),n.return=t,n.sibling=null,e!==null&&(r=t.deletions,r===null?(t.deletions=[e],t.flags|=16):r.push(e)),t.child=n,t.memoizedState=null,n}function uc(e,t){return t=Tl({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function ga(e,t,r,n){return n!==null&&Yf(n),_i(t,e.child,null,r),e=uc(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function gm(e,t,r,n,i,o,a){if(r)return t.flags&256?(t.flags&=-257,n=Es(Error(te(422))),ga(e,t,a,n)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(o=n.fallback,i=t.mode,n=Tl({mode:"visible",children:n.children},i,0,null),o=Bn(o,i,a,null),o.flags|=2,n.return=t,o.return=t,n.sibling=o,t.child=n,t.mode&1&&_i(t,e.child,null,a),t.child.memoizedState=tf(a),t.memoizedState=ef,o);if(!(t.mode&1))return ga(e,t,a,null);if(i.data==="$!"){if(n=i.nextSibling&&i.nextSibling.dataset,n)var s=n.dgst;return n=s,o=Error(te(419)),n=Es(o,n,void 0),ga(e,t,a,n)}if(s=(a&e.childLanes)!==0,Zt||s){if(n=At,n!==null){switch(a&-a){case 4:i=2;break;case 16:i=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:i=32;break;case 536870912:i=268435456;break;default:i=0}i=i&(n.suspendedLanes|a)?0:i,i!==0&&i!==o.retryLane&&(o.retryLane=i,qr(e,i),Cr(n,e,i,-1))}return vc(),n=Es(Error(te(421))),ga(e,t,a,n)}return i.data==="$?"?(t.flags|=128,t.child=e.child,t=Rm.bind(null,e),i._reactRetry=t,null):(e=o.treeContext,ar=pn(i.nextSibling),lr=t,lt=!0,Er=null,e!==null&&(hr[pr++]=$r,hr[pr++]=Hr,hr[pr++]=On,$r=e.id,Hr=e.overflow,On=t),t=uc(t,n.children),t.flags|=4096,t)}function Od(e,t,r){e.lanes|=t;var n=e.alternate;n!==null&&(n.lanes|=t),Gu(e.return,t,r)}function js(e,t,r,n,i){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:n,tail:r,tailMode:i}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=n,o.tail=r,o.tailMode=i)}function Q0(e,t,r){var n=t.pendingProps,i=n.revealOrder,o=n.tail;if(Kt(e,t,n.children,r),n=st.current,n&2)n=n&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Od(e,r,t);else if(e.tag===19)Od(e,r,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}n&=1}if(it(st,n),!(t.mode&1))t.memoizedState=null;else switch(i){case"forwards":for(r=t.child,i=null;r!==null;)e=r.alternate,e!==null&&ol(e)===null&&(i=r),r=r.sibling;r=i,r===null?(i=t.child,t.child=null):(i=r.sibling,r.sibling=null),js(t,!1,i,r,o);break;case"backwards":for(r=null,i=t.child,t.child=null;i!==null;){if(e=i.alternate,e!==null&&ol(e)===null){t.child=i;break}e=i.sibling,i.sibling=r,r=i,i=e}js(t,!0,r,null,o);break;case"together":js(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function Pa(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function Gr(e,t,r){if(e!==null&&(t.dependencies=e.dependencies),Dn|=t.lanes,!(r&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(te(153));if(t.child!==null){for(e=t.child,r=mn(e,e.pendingProps),t.child=r,r.return=t;e.sibling!==null;)e=e.sibling,r=r.sibling=mn(e,e.pendingProps),r.return=t;r.sibling=null}return t.child}function mm(e,t,r){switch(t.tag){case 3:G0(t),wi();break;case 5:_0(t);break;case 1:er(t.type)&&Ja(t);break;case 4:tc(t,t.stateNode.containerInfo);break;case 10:var n=t.type._context,i=t.memoizedProps.value;it(rl,n._currentValue),n._currentValue=i;break;case 13:if(n=t.memoizedState,n!==null)return n.dehydrated!==null?(it(st,st.current&1),t.flags|=128,null):r&t.child.childLanes?Y0(e,t,r):(it(st,st.current&1),e=Gr(e,t,r),e!==null?e.sibling:null);it(st,st.current&1);break;case 19:if(n=(r&t.childLanes)!==0,e.flags&128){if(n)return Q0(e,t,r);t.flags|=128}if(i=t.memoizedState,i!==null&&(i.rendering=null,i.tail=null,i.lastEffect=null),it(st,st.current),n)break;return null;case 22:case 23:return t.lanes=0,K0(e,t,r)}return Gr(e,t,r)}var X0,rf,Z0,J0;X0=function(e,t){for(var r=t.child;r!==null;){if(r.tag===5||r.tag===6)e.appendChild(r.stateNode);else if(r.tag!==4&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===t)break;for(;r.sibling===null;){if(r.return===null||r.return===t)return;r=r.return}r.sibling.return=r.return,r=r.sibling}};rf=function(){};Z0=function(e,t,r,n){var i=e.memoizedProps;if(i!==n){e=t.stateNode,Rn(Ir.current);var o=null;switch(r){case"input":i=Su(e,i),n=Su(e,n),o=[];break;case"select":i=ft({},i,{value:void 0}),n=ft({},n,{value:void 0}),o=[];break;case"textarea":i=Cu(e,i),n=Cu(e,n),o=[];break;default:typeof i.onClick!="function"&&typeof n.onClick=="function"&&(e.onclick=Xa)}Nu(r,n);var a;r=null;for(d in i)if(!n.hasOwnProperty(d)&&i.hasOwnProperty(d)&&i[d]!=null)if(d==="style"){var s=i[d];for(a in s)s.hasOwnProperty(a)&&(r||(r={}),r[a]="")}else d!=="dangerouslySetInnerHTML"&&d!=="children"&&d!=="suppressContentEditableWarning"&&d!=="suppressHydrationWarning"&&d!=="autoFocus"&&(yo.hasOwnProperty(d)?o||(o=[]):(o=o||[]).push(d,null));for(d in n){var u=n[d];if(s=i!=null?i[d]:void 0,n.hasOwnProperty(d)&&u!==s&&(u!=null||s!=null))if(d==="style")if(s){for(a in s)!s.hasOwnProperty(a)||u&&u.hasOwnProperty(a)||(r||(r={}),r[a]="");for(a in u)u.hasOwnProperty(a)&&s[a]!==u[a]&&(r||(r={}),r[a]=u[a])}else r||(o||(o=[]),o.push(d,r)),r=u;else d==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,s=s?s.__html:void 0,u!=null&&s!==u&&(o=o||[]).push(d,u)):d==="children"?typeof u!="string"&&typeof u!="number"||(o=o||[]).push(d,""+u):d!=="suppressContentEditableWarning"&&d!=="suppressHydrationWarning"&&(yo.hasOwnProperty(d)?(u!=null&&d==="onScroll"&&ot("scroll",e),o||s===u||(o=[])):(o=o||[]).push(d,u))}r&&(o=o||[]).push("style",r);var d=o;(t.updateQueue=d)&&(t.flags|=4)}};J0=function(e,t,r,n){r!==n&&(t.flags|=4)};function Ki(e,t){if(!lt)switch(e.tailMode){case"hidden":t=e.tail;for(var r=null;t!==null;)t.alternate!==null&&(r=t),t=t.sibling;r===null?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var n=null;r!==null;)r.alternate!==null&&(n=r),r=r.sibling;n===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:n.sibling=null}}function It(e){var t=e.alternate!==null&&e.alternate.child===e.child,r=0,n=0;if(t)for(var i=e.child;i!==null;)r|=i.lanes|i.childLanes,n|=i.subtreeFlags&14680064,n|=i.flags&14680064,i.return=e,i=i.sibling;else for(i=e.child;i!==null;)r|=i.lanes|i.childLanes,n|=i.subtreeFlags,n|=i.flags,i.return=e,i=i.sibling;return e.subtreeFlags|=n,e.childLanes=r,t}function xm(e,t,r){var n=t.pendingProps;switch(Gf(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return It(t),null;case 1:return er(t.type)&&Za(),It(t),null;case 3:return n=t.stateNode,ki(),at(Jt),at(Ht),nc(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(e===null||e.child===null)&&(va(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Er!==null&&(cf(Er),Er=null))),rf(e,t),It(t),null;case 5:rc(t);var i=Rn(Ao.current);if(r=t.type,e!==null&&t.stateNode!=null)Z0(e,t,r,n,i),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!n){if(t.stateNode===null)throw Error(te(166));return It(t),null}if(e=Rn(Ir.current),va(t)){n=t.stateNode,r=t.type;var o=t.memoizedProps;switch(n[Mr]=t,n[jo]=o,e=(t.mode&1)!==0,r){case"dialog":ot("cancel",n),ot("close",n);break;case"iframe":case"object":case"embed":ot("load",n);break;case"video":case"audio":for(i=0;i<io.length;i++)ot(io[i],n);break;case"source":ot("error",n);break;case"img":case"image":case"link":ot("error",n),ot("load",n);break;case"details":ot("toggle",n);break;case"input":Vc(n,o),ot("invalid",n);break;case"select":n._wrapperState={wasMultiple:!!o.multiple},ot("invalid",n);break;case"textarea":qc(n,o),ot("invalid",n)}Nu(r,o),i=null;for(var a in o)if(o.hasOwnProperty(a)){var s=o[a];a==="children"?typeof s=="string"?n.textContent!==s&&(o.suppressHydrationWarning!==!0&&pa(n.textContent,s,e),i=["children",s]):typeof s=="number"&&n.textContent!==""+s&&(o.suppressHydrationWarning!==!0&&pa(n.textContent,s,e),i=["children",""+s]):yo.hasOwnProperty(a)&&s!=null&&a==="onScroll"&&ot("scroll",n)}switch(r){case"input":aa(n),Kc(n,o,!0);break;case"textarea":aa(n),Gc(n);break;case"select":case"option":break;default:typeof o.onClick=="function"&&(n.onclick=Xa)}n=i,t.updateQueue=n,n!==null&&(t.flags|=4)}else{a=i.nodeType===9?i:i.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=Cp(r)),e==="http://www.w3.org/1999/xhtml"?r==="script"?(e=a.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof n.is=="string"?e=a.createElement(r,{is:n.is}):(e=a.createElement(r),r==="select"&&(a=e,n.multiple?a.multiple=!0:n.size&&(a.size=n.size))):e=a.createElementNS(e,r),e[Mr]=t,e[jo]=n,X0(e,t,!1,!1),t.stateNode=e;e:{switch(a=Ru(r,n),r){case"dialog":ot("cancel",e),ot("close",e),i=n;break;case"iframe":case"object":case"embed":ot("load",e),i=n;break;case"video":case"audio":for(i=0;i<io.length;i++)ot(io[i],e);i=n;break;case"source":ot("error",e),i=n;break;case"img":case"image":case"link":ot("error",e),ot("load",e),i=n;break;case"details":ot("toggle",e),i=n;break;case"input":Vc(e,n),i=Su(e,n),ot("invalid",e);break;case"option":i=n;break;case"select":e._wrapperState={wasMultiple:!!n.multiple},i=ft({},n,{value:void 0}),ot("invalid",e);break;case"textarea":qc(e,n),i=Cu(e,n),ot("invalid",e);break;default:i=n}Nu(r,i),s=i;for(o in s)if(s.hasOwnProperty(o)){var u=s[o];o==="style"?Rp(e,u):o==="dangerouslySetInnerHTML"?(u=u?u.__html:void 0,u!=null&&Ap(e,u)):o==="children"?typeof u=="string"?(r!=="textarea"||u!=="")&&go(e,u):typeof u=="number"&&go(e,""+u):o!=="suppressContentEditableWarning"&&o!=="suppressHydrationWarning"&&o!=="autoFocus"&&(yo.hasOwnProperty(o)?u!=null&&o==="onScroll"&&ot("scroll",e):u!=null&&Bf(e,o,u,a))}switch(r){case"input":aa(e),Kc(e,n,!1);break;case"textarea":aa(e),Gc(e);break;case"option":n.value!=null&&e.setAttribute("value",""+xn(n.value));break;case"select":e.multiple=!!n.multiple,o=n.value,o!=null?fi(e,!!n.multiple,o,!1):n.defaultValue!=null&&fi(e,!!n.multiple,n.defaultValue,!0);break;default:typeof i.onClick=="function"&&(e.onclick=Xa)}switch(r){case"button":case"input":case"select":case"textarea":n=!!n.autoFocus;break e;case"img":n=!0;break e;default:n=!1}}n&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return It(t),null;case 6:if(e&&t.stateNode!=null)J0(e,t,e.memoizedProps,n);else{if(typeof n!="string"&&t.stateNode===null)throw Error(te(166));if(r=Rn(Ao.current),Rn(Ir.current),va(t)){if(n=t.stateNode,r=t.memoizedProps,n[Mr]=t,(o=n.nodeValue!==r)&&(e=lr,e!==null))switch(e.tag){case 3:pa(n.nodeValue,r,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&pa(n.nodeValue,r,(e.mode&1)!==0)}o&&(t.flags|=4)}else n=(r.nodeType===9?r:r.ownerDocument).createTextNode(n),n[Mr]=t,t.stateNode=n}return It(t),null;case 13:if(at(st),n=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(lt&&ar!==null&&t.mode&1&&!(t.flags&128))g0(),wi(),t.flags|=98560,o=!1;else if(o=va(t),n!==null&&n.dehydrated!==null){if(e===null){if(!o)throw Error(te(318));if(o=t.memoizedState,o=o!==null?o.dehydrated:null,!o)throw Error(te(317));o[Mr]=t}else wi(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;It(t),o=!1}else Er!==null&&(cf(Er),Er=null),o=!0;if(!o)return t.flags&65536?t:null}return t.flags&128?(t.lanes=r,t):(n=n!==null,n!==(e!==null&&e.memoizedState!==null)&&n&&(t.child.flags|=8192,t.mode&1&&(e===null||st.current&1?St===0&&(St=3):vc())),t.updateQueue!==null&&(t.flags|=4),It(t),null);case 4:return ki(),rf(e,t),e===null&&So(t.stateNode.containerInfo),It(t),null;case 10:return Zf(t.type._context),It(t),null;case 17:return er(t.type)&&Za(),It(t),null;case 19:if(at(st),o=t.memoizedState,o===null)return It(t),null;if(n=(t.flags&128)!==0,a=o.rendering,a===null)if(n)Ki(o,!1);else{if(St!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(a=ol(e),a!==null){for(t.flags|=128,Ki(o,!1),n=a.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),t.subtreeFlags=0,n=r,r=t.child;r!==null;)o=r,e=n,o.flags&=14680066,a=o.alternate,a===null?(o.childLanes=0,o.lanes=e,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=a.childLanes,o.lanes=a.lanes,o.child=a.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=a.memoizedProps,o.memoizedState=a.memoizedState,o.updateQueue=a.updateQueue,o.type=a.type,e=a.dependencies,o.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),r=r.sibling;return it(st,st.current&1|2),t.child}e=e.sibling}o.tail!==null&&xt()>Ei&&(t.flags|=128,n=!0,Ki(o,!1),t.lanes=4194304)}else{if(!n)if(e=ol(a),e!==null){if(t.flags|=128,n=!0,r=e.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),Ki(o,!0),o.tail===null&&o.tailMode==="hidden"&&!a.alternate&&!lt)return It(t),null}else 2*xt()-o.renderingStartTime>Ei&&r!==1073741824&&(t.flags|=128,n=!0,Ki(o,!1),t.lanes=4194304);o.isBackwards?(a.sibling=t.child,t.child=a):(r=o.last,r!==null?r.sibling=a:t.child=a,o.last=a)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=xt(),t.sibling=null,r=st.current,it(st,n?r&1|2:r&1),t):(It(t),null);case 22:case 23:return pc(),n=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==n&&(t.flags|=8192),n&&t.mode&1?or&1073741824&&(It(t),t.subtreeFlags&6&&(t.flags|=8192)):It(t),null;case 24:return null;case 25:return null}throw Error(te(156,t.tag))}function bm(e,t){switch(Gf(t),t.tag){case 1:return er(t.type)&&Za(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ki(),at(Jt),at(Ht),nc(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return rc(t),null;case 13:if(at(st),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(te(340));wi()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return at(st),null;case 4:return ki(),null;case 10:return Zf(t.type._context),null;case 22:case 23:return pc(),null;case 24:return null;default:return null}}var ma=!1,$t=!1,wm=typeof WeakSet=="function"?WeakSet:Set,fe=null;function si(e,t){var r=e.ref;if(r!==null)if(typeof r=="function")try{r(null)}catch(n){vt(e,t,n)}else r.current=null}function nf(e,t,r){try{r()}catch(n){vt(e,t,n)}}var Id=!1;function _m(e,t){if(Fu=Ga,e=i0(),Kf(e)){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else e:{r=(r=e.ownerDocument)&&r.defaultView||window;var n=r.getSelection&&r.getSelection();if(n&&n.rangeCount!==0){r=n.anchorNode;var i=n.anchorOffset,o=n.focusNode;n=n.focusOffset;try{r.nodeType,o.nodeType}catch{r=null;break e}var a=0,s=-1,u=-1,d=0,_=0,m=e,E=null;t:for(;;){for(var B;m!==r||i!==0&&m.nodeType!==3||(s=a+i),m!==o||n!==0&&m.nodeType!==3||(u=a+n),m.nodeType===3&&(a+=m.nodeValue.length),(B=m.firstChild)!==null;)E=m,m=B;for(;;){if(m===e)break t;if(E===r&&++d===i&&(s=a),E===o&&++_===n&&(u=a),(B=m.nextSibling)!==null)break;m=E,E=m.parentNode}m=B}r=s===-1||u===-1?null:{start:s,end:u}}else r=null}r=r||{start:0,end:0}}else r=null;for(zu={focusedElem:e,selectionRange:r},Ga=!1,fe=t;fe!==null;)if(t=fe,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,fe=e;else for(;fe!==null;){t=fe;try{var R=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(R!==null){var N=R.memoizedProps,P=R.memoizedState,p=t.stateNode,v=p.getSnapshotBeforeUpdate(t.elementType===t.type?N:kr(t.type,N),P);p.__reactInternalSnapshotBeforeUpdate=v}break;case 3:var x=t.stateNode.containerInfo;x.nodeType===1?x.textContent="":x.nodeType===9&&x.documentElement&&x.removeChild(x.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(te(163))}}catch(C){vt(t,t.return,C)}if(e=t.sibling,e!==null){e.return=t.return,fe=e;break}fe=t.return}return R=Id,Id=!1,R}function ho(e,t,r){var n=t.updateQueue;if(n=n!==null?n.lastEffect:null,n!==null){var i=n=n.next;do{if((i.tag&e)===e){var o=i.destroy;i.destroy=void 0,o!==void 0&&nf(t,r,o)}i=i.next}while(i!==n)}}function Nl(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var r=t=t.next;do{if((r.tag&e)===e){var n=r.create;r.destroy=n()}r=r.next}while(r!==t)}}function of(e){var t=e.ref;if(t!==null){var r=e.stateNode;switch(e.tag){case 5:e=r;break;default:e=r}typeof t=="function"?t(e):t.current=e}}function ev(e){var t=e.alternate;t!==null&&(e.alternate=null,ev(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Mr],delete t[jo],delete t[Wu],delete t[im],delete t[om])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function tv(e){return e.tag===5||e.tag===3||e.tag===4}function Dd(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||tv(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function af(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?r.nodeType===8?r.parentNode.insertBefore(e,t):r.insertBefore(e,t):(r.nodeType===8?(t=r.parentNode,t.insertBefore(e,r)):(t=r,t.appendChild(e)),r=r._reactRootContainer,r!=null||t.onclick!==null||(t.onclick=Xa));else if(n!==4&&(e=e.child,e!==null))for(af(e,t,r),e=e.sibling;e!==null;)af(e,t,r),e=e.sibling}function lf(e,t,r){var n=e.tag;if(n===5||n===6)e=e.stateNode,t?r.insertBefore(e,t):r.appendChild(e);else if(n!==4&&(e=e.child,e!==null))for(lf(e,t,r),e=e.sibling;e!==null;)lf(e,t,r),e=e.sibling}var Rt=null,Sr=!1;function Jr(e,t,r){for(r=r.child;r!==null;)rv(e,t,r),r=r.sibling}function rv(e,t,r){if(Or&&typeof Or.onCommitFiberUnmount=="function")try{Or.onCommitFiberUnmount(wl,r)}catch{}switch(r.tag){case 5:$t||si(r,t);case 6:var n=Rt,i=Sr;Rt=null,Jr(e,t,r),Rt=n,Sr=i,Rt!==null&&(Sr?(e=Rt,r=r.stateNode,e.nodeType===8?e.parentNode.removeChild(r):e.removeChild(r)):Rt.removeChild(r.stateNode));break;case 18:Rt!==null&&(Sr?(e=Rt,r=r.stateNode,e.nodeType===8?xs(e.parentNode,r):e.nodeType===1&&xs(e,r),wo(e)):xs(Rt,r.stateNode));break;case 4:n=Rt,i=Sr,Rt=r.stateNode.containerInfo,Sr=!0,Jr(e,t,r),Rt=n,Sr=i;break;case 0:case 11:case 14:case 15:if(!$t&&(n=r.updateQueue,n!==null&&(n=n.lastEffect,n!==null))){i=n=n.next;do{var o=i,a=o.destroy;o=o.tag,a!==void 0&&(o&2||o&4)&&nf(r,t,a),i=i.next}while(i!==n)}Jr(e,t,r);break;case 1:if(!$t&&(si(r,t),n=r.stateNode,typeof n.componentWillUnmount=="function"))try{n.props=r.memoizedProps,n.state=r.memoizedState,n.componentWillUnmount()}catch(s){vt(r,t,s)}Jr(e,t,r);break;case 21:Jr(e,t,r);break;case 22:r.mode&1?($t=(n=$t)||r.memoizedState!==null,Jr(e,t,r),$t=n):Jr(e,t,r);break;default:Jr(e,t,r)}}function Ud(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var r=e.stateNode;r===null&&(r=e.stateNode=new wm),t.forEach(function(n){var i=Tm.bind(null,e,n);r.has(n)||(r.add(n),n.then(i,i))})}}function wr(e,t){var r=t.deletions;if(r!==null)for(var n=0;n<r.length;n++){var i=r[n];try{var o=e,a=t,s=a;e:for(;s!==null;){switch(s.tag){case 5:Rt=s.stateNode,Sr=!1;break e;case 3:Rt=s.stateNode.containerInfo,Sr=!0;break e;case 4:Rt=s.stateNode.containerInfo,Sr=!0;break e}s=s.return}if(Rt===null)throw Error(te(160));rv(o,a,i),Rt=null,Sr=!1;var u=i.alternate;u!==null&&(u.return=null),i.return=null}catch(d){vt(i,t,d)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)nv(t,e),t=t.sibling}function nv(e,t){var r=e.alternate,n=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(wr(t,e),Tr(e),n&4){try{ho(3,e,e.return),Nl(3,e)}catch(N){vt(e,e.return,N)}try{ho(5,e,e.return)}catch(N){vt(e,e.return,N)}}break;case 1:wr(t,e),Tr(e),n&512&&r!==null&&si(r,r.return);break;case 5:if(wr(t,e),Tr(e),n&512&&r!==null&&si(r,r.return),e.flags&32){var i=e.stateNode;try{go(i,"")}catch(N){vt(e,e.return,N)}}if(n&4&&(i=e.stateNode,i!=null)){var o=e.memoizedProps,a=r!==null?r.memoizedProps:o,s=e.type,u=e.updateQueue;if(e.updateQueue=null,u!==null)try{s==="input"&&o.type==="radio"&&o.name!=null&&Ep(i,o),Ru(s,a);var d=Ru(s,o);for(a=0;a<u.length;a+=2){var _=u[a],m=u[a+1];_==="style"?Rp(i,m):_==="dangerouslySetInnerHTML"?Ap(i,m):_==="children"?go(i,m):Bf(i,_,m,d)}switch(s){case"input":Eu(i,o);break;case"textarea":jp(i,o);break;case"select":var E=i._wrapperState.wasMultiple;i._wrapperState.wasMultiple=!!o.multiple;var B=o.value;B!=null?fi(i,!!o.multiple,B,!1):E!==!!o.multiple&&(o.defaultValue!=null?fi(i,!!o.multiple,o.defaultValue,!0):fi(i,!!o.multiple,o.multiple?[]:"",!1))}i[jo]=o}catch(N){vt(e,e.return,N)}}break;case 6:if(wr(t,e),Tr(e),n&4){if(e.stateNode===null)throw Error(te(162));i=e.stateNode,o=e.memoizedProps;try{i.nodeValue=o}catch(N){vt(e,e.return,N)}}break;case 3:if(wr(t,e),Tr(e),n&4&&r!==null&&r.memoizedState.isDehydrated)try{wo(t.containerInfo)}catch(N){vt(e,e.return,N)}break;case 4:wr(t,e),Tr(e);break;case 13:wr(t,e),Tr(e),i=e.child,i.flags&8192&&(o=i.memoizedState!==null,i.stateNode.isHidden=o,!o||i.alternate!==null&&i.alternate.memoizedState!==null||(dc=xt())),n&4&&Ud(e);break;case 22:if(_=r!==null&&r.memoizedState!==null,e.mode&1?($t=(d=$t)||_,wr(t,e),$t=d):wr(t,e),Tr(e),n&8192){if(d=e.memoizedState!==null,(e.stateNode.isHidden=d)&&!_&&e.mode&1)for(fe=e,_=e.child;_!==null;){for(m=fe=_;fe!==null;){switch(E=fe,B=E.child,E.tag){case 0:case 11:case 14:case 15:ho(4,E,E.return);break;case 1:si(E,E.return);var R=E.stateNode;if(typeof R.componentWillUnmount=="function"){n=E,r=E.return;try{t=n,R.props=t.memoizedProps,R.state=t.memoizedState,R.componentWillUnmount()}catch(N){vt(n,r,N)}}break;case 5:si(E,E.return);break;case 22:if(E.memoizedState!==null){zd(m);continue}}B!==null?(B.return=E,fe=B):zd(m)}_=_.sibling}e:for(_=null,m=e;;){if(m.tag===5){if(_===null){_=m;try{i=m.stateNode,d?(o=i.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"):(s=m.stateNode,u=m.memoizedProps.style,a=u!=null&&u.hasOwnProperty("display")?u.display:null,s.style.display=Np("display",a))}catch(N){vt(e,e.return,N)}}}else if(m.tag===6){if(_===null)try{m.stateNode.nodeValue=d?"":m.memoizedProps}catch(N){vt(e,e.return,N)}}else if((m.tag!==22&&m.tag!==23||m.memoizedState===null||m===e)&&m.child!==null){m.child.return=m,m=m.child;continue}if(m===e)break e;for(;m.sibling===null;){if(m.return===null||m.return===e)break e;_===m&&(_=null),m=m.return}_===m&&(_=null),m.sibling.return=m.return,m=m.sibling}}break;case 19:wr(t,e),Tr(e),n&4&&Ud(e);break;case 21:break;default:wr(t,e),Tr(e)}}function Tr(e){var t=e.flags;if(t&2){try{e:{for(var r=e.return;r!==null;){if(tv(r)){var n=r;break e}r=r.return}throw Error(te(160))}switch(n.tag){case 5:var i=n.stateNode;n.flags&32&&(go(i,""),n.flags&=-33);var o=Dd(e);lf(e,o,i);break;case 3:case 4:var a=n.stateNode.containerInfo,s=Dd(e);af(e,s,a);break;default:throw Error(te(161))}}catch(u){vt(e,e.return,u)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function km(e,t,r){fe=e,iv(e)}function iv(e,t,r){for(var n=(e.mode&1)!==0;fe!==null;){var i=fe,o=i.child;if(i.tag===22&&n){var a=i.memoizedState!==null||ma;if(!a){var s=i.alternate,u=s!==null&&s.memoizedState!==null||$t;s=ma;var d=$t;if(ma=a,($t=u)&&!d)for(fe=i;fe!==null;)a=fe,u=a.child,a.tag===22&&a.memoizedState!==null?$d(i):u!==null?(u.return=a,fe=u):$d(i);for(;o!==null;)fe=o,iv(o),o=o.sibling;fe=i,ma=s,$t=d}Fd(e)}else i.subtreeFlags&8772&&o!==null?(o.return=i,fe=o):Fd(e)}}function Fd(e){for(;fe!==null;){var t=fe;if(t.flags&8772){var r=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:$t||Nl(5,t);break;case 1:var n=t.stateNode;if(t.flags&4&&!$t)if(r===null)n.componentDidMount();else{var i=t.elementType===t.type?r.memoizedProps:kr(t.type,r.memoizedProps);n.componentDidUpdate(i,r.memoizedState,n.__reactInternalSnapshotBeforeUpdate)}var o=t.updateQueue;o!==null&&Sd(t,o,n);break;case 3:var a=t.updateQueue;if(a!==null){if(r=null,t.child!==null)switch(t.child.tag){case 5:r=t.child.stateNode;break;case 1:r=t.child.stateNode}Sd(t,a,r)}break;case 5:var s=t.stateNode;if(r===null&&t.flags&4){r=s;var u=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":u.autoFocus&&r.focus();break;case"img":u.src&&(r.src=u.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var d=t.alternate;if(d!==null){var _=d.memoizedState;if(_!==null){var m=_.dehydrated;m!==null&&wo(m)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(te(163))}$t||t.flags&512&&of(t)}catch(E){vt(t,t.return,E)}}if(t===e){fe=null;break}if(r=t.sibling,r!==null){r.return=t.return,fe=r;break}fe=t.return}}function zd(e){for(;fe!==null;){var t=fe;if(t===e){fe=null;break}var r=t.sibling;if(r!==null){r.return=t.return,fe=r;break}fe=t.return}}function $d(e){for(;fe!==null;){var t=fe;try{switch(t.tag){case 0:case 11:case 15:var r=t.return;try{Nl(4,t)}catch(u){vt(t,r,u)}break;case 1:var n=t.stateNode;if(typeof n.componentDidMount=="function"){var i=t.return;try{n.componentDidMount()}catch(u){vt(t,i,u)}}var o=t.return;try{of(t)}catch(u){vt(t,o,u)}break;case 5:var a=t.return;try{of(t)}catch(u){vt(t,a,u)}}}catch(u){vt(t,t.return,u)}if(t===e){fe=null;break}var s=t.sibling;if(s!==null){s.return=t.return,fe=s;break}fe=t.return}}var Sm=Math.ceil,sl=Zr.ReactCurrentDispatcher,fc=Zr.ReactCurrentOwner,yr=Zr.ReactCurrentBatchConfig,Qe=0,At=null,bt=null,Tt=0,or=0,ui=_n(0),St=0,Lo=null,Dn=0,Rl=0,cc=0,po=null,Xt=null,dc=0,Ei=1/0,Fr=null,ul=!1,sf=null,yn=null,xa=!1,fn=null,fl=0,vo=0,uf=null,Ma=-1,Oa=0;function qt(){return Qe&6?xt():Ma!==-1?Ma:Ma=xt()}function gn(e){return e.mode&1?Qe&2&&Tt!==0?Tt&-Tt:lm.transition!==null?(Oa===0&&(Oa=$p()),Oa):(e=et,e!==0||(e=window.event,e=e===void 0?16:Yp(e.type)),e):1}function Cr(e,t,r,n){if(50<vo)throw vo=0,uf=null,Error(te(185));Uo(e,r,n),(!(Qe&2)||e!==At)&&(e===At&&(!(Qe&2)&&(Rl|=r),St===4&&sn(e,Tt)),tr(e,n),r===1&&Qe===0&&!(t.mode&1)&&(Ei=xt()+500,jl&&kn()))}function tr(e,t){var r=e.callbackNode;lg(e,t);var n=qa(e,e===At?Tt:0);if(n===0)r!==null&&Xc(r),e.callbackNode=null,e.callbackPriority=0;else if(t=n&-n,e.callbackPriority!==t){if(r!=null&&Xc(r),t===1)e.tag===0?am(Hd.bind(null,e)):p0(Hd.bind(null,e)),rm(function(){!(Qe&6)&&kn()}),r=null;else{switch(Hp(n)){case 1:r=Df;break;case 4:r=Fp;break;case 16:r=Ka;break;case 536870912:r=zp;break;default:r=Ka}r=dv(r,ov.bind(null,e))}e.callbackPriority=t,e.callbackNode=r}}function ov(e,t){if(Ma=-1,Oa=0,Qe&6)throw Error(te(327));var r=e.callbackNode;if(vi()&&e.callbackNode!==r)return null;var n=qa(e,e===At?Tt:0);if(n===0)return null;if(n&30||n&e.expiredLanes||t)t=cl(e,n);else{t=n;var i=Qe;Qe|=2;var o=lv();(At!==e||Tt!==t)&&(Fr=null,Ei=xt()+500,Ln(e,t));do try{Cm();break}catch(s){av(e,s)}while(!0);Xf(),sl.current=o,Qe=i,bt!==null?t=0:(At=null,Tt=0,t=St)}if(t!==0){if(t===2&&(i=Mu(e),i!==0&&(n=i,t=ff(e,i))),t===1)throw r=Lo,Ln(e,0),sn(e,n),tr(e,xt()),r;if(t===6)sn(e,n);else{if(i=e.current.alternate,!(n&30)&&!Em(i)&&(t=cl(e,n),t===2&&(o=Mu(e),o!==0&&(n=o,t=ff(e,o))),t===1))throw r=Lo,Ln(e,0),sn(e,n),tr(e,xt()),r;switch(e.finishedWork=i,e.finishedLanes=n,t){case 0:case 1:throw Error(te(345));case 2:Cn(e,Xt,Fr);break;case 3:if(sn(e,n),(n&130023424)===n&&(t=dc+500-xt(),10<t)){if(qa(e,0)!==0)break;if(i=e.suspendedLanes,(i&n)!==n){qt(),e.pingedLanes|=e.suspendedLanes&i;break}e.timeoutHandle=Hu(Cn.bind(null,e,Xt,Fr),t);break}Cn(e,Xt,Fr);break;case 4:if(sn(e,n),(n&4194240)===n)break;for(t=e.eventTimes,i=-1;0<n;){var a=31-jr(n);o=1<<a,a=t[a],a>i&&(i=a),n&=~o}if(n=i,n=xt()-n,n=(120>n?120:480>n?480:1080>n?1080:1920>n?1920:3e3>n?3e3:4320>n?4320:1960*Sm(n/1960))-n,10<n){e.timeoutHandle=Hu(Cn.bind(null,e,Xt,Fr),n);break}Cn(e,Xt,Fr);break;case 5:Cn(e,Xt,Fr);break;default:throw Error(te(329))}}}return tr(e,xt()),e.callbackNode===r?ov.bind(null,e):null}function ff(e,t){var r=po;return e.current.memoizedState.isDehydrated&&(Ln(e,t).flags|=256),e=cl(e,t),e!==2&&(t=Xt,Xt=r,t!==null&&cf(t)),e}function cf(e){Xt===null?Xt=e:Xt.push.apply(Xt,e)}function Em(e){for(var t=e;;){if(t.flags&16384){var r=t.updateQueue;if(r!==null&&(r=r.stores,r!==null))for(var n=0;n<r.length;n++){var i=r[n],o=i.getSnapshot;i=i.value;try{if(!Ar(o(),i))return!1}catch{return!1}}}if(r=t.child,t.subtreeFlags&16384&&r!==null)r.return=t,t=r;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function sn(e,t){for(t&=~cc,t&=~Rl,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var r=31-jr(t),n=1<<r;e[r]=-1,t&=~n}}function Hd(e){if(Qe&6)throw Error(te(327));vi();var t=qa(e,0);if(!(t&1))return tr(e,xt()),null;var r=cl(e,t);if(e.tag!==0&&r===2){var n=Mu(e);n!==0&&(t=n,r=ff(e,n))}if(r===1)throw r=Lo,Ln(e,0),sn(e,t),tr(e,xt()),r;if(r===6)throw Error(te(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,Cn(e,Xt,Fr),tr(e,xt()),null}function hc(e,t){var r=Qe;Qe|=1;try{return e(t)}finally{Qe=r,Qe===0&&(Ei=xt()+500,jl&&kn())}}function Un(e){fn!==null&&fn.tag===0&&!(Qe&6)&&vi();var t=Qe;Qe|=1;var r=yr.transition,n=et;try{if(yr.transition=null,et=1,e)return e()}finally{et=n,yr.transition=r,Qe=t,!(Qe&6)&&kn()}}function pc(){or=ui.current,at(ui)}function Ln(e,t){e.finishedWork=null,e.finishedLanes=0;var r=e.timeoutHandle;if(r!==-1&&(e.timeoutHandle=-1,tm(r)),bt!==null)for(r=bt.return;r!==null;){var n=r;switch(Gf(n),n.tag){case 1:n=n.type.childContextTypes,n!=null&&Za();break;case 3:ki(),at(Jt),at(Ht),nc();break;case 5:rc(n);break;case 4:ki();break;case 13:at(st);break;case 19:at(st);break;case 10:Zf(n.type._context);break;case 22:case 23:pc()}r=r.return}if(At=e,bt=e=mn(e.current,null),Tt=or=t,St=0,Lo=null,cc=Rl=Dn=0,Xt=po=null,Nn!==null){for(t=0;t<Nn.length;t++)if(r=Nn[t],n=r.interleaved,n!==null){r.interleaved=null;var i=n.next,o=r.pending;if(o!==null){var a=o.next;o.next=i,n.next=a}r.pending=n}Nn=null}return e}function av(e,t){do{var r=bt;try{if(Xf(),La.current=ll,al){for(var n=ut.memoizedState;n!==null;){var i=n.queue;i!==null&&(i.pending=null),n=n.next}al=!1}if(In=0,Ct=kt=ut=null,co=!1,No=0,fc.current=null,r===null||r.return===null){St=1,Lo=t,bt=null;break}e:{var o=e,a=r.return,s=r,u=t;if(t=Tt,s.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){var d=u,_=s,m=_.tag;if(!(_.mode&1)&&(m===0||m===11||m===15)){var E=_.alternate;E?(_.updateQueue=E.updateQueue,_.memoizedState=E.memoizedState,_.lanes=E.lanes):(_.updateQueue=null,_.memoizedState=null)}var B=Rd(a);if(B!==null){B.flags&=-257,Td(B,a,s,o,t),B.mode&1&&Nd(o,d,t),t=B,u=d;var R=t.updateQueue;if(R===null){var N=new Set;N.add(u),t.updateQueue=N}else R.add(u);break e}else{if(!(t&1)){Nd(o,d,t),vc();break e}u=Error(te(426))}}else if(lt&&s.mode&1){var P=Rd(a);if(P!==null){!(P.flags&65536)&&(P.flags|=256),Td(P,a,s,o,t),Yf(Si(u,s));break e}}o=u=Si(u,s),St!==4&&(St=2),po===null?po=[o]:po.push(o),o=a;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var p=H0(o,u,t);kd(o,p);break e;case 1:s=u;var v=o.type,x=o.stateNode;if(!(o.flags&128)&&(typeof v.getDerivedStateFromError=="function"||x!==null&&typeof x.componentDidCatch=="function"&&(yn===null||!yn.has(x)))){o.flags|=65536,t&=-t,o.lanes|=t;var C=W0(o,s,t);kd(o,C);break e}}o=o.return}while(o!==null)}uv(r)}catch(O){t=O,bt===r&&r!==null&&(bt=r=r.return);continue}break}while(!0)}function lv(){var e=sl.current;return sl.current=ll,e===null?ll:e}function vc(){(St===0||St===3||St===2)&&(St=4),At===null||!(Dn&268435455)&&!(Rl&268435455)||sn(At,Tt)}function cl(e,t){var r=Qe;Qe|=2;var n=lv();(At!==e||Tt!==t)&&(Fr=null,Ln(e,t));do try{jm();break}catch(i){av(e,i)}while(!0);if(Xf(),Qe=r,sl.current=n,bt!==null)throw Error(te(261));return At=null,Tt=0,St}function jm(){for(;bt!==null;)sv(bt)}function Cm(){for(;bt!==null&&!Zy();)sv(bt)}function sv(e){var t=cv(e.alternate,e,or);e.memoizedProps=e.pendingProps,t===null?uv(e):bt=t,fc.current=null}function uv(e){var t=e;do{var r=t.alternate;if(e=t.return,t.flags&32768){if(r=bm(r,t),r!==null){r.flags&=32767,bt=r;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{St=6,bt=null;return}}else if(r=xm(r,t,or),r!==null){bt=r;return}if(t=t.sibling,t!==null){bt=t;return}bt=t=e}while(t!==null);St===0&&(St=5)}function Cn(e,t,r){var n=et,i=yr.transition;try{yr.transition=null,et=1,Am(e,t,r,n)}finally{yr.transition=i,et=n}return null}function Am(e,t,r,n){do vi();while(fn!==null);if(Qe&6)throw Error(te(327));r=e.finishedWork;var i=e.finishedLanes;if(r===null)return null;if(e.finishedWork=null,e.finishedLanes=0,r===e.current)throw Error(te(177));e.callbackNode=null,e.callbackPriority=0;var o=r.lanes|r.childLanes;if(sg(e,o),e===At&&(bt=At=null,Tt=0),!(r.subtreeFlags&2064)&&!(r.flags&2064)||xa||(xa=!0,dv(Ka,function(){return vi(),null})),o=(r.flags&15990)!==0,r.subtreeFlags&15990||o){o=yr.transition,yr.transition=null;var a=et;et=1;var s=Qe;Qe|=4,fc.current=null,_m(e,r),nv(r,e),Gg(zu),Ga=!!Fu,zu=Fu=null,e.current=r,km(r),Jy(),Qe=s,et=a,yr.transition=o}else e.current=r;if(xa&&(xa=!1,fn=e,fl=i),o=e.pendingLanes,o===0&&(yn=null),rg(r.stateNode),tr(e,xt()),t!==null)for(n=e.onRecoverableError,r=0;r<t.length;r++)i=t[r],n(i.value,{componentStack:i.stack,digest:i.digest});if(ul)throw ul=!1,e=sf,sf=null,e;return fl&1&&e.tag!==0&&vi(),o=e.pendingLanes,o&1?e===uf?vo++:(vo=0,uf=e):vo=0,kn(),null}function vi(){if(fn!==null){var e=Hp(fl),t=yr.transition,r=et;try{if(yr.transition=null,et=16>e?16:e,fn===null)var n=!1;else{if(e=fn,fn=null,fl=0,Qe&6)throw Error(te(331));var i=Qe;for(Qe|=4,fe=e.current;fe!==null;){var o=fe,a=o.child;if(fe.flags&16){var s=o.deletions;if(s!==null){for(var u=0;u<s.length;u++){var d=s[u];for(fe=d;fe!==null;){var _=fe;switch(_.tag){case 0:case 11:case 15:ho(8,_,o)}var m=_.child;if(m!==null)m.return=_,fe=m;else for(;fe!==null;){_=fe;var E=_.sibling,B=_.return;if(ev(_),_===d){fe=null;break}if(E!==null){E.return=B,fe=E;break}fe=B}}}var R=o.alternate;if(R!==null){var N=R.child;if(N!==null){R.child=null;do{var P=N.sibling;N.sibling=null,N=P}while(N!==null)}}fe=o}}if(o.subtreeFlags&2064&&a!==null)a.return=o,fe=a;else e:for(;fe!==null;){if(o=fe,o.flags&2048)switch(o.tag){case 0:case 11:case 15:ho(9,o,o.return)}var p=o.sibling;if(p!==null){p.return=o.return,fe=p;break e}fe=o.return}}var v=e.current;for(fe=v;fe!==null;){a=fe;var x=a.child;if(a.subtreeFlags&2064&&x!==null)x.return=a,fe=x;else e:for(a=v;fe!==null;){if(s=fe,s.flags&2048)try{switch(s.tag){case 0:case 11:case 15:Nl(9,s)}}catch(O){vt(s,s.return,O)}if(s===a){fe=null;break e}var C=s.sibling;if(C!==null){C.return=s.return,fe=C;break e}fe=s.return}}if(Qe=i,kn(),Or&&typeof Or.onPostCommitFiberRoot=="function")try{Or.onPostCommitFiberRoot(wl,e)}catch{}n=!0}return n}finally{et=r,yr.transition=t}}return!1}function Wd(e,t,r){t=Si(r,t),t=H0(e,t,1),e=vn(e,t,1),t=qt(),e!==null&&(Uo(e,1,t),tr(e,t))}function vt(e,t,r){if(e.tag===3)Wd(e,e,r);else for(;t!==null;){if(t.tag===3){Wd(t,e,r);break}else if(t.tag===1){var n=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof n.componentDidCatch=="function"&&(yn===null||!yn.has(n))){e=Si(r,e),e=W0(t,e,1),t=vn(t,e,1),e=qt(),t!==null&&(Uo(t,1,e),tr(t,e));break}}t=t.return}}function Nm(e,t,r){var n=e.pingCache;n!==null&&n.delete(t),t=qt(),e.pingedLanes|=e.suspendedLanes&r,At===e&&(Tt&r)===r&&(St===4||St===3&&(Tt&130023424)===Tt&&500>xt()-dc?Ln(e,0):cc|=r),tr(e,t)}function fv(e,t){t===0&&(e.mode&1?(t=ua,ua<<=1,!(ua&130023424)&&(ua=4194304)):t=1);var r=qt();e=qr(e,t),e!==null&&(Uo(e,t,r),tr(e,r))}function Rm(e){var t=e.memoizedState,r=0;t!==null&&(r=t.retryLane),fv(e,r)}function Tm(e,t){var r=0;switch(e.tag){case 13:var n=e.stateNode,i=e.memoizedState;i!==null&&(r=i.retryLane);break;case 19:n=e.stateNode;break;default:throw Error(te(314))}n!==null&&n.delete(t),fv(e,r)}var cv;cv=function(e,t,r){if(e!==null)if(e.memoizedProps!==t.pendingProps||Jt.current)Zt=!0;else{if(!(e.lanes&r)&&!(t.flags&128))return Zt=!1,mm(e,t,r);Zt=!!(e.flags&131072)}else Zt=!1,lt&&t.flags&1048576&&v0(t,tl,t.index);switch(t.lanes=0,t.tag){case 2:var n=t.type;Pa(e,t),e=t.pendingProps;var i=bi(t,Ht.current);pi(t,r),i=oc(null,t,n,e,i,r);var o=ac();return t.flags|=1,typeof i=="object"&&i!==null&&typeof i.render=="function"&&i.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,er(n)?(o=!0,Ja(t)):o=!1,t.memoizedState=i.state!==null&&i.state!==void 0?i.state:null,ec(t),i.updater=Al,t.stateNode=i,i._reactInternals=t,Qu(t,n,e,r),t=Ju(null,t,n,!0,o,r)):(t.tag=0,lt&&o&&qf(t),Kt(null,t,i,r),t=t.child),t;case 16:n=t.elementType;e:{switch(Pa(e,t),e=t.pendingProps,i=n._init,n=i(n._payload),t.type=n,i=t.tag=Bm(n),e=kr(n,e),i){case 0:t=Zu(null,t,n,e,r);break e;case 1:t=Pd(null,t,n,e,r);break e;case 11:t=Ld(null,t,n,e,r);break e;case 14:t=Bd(null,t,n,kr(n.type,e),r);break e}throw Error(te(306,n,""))}return t;case 0:return n=t.type,i=t.pendingProps,i=t.elementType===n?i:kr(n,i),Zu(e,t,n,i,r);case 1:return n=t.type,i=t.pendingProps,i=t.elementType===n?i:kr(n,i),Pd(e,t,n,i,r);case 3:e:{if(G0(t),e===null)throw Error(te(387));n=t.pendingProps,o=t.memoizedState,i=o.element,w0(e,t),il(t,n,null,r);var a=t.memoizedState;if(n=a.element,o.isDehydrated)if(o={element:n,isDehydrated:!1,cache:a.cache,pendingSuspenseBoundaries:a.pendingSuspenseBoundaries,transitions:a.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){i=Si(Error(te(423)),t),t=Md(e,t,n,r,i);break e}else if(n!==i){i=Si(Error(te(424)),t),t=Md(e,t,n,r,i);break e}else for(ar=pn(t.stateNode.containerInfo.firstChild),lr=t,lt=!0,Er=null,r=x0(t,null,n,r),t.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling;else{if(wi(),n===i){t=Gr(e,t,r);break e}Kt(e,t,n,r)}t=t.child}return t;case 5:return _0(t),e===null&&qu(t),n=t.type,i=t.pendingProps,o=e!==null?e.memoizedProps:null,a=i.children,$u(n,i)?a=null:o!==null&&$u(n,o)&&(t.flags|=32),q0(e,t),Kt(e,t,a,r),t.child;case 6:return e===null&&qu(t),null;case 13:return Y0(e,t,r);case 4:return tc(t,t.stateNode.containerInfo),n=t.pendingProps,e===null?t.child=_i(t,null,n,r):Kt(e,t,n,r),t.child;case 11:return n=t.type,i=t.pendingProps,i=t.elementType===n?i:kr(n,i),Ld(e,t,n,i,r);case 7:return Kt(e,t,t.pendingProps,r),t.child;case 8:return Kt(e,t,t.pendingProps.children,r),t.child;case 12:return Kt(e,t,t.pendingProps.children,r),t.child;case 10:e:{if(n=t.type._context,i=t.pendingProps,o=t.memoizedProps,a=i.value,it(rl,n._currentValue),n._currentValue=a,o!==null)if(Ar(o.value,a)){if(o.children===i.children&&!Jt.current){t=Gr(e,t,r);break e}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var s=o.dependencies;if(s!==null){a=o.child;for(var u=s.firstContext;u!==null;){if(u.context===n){if(o.tag===1){u=Wr(-1,r&-r),u.tag=2;var d=o.updateQueue;if(d!==null){d=d.shared;var _=d.pending;_===null?u.next=u:(u.next=_.next,_.next=u),d.pending=u}}o.lanes|=r,u=o.alternate,u!==null&&(u.lanes|=r),Gu(o.return,r,t),s.lanes|=r;break}u=u.next}}else if(o.tag===10)a=o.type===t.type?null:o.child;else if(o.tag===18){if(a=o.return,a===null)throw Error(te(341));a.lanes|=r,s=a.alternate,s!==null&&(s.lanes|=r),Gu(a,r,t),a=o.sibling}else a=o.child;if(a!==null)a.return=o;else for(a=o;a!==null;){if(a===t){a=null;break}if(o=a.sibling,o!==null){o.return=a.return,a=o;break}a=a.return}o=a}Kt(e,t,i.children,r),t=t.child}return t;case 9:return i=t.type,n=t.pendingProps.children,pi(t,r),i=mr(i),n=n(i),t.flags|=1,Kt(e,t,n,r),t.child;case 14:return n=t.type,i=kr(n,t.pendingProps),i=kr(n.type,i),Bd(e,t,n,i,r);case 15:return V0(e,t,t.type,t.pendingProps,r);case 17:return n=t.type,i=t.pendingProps,i=t.elementType===n?i:kr(n,i),Pa(e,t),t.tag=1,er(n)?(e=!0,Ja(t)):e=!1,pi(t,r),$0(t,n,i),Qu(t,n,i,r),Ju(null,t,n,!0,e,r);case 19:return Q0(e,t,r);case 22:return K0(e,t,r)}throw Error(te(156,t.tag))};function dv(e,t){return Up(e,t)}function Lm(e,t,r,n){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=n,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function vr(e,t,r,n){return new Lm(e,t,r,n)}function yc(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Bm(e){if(typeof e=="function")return yc(e)?1:0;if(e!=null){if(e=e.$$typeof,e===Mf)return 11;if(e===Of)return 14}return 2}function mn(e,t){var r=e.alternate;return r===null?(r=vr(e.tag,t,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=t,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&14680064,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,t=e.dependencies,r.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r}function Ia(e,t,r,n,i,o){var a=2;if(n=e,typeof e=="function")yc(e)&&(a=1);else if(typeof e=="string")a=5;else e:switch(e){case Jn:return Bn(r.children,i,o,t);case Pf:a=8,i|=8;break;case bu:return e=vr(12,r,t,i|2),e.elementType=bu,e.lanes=o,e;case wu:return e=vr(13,r,t,i),e.elementType=wu,e.lanes=o,e;case _u:return e=vr(19,r,t,i),e.elementType=_u,e.lanes=o,e;case _p:return Tl(r,i,o,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case bp:a=10;break e;case wp:a=9;break e;case Mf:a=11;break e;case Of:a=14;break e;case on:a=16,n=null;break e}throw Error(te(130,e==null?e:typeof e,""))}return t=vr(a,r,t,i),t.elementType=e,t.type=n,t.lanes=o,t}function Bn(e,t,r,n){return e=vr(7,e,n,t),e.lanes=r,e}function Tl(e,t,r,n){return e=vr(22,e,n,t),e.elementType=_p,e.lanes=r,e.stateNode={isHidden:!1},e}function Cs(e,t,r){return e=vr(6,e,null,t),e.lanes=r,e}function As(e,t,r){return t=vr(4,e.children!==null?e.children:[],e.key,t),t.lanes=r,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Pm(e,t,r,n,i){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=ss(0),this.expirationTimes=ss(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=ss(0),this.identifierPrefix=n,this.onRecoverableError=i,this.mutableSourceEagerHydrationData=null}function gc(e,t,r,n,i,o,a,s,u){return e=new Pm(e,t,r,s,u),t===1?(t=1,o===!0&&(t|=8)):t=0,o=vr(3,null,null,t),e.current=o,o.stateNode=e,o.memoizedState={element:n,isDehydrated:r,cache:null,transitions:null,pendingSuspenseBoundaries:null},ec(o),e}function Mm(e,t,r){var n=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Zn,key:n==null?null:""+n,children:e,containerInfo:t,implementation:r}}function hv(e){if(!e)return bn;e=e._reactInternals;e:{if($n(e)!==e||e.tag!==1)throw Error(te(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(er(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(te(171))}if(e.tag===1){var r=e.type;if(er(r))return h0(e,r,t)}return t}function pv(e,t,r,n,i,o,a,s,u){return e=gc(r,n,!0,e,i,o,a,s,u),e.context=hv(null),r=e.current,n=qt(),i=gn(r),o=Wr(n,i),o.callback=t??null,vn(r,o,i),e.current.lanes=i,Uo(e,i,n),tr(e,n),e}function Ll(e,t,r,n){var i=t.current,o=qt(),a=gn(i);return r=hv(r),t.context===null?t.context=r:t.pendingContext=r,t=Wr(o,a),t.payload={element:e},n=n===void 0?null:n,n!==null&&(t.callback=n),e=vn(i,t,a),e!==null&&(Cr(e,i,a,o),Ta(e,i,a)),a}function dl(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function Vd(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var r=e.retryLane;e.retryLane=r!==0&&r<t?r:t}}function mc(e,t){Vd(e,t),(e=e.alternate)&&Vd(e,t)}function Om(){return null}var vv=typeof reportError=="function"?reportError:function(e){console.error(e)};function xc(e){this._internalRoot=e}Bl.prototype.render=xc.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(te(409));Ll(e,t,null,null)};Bl.prototype.unmount=xc.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Un(function(){Ll(null,e,null,null)}),t[Kr]=null}};function Bl(e){this._internalRoot=e}Bl.prototype.unstable_scheduleHydration=function(e){if(e){var t=Kp();e={blockedOn:null,target:e,priority:t};for(var r=0;r<ln.length&&t!==0&&t<ln[r].priority;r++);ln.splice(r,0,e),r===0&&Gp(e)}};function bc(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Pl(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Kd(){}function Im(e,t,r,n,i){if(i){if(typeof n=="function"){var o=n;n=function(){var d=dl(a);o.call(d)}}var a=pv(t,n,e,0,null,!1,!1,"",Kd);return e._reactRootContainer=a,e[Kr]=a.current,So(e.nodeType===8?e.parentNode:e),Un(),a}for(;i=e.lastChild;)e.removeChild(i);if(typeof n=="function"){var s=n;n=function(){var d=dl(u);s.call(d)}}var u=gc(e,0,!1,null,null,!1,!1,"",Kd);return e._reactRootContainer=u,e[Kr]=u.current,So(e.nodeType===8?e.parentNode:e),Un(function(){Ll(t,u,r,n)}),u}function Ml(e,t,r,n,i){var o=r._reactRootContainer;if(o){var a=o;if(typeof i=="function"){var s=i;i=function(){var u=dl(a);s.call(u)}}Ll(t,a,e,i)}else a=Im(r,t,e,i,n);return dl(a)}Wp=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var r=no(t.pendingLanes);r!==0&&(Uf(t,r|1),tr(t,xt()),!(Qe&6)&&(Ei=xt()+500,kn()))}break;case 13:Un(function(){var n=qr(e,1);if(n!==null){var i=qt();Cr(n,e,1,i)}}),mc(e,1)}};Ff=function(e){if(e.tag===13){var t=qr(e,134217728);if(t!==null){var r=qt();Cr(t,e,134217728,r)}mc(e,134217728)}};Vp=function(e){if(e.tag===13){var t=gn(e),r=qr(e,t);if(r!==null){var n=qt();Cr(r,e,t,n)}mc(e,t)}};Kp=function(){return et};qp=function(e,t){var r=et;try{return et=e,t()}finally{et=r}};Lu=function(e,t,r){switch(t){case"input":if(Eu(e,r),t=r.name,r.type==="radio"&&t!=null){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<r.length;t++){var n=r[t];if(n!==e&&n.form===e.form){var i=El(n);if(!i)throw Error(te(90));Sp(n),Eu(n,i)}}}break;case"textarea":jp(e,r);break;case"select":t=r.value,t!=null&&fi(e,!!r.multiple,t,!1)}};Bp=hc;Pp=Un;var Dm={usingClientEntryPoint:!1,Events:[zo,ni,El,Tp,Lp,hc]},qi={findFiberByHostInstance:An,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Um={bundleType:qi.bundleType,version:qi.version,rendererPackageName:qi.rendererPackageName,rendererConfig:qi.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Zr.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=Ip(e),e===null?null:e.stateNode},findFiberByHostInstance:qi.findFiberByHostInstance||Om,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var ba=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!ba.isDisabled&&ba.supportsFiber)try{wl=ba.inject(Um),Or=ba}catch{}}ur.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Dm;ur.createPortal=function(e,t){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!bc(t))throw Error(te(200));return Mm(e,t,null,r)};ur.createRoot=function(e,t){if(!bc(e))throw Error(te(299));var r=!1,n="",i=vv;return t!=null&&(t.unstable_strictMode===!0&&(r=!0),t.identifierPrefix!==void 0&&(n=t.identifierPrefix),t.onRecoverableError!==void 0&&(i=t.onRecoverableError)),t=gc(e,1,!1,null,null,r,!1,n,i),e[Kr]=t.current,So(e.nodeType===8?e.parentNode:e),new xc(t)};ur.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(te(188)):(e=Object.keys(e).join(","),Error(te(268,e)));return e=Ip(t),e=e===null?null:e.stateNode,e};ur.flushSync=function(e){return Un(e)};ur.hydrate=function(e,t,r){if(!Pl(t))throw Error(te(200));return Ml(null,e,t,!0,r)};ur.hydrateRoot=function(e,t,r){if(!bc(e))throw Error(te(405));var n=r!=null&&r.hydratedSources||null,i=!1,o="",a=vv;if(r!=null&&(r.unstable_strictMode===!0&&(i=!0),r.identifierPrefix!==void 0&&(o=r.identifierPrefix),r.onRecoverableError!==void 0&&(a=r.onRecoverableError)),t=pv(t,null,e,1,r??null,i,!1,o,a),e[Kr]=t.current,So(e),n)for(e=0;e<n.length;e++)r=n[e],i=r._getVersion,i=i(r._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[r,i]:t.mutableSourceEagerHydrationData.push(r,i);return new Bl(t)};ur.render=function(e,t,r){if(!Pl(t))throw Error(te(200));return Ml(null,e,t,!1,r)};ur.unmountComponentAtNode=function(e){if(!Pl(e))throw Error(te(40));return e._reactRootContainer?(Un(function(){Ml(null,null,e,!1,function(){e._reactRootContainer=null,e[Kr]=null})}),!0):!1};ur.unstable_batchedUpdates=hc;ur.unstable_renderSubtreeIntoContainer=function(e,t,r,n){if(!Pl(r))throw Error(te(200));if(e==null||e._reactInternals===void 0)throw Error(te(38));return Ml(e,t,r,!1,n)};ur.version="18.3.1-next-f1338f8080-20240426";function yv(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(yv)}catch(e){console.error(e)}}yv(),yp.exports=ur;var Fm=yp.exports,gv,qd=Fm;gv=qd.createRoot,qd.hydrateRoot;function zm(e){return{allowedContract:e,allowedFns:["add_signer","remove_signer"],name:"recovery-signer-management-only"}}async function $m({accountId:e,recoveryG:t,kit:r}){r=r??await ty();const n=zm(e),{contextRuleId:i}=await r.rules.create({type:"custom",params:n}),o=await r.signers.addDelegated(i,t);return{contextRuleId:i,...o}}function mv({verdict:e,simulate:t,onApprove:r,onReject:n}){const i=!!(e!=null&&e.allow);return f.jsxs("div",{className:"approve",role:"dialog","aria-label":"Approve transaction",children:[f.jsxs("div",{className:"eyebrow",children:[f.jsx("span",{className:"sec",children:"Approve"}),f.jsx("span",{className:"rule"}),f.jsx("span",{children:"F8 gate"})]}),f.jsxs("p",{className:"approve-verdict "+(i?"ok":"bad"),"data-testid":"verdict","data-eligible":i,children:[i?"Eligible":"Not eligible",": ",((e==null?void 0:e.reasons)??[]).join("; ")]}),f.jsxs("div",{className:"row",children:[f.jsx("span",{className:"row-k",children:"Shares out"}),f.jsx("span",{className:"row-v mono tnum","data-testid":"amount",children:(t==null?void 0:t.sharesOut)??"-"})]}),f.jsxs("div",{className:"btn-row",children:[f.jsx("button",{className:"btn btn-ghost",onClick:n,children:"Cancel"}),f.jsx("button",{className:"btn btn-primary",disabled:!i,onClick:r,children:"Approve with Face ID"})]})]})}const qn={deposit:"F8 eligibility is app-layer only, not enforced on-chain (off-chain check, fail-closed).",recovery:"Recovery key is VF-custodied, a centralisation trade-off. Guard this key carefully.",testnet:"Everything here is testnet-grade only. Do not use real funds.",protocol:"Passkey-on-Stellar is mainnet-live at the protocol layer, but these wallet contracts are testnet PoC-grade.",agent:"Agent spending cap is not yet enforced on-chain (cap policy contract undeployed). Testnet PoC.",session_key:"While unlocked, this wallet keeps a key in chrome.storage.session (in-memory). Someone already running code on your machine could read it. Lock this wallet when done. Testnet PoC."},Gn={fontFamily:'"JetBrains Mono", ui-monospace, monospace',fontSize:11,lineHeight:1.5,color:"#f0b54a",background:"rgba(240,181,74,0.08)",border:"1px solid rgba(240,181,74,0.28)",borderRadius:6,padding:"7px 9px",margin:"4px 0"};function Pr({scope:e="global"}){return e==="deposit"?f.jsx("p",{"data-testid":"honesty-deposit",style:Gn,children:qn.deposit}):e==="recovery"?f.jsx("p",{"data-testid":"honesty-recovery",style:Gn,children:qn.recovery}):e==="agent"?f.jsx("p",{"data-testid":"honesty-agent",style:Gn,children:qn.agent}):e==="session-key"?f.jsx("p",{"data-testid":"honesty-session-key",style:Gn,children:qn.session_key}):f.jsxs("div",{"data-testid":"honesty-global",children:[f.jsx("p",{style:Gn,children:qn.testnet}),f.jsx("p",{style:Gn,children:qn.protocol})]})}function Hm({onCreate:e,onGoImport:t,busy:r,error:n}){const[i,o]=xe.useState("Main"),[a,s]=xe.useState(""),[u,d]=xe.useState(""),_=a.length<12,m=a!==u;return f.jsxs("div",{className:"vf-screen vf-create",children:[f.jsxs("div",{style:{textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",gap:"6px"},children:[f.jsx("div",{style:{width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(135deg, var(--bg-elev) 0%, var(--bg-card) 100%)",border:"1px solid var(--border-strong)",marginBottom:4,boxShadow:"0 4px 16px rgba(0,0,0,.25)"},children:f.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("path",{d:"M12 2L2 7l10 5 10-5-10-5z"}),f.jsx("path",{d:"M2 17l10 5 10-5"}),f.jsx("path",{d:"M2 12l10 5 10-5"})]})}),f.jsx("h2",{style:{margin:0},children:"Create wallet"}),f.jsx("p",{className:"vf-hint",style:{textAlign:"center",margin:0},children:"Set a password to encrypt your keys locally."})]}),f.jsx(Pr,{scope:"global"}),f.jsxs("label",{children:["Label",f.jsx("input",{placeholder:"Example: Main",value:i,onChange:E=>o(E.target.value)})]}),f.jsxs("label",{children:["Password",f.jsx("input",{type:"password",autoComplete:"new-password",placeholder:"12+ characters",value:a,onChange:E=>s(E.target.value)})]}),f.jsxs("label",{children:["Confirm password",f.jsx("input",{type:"password",autoComplete:"new-password",placeholder:"Re-enter password",value:u,onChange:E=>d(E.target.value)})]}),_&&a.length>0&&f.jsx("p",{className:"vf-hint",children:"Use 12+ characters."}),m&&u&&f.jsx("p",{className:"vf-error",children:"Passwords do not match."}),n&&f.jsx("p",{className:"vf-error",children:n}),f.jsx("button",{className:"vf-btn primary",disabled:r||_||m,onClick:()=>e(i,a),children:r?"Creating…":"Create wallet"}),f.jsx("button",{className:"vf-btn ghost",onClick:t,children:"Import an existing wallet"})]})}function xv(e=24,t=3,r=Math.random){const n=Math.min(t,e),i=new Set;for(;i.size<n;)i.add(Math.floor(r()*e));return[...i].sort((o,a)=>o-a)}function Wm(e,t){const r=e.trim().split(/\s+/);return t.every(n=>{var i;return((i=r[n.index])==null?void 0:i.toLowerCase())===String(n.word).trim().toLowerCase()})}function Vm({mnemonic:e,indices:t,onConfirm:r,onSkip:n,error:i}){const[o,a]=xe.useState(1),[s,u]=xe.useState(!1),[d,_]=xe.useState({}),[m,E]=xe.useState(!1),B=e.trim().split(/\s+/),R=xe.useCallback(async()=>{try{await navigator.clipboard.writeText(e.trim()),E(!0),setTimeout(()=>E(!1),2200)}catch{}},[e]);function N(){const P=t.map(p=>({index:p,word:d[p]??""}));Wm(e,P)&&r(P)}return f.jsxs("div",{className:"vf-screen vf-backup",children:[f.jsx(Km,{}),f.jsxs("div",{className:"bk-header",children:[f.jsx("div",{className:"bk-icon-wrap",children:f.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"var(--warn)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("path",{d:"M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"}),f.jsx("line",{x1:"12",y1:"9",x2:"12",y2:"13"}),f.jsx("line",{x1:"12",y1:"17",x2:"12.01",y2:"17"})]})}),f.jsx("h2",{style:{margin:0},children:"Recovery Phrase"}),f.jsx("p",{className:"vf-hint",style:{textAlign:"center",margin:0},children:"Your secret phrase is the only way to recover assets."})]}),f.jsxs("div",{className:"bk-progress",children:[[1,2,3].map(P=>f.jsxs("div",{className:"bk-prog-step"+(P<=o?" active":"")+(P===o?" current":""),children:[f.jsx("span",{className:"bk-prog-num",children:P}),f.jsx("span",{className:"bk-prog-label",children:P===1?"Reveal":P===2?"Save":"Verify"})]},P)),f.jsx("div",{className:"bk-prog-track",children:f.jsx("div",{className:"bk-prog-fill",style:{transform:`scaleX(${(o-1)/2})`}})})]}),f.jsx(Pr,{scope:"global"}),o===1&&f.jsxs("div",{className:"bk-step",children:[f.jsx("p",{className:"vf-warn",children:"Write these 24 words on paper in order. Keep them offline. If you lose them, your funds cannot be recovered."}),f.jsxs("div",{className:"bk-reveal-zone",children:[f.jsxs("svg",{width:"40",height:"40",viewBox:"0 0 24 24",fill:"none",stroke:"var(--text-faint)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",style:{opacity:.5},children:[f.jsx("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"}),f.jsx("circle",{cx:"12",cy:"12",r:"3"})]}),f.jsx("p",{className:"bk-reveal-hint",children:"Your recovery phrase is hidden"}),f.jsxs("button",{className:"vf-btn primary",onClick:()=>a(2),children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginRight:6},children:[f.jsx("path",{d:"M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"}),f.jsx("circle",{cx:"12",cy:"12",r:"3"})]}),"Reveal recovery phrase"]})]})]},"s1"),o===2&&f.jsxs("div",{className:"bk-step",children:[f.jsx("div",{className:"vf-phrase revealed","aria-live":"polite",children:B.map((P,p)=>f.jsxs("span",{className:"vf-word",spellCheck:!1,children:[f.jsxs("span",{className:"vf-word-idx",children:[p+1,"."]})," ",f.jsx("span",{className:"vf-word-text",children:P})]},p))}),f.jsx("button",{className:"bk-copy-btn"+(m?" copied":""),onClick:R,children:m?f.jsxs(f.Fragment,{children:[f.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:f.jsx("polyline",{points:"20 6 9 17 4 12"})}),"Copied!"]}):f.jsxs(f.Fragment,{children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),f.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]}),"Copy all words"]})}),f.jsxs("label",{className:"bk-saved-check",children:[f.jsx("input",{type:"checkbox",checked:s,onChange:P=>u(P.target.checked)}),f.jsx("span",{className:"bk-check-box",children:s&&f.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"3",strokeLinecap:"round",strokeLinejoin:"round",children:f.jsx("polyline",{points:"20 6 9 17 4 12"})})}),f.jsx("span",{className:"bk-check-text",children:"I've saved my recovery phrase securely"})]}),f.jsxs("button",{className:"vf-btn primary",onClick:()=>a(3),disabled:!s,children:["Continue to verification",f.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginLeft:6},children:f.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})})]}),f.jsx("button",{className:"vf-btn ghost",onClick:n,children:"Skip for now (risky)"})]},"s2"),o===3&&f.jsxs("div",{className:"bk-step",children:[f.jsxs("div",{className:"bk-confirm-info",children:[f.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),f.jsx("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]}),f.jsx("span",{children:"Confirm you saved it by entering these words:"})]}),f.jsx("div",{className:"bk-confirm-inputs",children:t.map(P=>f.jsxs("label",{className:"bk-input-group",children:[f.jsxs("span",{className:"bk-input-label",children:["Word #",P+1]}),f.jsx("input",{"aria-label":`word #${P+1}`,spellCheck:!1,autoComplete:"off",placeholder:`Enter word #${P+1}`,value:d[P]??"",onChange:p=>_(v=>({...v,[P]:p.target.value})),className:"bk-word-input"})]},P))}),i&&f.jsx("p",{className:"vf-error",children:i}),f.jsxs("button",{className:"vf-btn primary",onClick:N,children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",style:{marginRight:6},children:[f.jsx("path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14"}),f.jsx("polyline",{points:"22 4 12 14.01 9 11.01"})]}),"Confirm & finish"]}),f.jsxs("button",{className:"vf-btn ghost",onClick:()=>{a(2),u(!1)},children:[f.jsx("svg",{width:"12",height:"12",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginRight:4},children:f.jsx("path",{d:"M19 12H5M12 19l-7-7 7-7"})}),"View recovery phrase again"]})]},"s3")]})}function Km(){return f.jsx("style",{children:`
.bk-header {
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
}
.bk-icon-wrap {
  width: 48px; height: 48px; border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, var(--bg-elev) 0%, var(--bg-card) 100%);
  border: 1px solid var(--border-strong); margin-bottom: 4px;
  box-shadow: 0 4px 16px rgba(0,0,0,.25);
}

/* ── progress bar ── */
.bk-progress {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0;
  padding: 0 4px;
  margin: 8px 0 4px;
  position: relative;
}
.bk-prog-track {
  position: absolute;
  left: 16.67%; right: 16.67%;
  top: 12px;
  height: 2px;
  background: var(--border);
  border-radius: 2px;
  z-index: 0;
}
.bk-prog-fill {
  width: 100%;
  height: 100%;
  background: var(--accent, #cfff3d);
  border-radius: 2px;
  transform-origin: left;
  transition: transform 220ms cubic-bezier(.23,1,.32,1);
}
.bk-prog-step {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  z-index: 1;
  flex: 1;
}
.bk-prog-num {
  position: relative;
  z-index: 2;
  width: 24px; height: 24px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-family: var(--mono);
  font-size: 11px; font-weight: 700;
  background: var(--bg-canvas, #0e100c);
  border: 1.5px solid var(--border);
  color: var(--text-faint);
  transition: border-color 220ms cubic-bezier(.23,1,.32,1), color 160ms ease, background-color 220ms cubic-bezier(.23,1,.32,1), box-shadow 220ms cubic-bezier(.23,1,.32,1);
}
.bk-prog-step.active .bk-prog-num {
  border-color: var(--accent, #cfff3d);
  color: var(--accent, #cfff3d);
  background: #11140c;
}
.bk-prog-step.current .bk-prog-num {
  box-shadow: 0 0 12px rgba(207,255,61,.3);
}
.bk-prog-label {
  font-family: var(--mono);
  font-size: 9.5px;
  letter-spacing: .06em;
  text-transform: uppercase;
  color: var(--text-faint);
  transition: color 160ms ease;
}
.bk-prog-step.active .bk-prog-label { color: var(--text-muted); }
.bk-prog-step.current .bk-prog-label { color: var(--text); }

/* ── step animation ── */
.bk-step {
  display: flex;
  flex-direction: column;
  gap: 10px;
  animation: bk-fade-in 220ms cubic-bezier(.23,1,.32,1) both;
}
@keyframes bk-fade-in {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ── step 1: reveal zone ── */
.bk-reveal-zone {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 28px 16px;
  background: var(--bg-card);
  border: 1px dashed var(--border-strong);
  border-radius: var(--r-lg, 14px);
}
.bk-reveal-hint {
  margin: 0;
  font-family: var(--mono);
  font-size: 11.5px;
  color: var(--text-faint);
}

/* ── step 2: copy button ── */
.bk-copy-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  width: 100%;
  padding: 9px 12px;
  font-family: var(--mono);
  font-size: 12px; font-weight: 600;
  color: var(--text-muted);
  background: var(--bg-card);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-md, 8px);
  cursor: pointer;
  transition: background-color 160ms ease, border-color 160ms ease, color 160ms ease, transform 160ms cubic-bezier(.23,1,.32,1);
}
.bk-copy-btn:hover {
  background: var(--bg-elev);
  border-color: var(--accent, #cfff3d);
  color: var(--text);
}
.bk-copy-btn.copied {
  border-color: var(--accent, #cfff3d);
  color: var(--accent, #cfff3d);
  background: rgba(207,255,61,.06);
}
.bk-copy-btn:active { transform: scale(.97); }

/* ── checkbox ── */
.bk-saved-check {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  background: rgba(207,255,61,.04);
  border: 1px solid rgba(207,255,61,.12);
  border-radius: var(--r-md, 8px);
  cursor: pointer;
  transition: border-color 160ms ease;
}
.bk-saved-check:hover { border-color: rgba(207,255,61,.3); }
.bk-saved-check input { display: none; }
.bk-check-box {
  width: 18px; height: 18px;
  border-radius: 4px;
  border: 1.5px solid var(--border-strong);
  background: var(--bg-card);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  transition: border-color 160ms ease, background-color 160ms ease;
}
.bk-saved-check input:checked + .bk-check-box {
  border-color: var(--accent, #cfff3d);
  background: rgba(207,255,61,.1);
}
.bk-check-text {
  font-family: var(--mono);
  font-size: 11.5px;
  color: var(--text-muted);
  user-select: none;
}

/* ── step 3: confirm ── */
.bk-confirm-info {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 0;
  font-family: var(--mono);
  font-size: 12px;
  color: var(--text-muted);
}
.bk-confirm-inputs {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.bk-input-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.bk-input-label {
  font-family: var(--mono);
  font-size: 11px;
  color: var(--text-faint);
  letter-spacing: .03em;
}
.bk-word-input {
  font-family: var(--mono);
  font-size: 13px;
  padding: 9px 12px;
  background: var(--bg-card);
  border: 1px solid var(--border-strong);
  border-radius: var(--r-md, 8px);
  color: var(--text);
  outline: none;
  transition: border-color 200ms ease, box-shadow 200ms ease;
}
.bk-word-input:focus {
  border-color: var(--accent, #cfff3d);
  box-shadow: 0 0 0 2px rgba(207,255,61,.12);
}
.bk-word-input::placeholder { color: var(--text-faint); opacity: .6; }

@media (prefers-reduced-motion: reduce) {
  .bk-step { animation: none; }
  .bk-prog-fill,
  .bk-prog-num,
  .bk-copy-btn,
  .bk-check-box { transition: none; }
}
`})}function yi(e){if(!Number.isSafeInteger(e)||e<0)throw new Error(`positive integer expected, not ${e}`)}function qm(e){return e instanceof Uint8Array||e!=null&&typeof e=="object"&&e.constructor.name==="Uint8Array"}function Ol(e,...t){if(!qm(e))throw new Error("Uint8Array expected");if(t.length>0&&!t.includes(e.length))throw new Error(`Uint8Array expected of length ${t}, not of length=${e.length}`)}function bv(e){if(typeof e!="function"||typeof e.create!="function")throw new Error("Hash should be wrapped by utils.wrapConstructor");yi(e.outputLen),yi(e.blockLen)}function hl(e,t=!0){if(e.destroyed)throw new Error("Hash instance has been destroyed");if(t&&e.finished)throw new Error("Hash#digest() has already been called")}function Gm(e,t){Ol(e);const r=t.outputLen;if(e.length<r)throw new Error(`digestInto() expects output buffer of length at least ${r}`)}const Ns=typeof globalThis=="object"&&"crypto"in globalThis?globalThis.crypto:void 0;/*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */const Da=e=>new DataView(e.buffer,e.byteOffset,e.byteLength),Lr=(e,t)=>e<<32-t|e>>>t;new Uint8Array(new Uint32Array([287454020]).buffer)[0];function Ym(e){if(typeof e!="string")throw new Error(`utf8ToBytes expected string, got ${typeof e}`);return new Uint8Array(new TextEncoder().encode(e))}function Bo(e){return typeof e=="string"&&(e=Ym(e)),Ol(e),e}let wv=class{clone(){return this._cloneInto()}};const Qm={}.toString;function Xm(e,t){if(t!==void 0&&Qm.call(t)!=="[object Object]")throw new Error("Options should be object or undefined");return Object.assign(e,t)}function _v(e){const t=n=>e().update(Bo(n)).digest(),r=e();return t.outputLen=r.outputLen,t.blockLen=r.blockLen,t.create=()=>e(),t}function Zm(e=32){if(Ns&&typeof Ns.getRandomValues=="function")return Ns.getRandomValues(new Uint8Array(e));throw new Error("crypto.getRandomValues must be defined")}class kv extends wv{constructor(t,r){super(),this.finished=!1,this.destroyed=!1,bv(t);const n=Bo(r);if(this.iHash=t.create(),typeof this.iHash.update!="function")throw new Error("Expected instance of class which extends utils.Hash");this.blockLen=this.iHash.blockLen,this.outputLen=this.iHash.outputLen;const i=this.blockLen,o=new Uint8Array(i);o.set(n.length>i?t.create().update(n).digest():n);for(let a=0;a<o.length;a++)o[a]^=54;this.iHash.update(o),this.oHash=t.create();for(let a=0;a<o.length;a++)o[a]^=106;this.oHash.update(o),o.fill(0)}update(t){return hl(this),this.iHash.update(t),this}digestInto(t){hl(this),Ol(t,this.outputLen),this.finished=!0,this.iHash.digestInto(t),this.oHash.update(t),this.oHash.digestInto(t),this.destroy()}digest(){const t=new Uint8Array(this.oHash.outputLen);return this.digestInto(t),t}_cloneInto(t){t||(t=Object.create(Object.getPrototypeOf(this),{}));const{oHash:r,iHash:n,finished:i,destroyed:o,blockLen:a,outputLen:s}=this;return t=t,t.finished=i,t.destroyed=o,t.blockLen=a,t.outputLen=s,t.oHash=r._cloneInto(t.oHash),t.iHash=n._cloneInto(t.iHash),t}destroy(){this.destroyed=!0,this.oHash.destroy(),this.iHash.destroy()}}const Sv=(e,t,r)=>new kv(e,t).update(r).digest();Sv.create=(e,t)=>new kv(e,t);function Jm(e,t,r,n){bv(e);const i=Xm({dkLen:32,asyncTick:10},n),{c:o,dkLen:a,asyncTick:s}=i;if(yi(o),yi(a),yi(s),o<1)throw new Error("PBKDF2: iterations (c) should be >= 1");const u=Bo(t),d=Bo(r),_=new Uint8Array(a),m=Sv.create(e,u),E=m._cloneInto().update(d);return{c:o,dkLen:a,asyncTick:s,DK:_,PRF:m,PRFSalt:E}}function ex(e,t,r,n,i){return e.destroy(),t.destroy(),n&&n.destroy(),i.fill(0),r}function tx(e,t,r,n){const{c:i,dkLen:o,DK:a,PRF:s,PRFSalt:u}=Jm(e,t,r,n);let d;const _=new Uint8Array(4),m=Da(_),E=new Uint8Array(s.outputLen);for(let B=1,R=0;R<o;B++,R+=s.outputLen){const N=a.subarray(R,R+s.outputLen);m.setInt32(0,B,!1),(d=u._cloneInto(d)).update(_).digestInto(E),N.set(E.subarray(0,N.length));for(let P=1;P<i;P++){s._cloneInto(d).update(E).digestInto(E);for(let p=0;p<N.length;p++)N[p]^=E[p]}}return ex(s,u,a,d,E)}function rx(e,t,r,n){if(typeof e.setBigUint64=="function")return e.setBigUint64(t,r,n);const i=BigInt(32),o=BigInt(4294967295),a=Number(r>>i&o),s=Number(r&o),u=n?4:0,d=n?0:4;e.setUint32(t+u,a,n),e.setUint32(t+d,s,n)}const nx=(e,t,r)=>e&t^~e&r,ix=(e,t,r)=>e&t^e&r^t&r;class Ev extends wv{constructor(t,r,n,i){super(),this.blockLen=t,this.outputLen=r,this.padOffset=n,this.isLE=i,this.finished=!1,this.length=0,this.pos=0,this.destroyed=!1,this.buffer=new Uint8Array(t),this.view=Da(this.buffer)}update(t){hl(this);const{view:r,buffer:n,blockLen:i}=this;t=Bo(t);const o=t.length;for(let a=0;a<o;){const s=Math.min(i-this.pos,o-a);if(s===i){const u=Da(t);for(;i<=o-a;a+=i)this.process(u,a);continue}n.set(t.subarray(a,a+s),this.pos),this.pos+=s,a+=s,this.pos===i&&(this.process(r,0),this.pos=0)}return this.length+=t.length,this.roundClean(),this}digestInto(t){hl(this),Gm(t,this),this.finished=!0;const{buffer:r,view:n,blockLen:i,isLE:o}=this;let{pos:a}=this;r[a++]=128,this.buffer.subarray(a).fill(0),this.padOffset>i-a&&(this.process(n,0),a=0);for(let m=a;m<i;m++)r[m]=0;rx(n,i-8,BigInt(this.length*8),o),this.process(n,0);const s=Da(t),u=this.outputLen;if(u%4)throw new Error("_sha2: outputLen should be aligned to 32bit");const d=u/4,_=this.get();if(d>_.length)throw new Error("_sha2: outputLen bigger than state");for(let m=0;m<d;m++)s.setUint32(4*m,_[m],o)}digest(){const{buffer:t,outputLen:r}=this;this.digestInto(t);const n=t.slice(0,r);return this.destroy(),n}_cloneInto(t){t||(t=new this.constructor),t.set(...this.get());const{blockLen:r,buffer:n,length:i,finished:o,destroyed:a,pos:s}=this;return t.length=i,t.pos=s,t.finished=o,t.destroyed=a,i%r&&t.buffer.set(n),t}}const ox=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),en=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),tn=new Uint32Array(64);class ax extends Ev{constructor(){super(64,32,8,!1),this.A=en[0]|0,this.B=en[1]|0,this.C=en[2]|0,this.D=en[3]|0,this.E=en[4]|0,this.F=en[5]|0,this.G=en[6]|0,this.H=en[7]|0}get(){const{A:t,B:r,C:n,D:i,E:o,F:a,G:s,H:u}=this;return[t,r,n,i,o,a,s,u]}set(t,r,n,i,o,a,s,u){this.A=t|0,this.B=r|0,this.C=n|0,this.D=i|0,this.E=o|0,this.F=a|0,this.G=s|0,this.H=u|0}process(t,r){for(let m=0;m<16;m++,r+=4)tn[m]=t.getUint32(r,!1);for(let m=16;m<64;m++){const E=tn[m-15],B=tn[m-2],R=Lr(E,7)^Lr(E,18)^E>>>3,N=Lr(B,17)^Lr(B,19)^B>>>10;tn[m]=N+tn[m-7]+R+tn[m-16]|0}let{A:n,B:i,C:o,D:a,E:s,F:u,G:d,H:_}=this;for(let m=0;m<64;m++){const E=Lr(s,6)^Lr(s,11)^Lr(s,25),B=_+E+nx(s,u,d)+ox[m]+tn[m]|0,N=(Lr(n,2)^Lr(n,13)^Lr(n,22))+ix(n,i,o)|0;_=d,d=u,u=s,s=a+B|0,a=o,o=i,i=n,n=B+N|0}n=n+this.A|0,i=i+this.B|0,o=o+this.C|0,a=a+this.D|0,s=s+this.E|0,u=u+this.F|0,d=d+this.G|0,_=_+this.H|0,this.set(n,i,o,a,s,u,d,_)}roundClean(){tn.fill(0)}destroy(){this.set(0,0,0,0,0,0,0,0),this.buffer.fill(0)}}const lx=_v(()=>new ax),wa=BigInt(2**32-1),df=BigInt(32);function jv(e,t=!1){return t?{h:Number(e&wa),l:Number(e>>df&wa)}:{h:Number(e>>df&wa)|0,l:Number(e&wa)|0}}function sx(e,t=!1){let r=new Uint32Array(e.length),n=new Uint32Array(e.length);for(let i=0;i<e.length;i++){const{h:o,l:a}=jv(e[i],t);[r[i],n[i]]=[o,a]}return[r,n]}const ux=(e,t)=>BigInt(e>>>0)<<df|BigInt(t>>>0),fx=(e,t,r)=>e>>>r,cx=(e,t,r)=>e<<32-r|t>>>r,dx=(e,t,r)=>e>>>r|t<<32-r,hx=(e,t,r)=>e<<32-r|t>>>r,px=(e,t,r)=>e<<64-r|t>>>r-32,vx=(e,t,r)=>e>>>r-32|t<<64-r,yx=(e,t)=>t,gx=(e,t)=>e,mx=(e,t,r)=>e<<r|t>>>32-r,xx=(e,t,r)=>t<<r|e>>>32-r,bx=(e,t,r)=>t<<r-32|e>>>64-r,wx=(e,t,r)=>e<<r-32|t>>>64-r;function _x(e,t,r,n){const i=(t>>>0)+(n>>>0);return{h:e+r+(i/2**32|0)|0,l:i|0}}const kx=(e,t,r)=>(e>>>0)+(t>>>0)+(r>>>0),Sx=(e,t,r,n)=>t+r+n+(e/2**32|0)|0,Ex=(e,t,r,n)=>(e>>>0)+(t>>>0)+(r>>>0)+(n>>>0),jx=(e,t,r,n,i)=>t+r+n+i+(e/2**32|0)|0,Cx=(e,t,r,n,i)=>(e>>>0)+(t>>>0)+(r>>>0)+(n>>>0)+(i>>>0),Ax=(e,t,r,n,i,o)=>t+r+n+i+o+(e/2**32|0)|0,Oe={fromBig:jv,split:sx,toBig:ux,shrSH:fx,shrSL:cx,rotrSH:dx,rotrSL:hx,rotrBH:px,rotrBL:vx,rotr32H:yx,rotr32L:gx,rotlSH:mx,rotlSL:xx,rotlBH:bx,rotlBL:wx,add:_x,add3L:kx,add3H:Sx,add4L:Ex,add4H:jx,add5H:Ax,add5L:Cx},[Nx,Rx]=Oe.split(["0x428a2f98d728ae22","0x7137449123ef65cd","0xb5c0fbcfec4d3b2f","0xe9b5dba58189dbbc","0x3956c25bf348b538","0x59f111f1b605d019","0x923f82a4af194f9b","0xab1c5ed5da6d8118","0xd807aa98a3030242","0x12835b0145706fbe","0x243185be4ee4b28c","0x550c7dc3d5ffb4e2","0x72be5d74f27b896f","0x80deb1fe3b1696b1","0x9bdc06a725c71235","0xc19bf174cf692694","0xe49b69c19ef14ad2","0xefbe4786384f25e3","0x0fc19dc68b8cd5b5","0x240ca1cc77ac9c65","0x2de92c6f592b0275","0x4a7484aa6ea6e483","0x5cb0a9dcbd41fbd4","0x76f988da831153b5","0x983e5152ee66dfab","0xa831c66d2db43210","0xb00327c898fb213f","0xbf597fc7beef0ee4","0xc6e00bf33da88fc2","0xd5a79147930aa725","0x06ca6351e003826f","0x142929670a0e6e70","0x27b70a8546d22ffc","0x2e1b21385c26c926","0x4d2c6dfc5ac42aed","0x53380d139d95b3df","0x650a73548baf63de","0x766a0abb3c77b2a8","0x81c2c92e47edaee6","0x92722c851482353b","0xa2bfe8a14cf10364","0xa81a664bbc423001","0xc24b8b70d0f89791","0xc76c51a30654be30","0xd192e819d6ef5218","0xd69906245565a910","0xf40e35855771202a","0x106aa07032bbd1b8","0x19a4c116b8d2d0c8","0x1e376c085141ab53","0x2748774cdf8eeb99","0x34b0bcb5e19b48a8","0x391c0cb3c5c95a63","0x4ed8aa4ae3418acb","0x5b9cca4f7763e373","0x682e6ff3d6b2b8a3","0x748f82ee5defb2fc","0x78a5636f43172f60","0x84c87814a1f0ab72","0x8cc702081a6439ec","0x90befffa23631e28","0xa4506cebde82bde9","0xbef9a3f7b2c67915","0xc67178f2e372532b","0xca273eceea26619c","0xd186b8c721c0c207","0xeada7dd6cde0eb1e","0xf57d4f7fee6ed178","0x06f067aa72176fba","0x0a637dc5a2c898a6","0x113f9804bef90dae","0x1b710b35131c471b","0x28db77f523047d84","0x32caab7b40c72493","0x3c9ebe0a15c9bebc","0x431d67c49c100d4c","0x4cc5d4becb3e42b6","0x597f299cfc657e2a","0x5fcb6fab3ad6faec","0x6c44198c4a475817"].map(e=>BigInt(e))),rn=new Uint32Array(80),nn=new Uint32Array(80);let Tx=class extends Ev{constructor(){super(128,64,16,!1),this.Ah=1779033703,this.Al=-205731576,this.Bh=-1150833019,this.Bl=-2067093701,this.Ch=1013904242,this.Cl=-23791573,this.Dh=-1521486534,this.Dl=1595750129,this.Eh=1359893119,this.El=-1377402159,this.Fh=-1694144372,this.Fl=725511199,this.Gh=528734635,this.Gl=-79577749,this.Hh=1541459225,this.Hl=327033209}get(){const{Ah:t,Al:r,Bh:n,Bl:i,Ch:o,Cl:a,Dh:s,Dl:u,Eh:d,El:_,Fh:m,Fl:E,Gh:B,Gl:R,Hh:N,Hl:P}=this;return[t,r,n,i,o,a,s,u,d,_,m,E,B,R,N,P]}set(t,r,n,i,o,a,s,u,d,_,m,E,B,R,N,P){this.Ah=t|0,this.Al=r|0,this.Bh=n|0,this.Bl=i|0,this.Ch=o|0,this.Cl=a|0,this.Dh=s|0,this.Dl=u|0,this.Eh=d|0,this.El=_|0,this.Fh=m|0,this.Fl=E|0,this.Gh=B|0,this.Gl=R|0,this.Hh=N|0,this.Hl=P|0}process(t,r){for(let x=0;x<16;x++,r+=4)rn[x]=t.getUint32(r),nn[x]=t.getUint32(r+=4);for(let x=16;x<80;x++){const C=rn[x-15]|0,O=nn[x-15]|0,H=Oe.rotrSH(C,O,1)^Oe.rotrSH(C,O,8)^Oe.shrSH(C,O,7),Q=Oe.rotrSL(C,O,1)^Oe.rotrSL(C,O,8)^Oe.shrSL(C,O,7),V=rn[x-2]|0,X=nn[x-2]|0,pe=Oe.rotrSH(V,X,19)^Oe.rotrBH(V,X,61)^Oe.shrSH(V,X,6),De=Oe.rotrSL(V,X,19)^Oe.rotrBL(V,X,61)^Oe.shrSL(V,X,6),$e=Oe.add4L(Q,De,nn[x-7],nn[x-16]),_e=Oe.add4H($e,H,pe,rn[x-7],rn[x-16]);rn[x]=_e|0,nn[x]=$e|0}let{Ah:n,Al:i,Bh:o,Bl:a,Ch:s,Cl:u,Dh:d,Dl:_,Eh:m,El:E,Fh:B,Fl:R,Gh:N,Gl:P,Hh:p,Hl:v}=this;for(let x=0;x<80;x++){const C=Oe.rotrSH(m,E,14)^Oe.rotrSH(m,E,18)^Oe.rotrBH(m,E,41),O=Oe.rotrSL(m,E,14)^Oe.rotrSL(m,E,18)^Oe.rotrBL(m,E,41),H=m&B^~m&N,Q=E&R^~E&P,V=Oe.add5L(v,O,Q,Rx[x],nn[x]),X=Oe.add5H(V,p,C,H,Nx[x],rn[x]),pe=V|0,De=Oe.rotrSH(n,i,28)^Oe.rotrBH(n,i,34)^Oe.rotrBH(n,i,39),$e=Oe.rotrSL(n,i,28)^Oe.rotrBL(n,i,34)^Oe.rotrBL(n,i,39),_e=n&o^n&s^o&s,He=i&a^i&u^a&u;p=N|0,v=P|0,N=B|0,P=R|0,B=m|0,R=E|0,{h:m,l:E}=Oe.add(d|0,_|0,X|0,pe|0),d=s|0,_=u|0,s=o|0,u=a|0,o=n|0,a=i|0;const nt=Oe.add3L(pe,$e,He);n=Oe.add3H(nt,X,De,_e),i=nt|0}({h:n,l:i}=Oe.add(this.Ah|0,this.Al|0,n|0,i|0)),{h:o,l:a}=Oe.add(this.Bh|0,this.Bl|0,o|0,a|0),{h:s,l:u}=Oe.add(this.Ch|0,this.Cl|0,s|0,u|0),{h:d,l:_}=Oe.add(this.Dh|0,this.Dl|0,d|0,_|0),{h:m,l:E}=Oe.add(this.Eh|0,this.El|0,m|0,E|0),{h:B,l:R}=Oe.add(this.Fh|0,this.Fl|0,B|0,R|0),{h:N,l:P}=Oe.add(this.Gh|0,this.Gl|0,N|0,P|0),{h:p,l:v}=Oe.add(this.Hh|0,this.Hl|0,p|0,v|0),this.set(n,i,o,a,s,u,d,_,m,E,B,R,N,P,p,v)}roundClean(){rn.fill(0),nn.fill(0)}destroy(){this.buffer.fill(0),this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)}};const Lx=_v(()=>new Tx);/*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */function pl(e){return e instanceof Uint8Array||e!=null&&typeof e=="object"&&e.constructor.name==="Uint8Array"}function Bx(...e){const t=o=>o,r=(o,a)=>s=>o(a(s)),n=e.map(o=>o.encode).reduceRight(r,t),i=e.map(o=>o.decode).reduce(r,t);return{encode:n,decode:i}}function Px(e){return{encode:t=>{if(!Array.isArray(t)||t.length&&typeof t[0]!="number")throw new Error("alphabet.encode input should be an array of numbers");return t.map(r=>{if(r<0||r>=e.length)throw new Error(`Digit index outside alphabet: ${r} (alphabet: ${e.length})`);return e[r]})},decode:t=>{if(!Array.isArray(t)||t.length&&typeof t[0]!="string")throw new Error("alphabet.decode input should be array of strings");return t.map(r=>{if(typeof r!="string")throw new Error(`alphabet.decode: not string element=${r}`);const n=e.indexOf(r);if(n===-1)throw new Error(`Unknown letter: "${r}". Allowed: ${e}`);return n})}}}function Mx(e=""){if(typeof e!="string")throw new Error("join separator should be string");return{encode:t=>{if(!Array.isArray(t)||t.length&&typeof t[0]!="string")throw new Error("join.encode input should be array of strings");for(let r of t)if(typeof r!="string")throw new Error(`join.encode: non-string input=${r}`);return t.join(e)},decode:t=>{if(typeof t!="string")throw new Error("join.decode input should be string");return t.split(e)}}}function Ox(e,t="="){if(typeof t!="string")throw new Error("padding chr should be string");return{encode(r){if(!Array.isArray(r)||r.length&&typeof r[0]!="string")throw new Error("padding.encode input should be array of strings");for(let n of r)if(typeof n!="string")throw new Error(`padding.encode: non-string input=${n}`);for(;r.length*e%8;)r.push(t);return r},decode(r){if(!Array.isArray(r)||r.length&&typeof r[0]!="string")throw new Error("padding.encode input should be array of strings");for(let i of r)if(typeof i!="string")throw new Error(`padding.decode: non-string input=${i}`);let n=r.length;if(n*e%8)throw new Error("Invalid padding: string should have whole number of bytes");for(;n>0&&r[n-1]===t;n--)if(!((n-1)*e%8))throw new Error("Invalid padding: string has too much padding");return r.slice(0,n)}}}function hf(e,t,r){if(t<2)throw new Error(`convertRadix: wrong from=${t}, base cannot be less than 2`);if(r<2)throw new Error(`convertRadix: wrong to=${r}, base cannot be less than 2`);if(!Array.isArray(e))throw new Error("convertRadix: data should be array");if(!e.length)return[];let n=0;const i=[],o=Array.from(e);for(o.forEach(a=>{if(a<0||a>=t)throw new Error(`Wrong integer: ${a}`)});;){let a=0,s=!0;for(let u=n;u<o.length;u++){const d=o[u],_=t*a+d;if(!Number.isSafeInteger(_)||t*a/t!==a||_-d!==t*a)throw new Error("convertRadix: carry overflow");a=_%r;const m=Math.floor(_/r);if(o[u]=m,!Number.isSafeInteger(m)||m*r+a!==_)throw new Error("convertRadix: carry overflow");if(s)m?s=!1:n=u;else continue}if(i.push(a),s)break}for(let a=0;a<e.length-1&&e[a]===0;a++)i.push(0);return i.reverse()}const Cv=(e,t)=>t?Cv(t,e%t):e,vl=(e,t)=>e+(t-Cv(e,t));function pf(e,t,r,n){if(!Array.isArray(e))throw new Error("convertRadix2: data should be array");if(t<=0||t>32)throw new Error(`convertRadix2: wrong from=${t}`);if(r<=0||r>32)throw new Error(`convertRadix2: wrong to=${r}`);if(vl(t,r)>32)throw new Error(`convertRadix2: carry overflow from=${t} to=${r} carryBits=${vl(t,r)}`);let i=0,o=0;const a=2**r-1,s=[];for(const u of e){if(u>=2**t)throw new Error(`convertRadix2: invalid data word=${u} from=${t}`);if(i=i<<t|u,o+t>32)throw new Error(`convertRadix2: carry overflow pos=${o} from=${t}`);for(o+=t;o>=r;o-=r)s.push((i>>o-r&a)>>>0);i&=2**o-1}if(i=i<<r-o&a,!n&&o>=t)throw new Error("Excess padding");if(!n&&i)throw new Error(`Non-zero padding: ${i}`);return n&&o>0&&s.push(i>>>0),s}function Ix(e){return{encode:t=>{if(!pl(t))throw new Error("radix.encode input should be Uint8Array");return hf(Array.from(t),2**8,e)},decode:t=>{if(!Array.isArray(t)||t.length&&typeof t[0]!="number")throw new Error("radix.decode input should be array of numbers");return Uint8Array.from(hf(t,e,2**8))}}}function Dx(e,t=!1){if(e<=0||e>32)throw new Error("radix2: bits should be in (0..32]");if(vl(8,e)>32||vl(e,8)>32)throw new Error("radix2: carry overflow");return{encode:r=>{if(!pl(r))throw new Error("radix2.encode input should be Uint8Array");return pf(Array.from(r),8,e,!t)},decode:r=>{if(!Array.isArray(r)||r.length&&typeof r[0]!="number")throw new Error("radix2.decode input should be array of numbers");return Uint8Array.from(pf(r,e,8,t))}}}function Ux(e,t){if(typeof t!="function")throw new Error("checksum fn should be function");return{encode(r){if(!pl(r))throw new Error("checksum.encode: input should be Uint8Array");const n=t(r).slice(0,e),i=new Uint8Array(r.length+e);return i.set(r),i.set(n,r.length),i},decode(r){if(!pl(r))throw new Error("checksum.decode: input should be Uint8Array");const n=r.slice(0,-e),i=t(n).slice(0,e),o=r.slice(-e);for(let a=0;a<e;a++)if(i[a]!==o[a])throw new Error("Invalid checksum");return n}}}const _a={alphabet:Px,chain:Bx,checksum:Ux,convertRadix:hf,convertRadix2:pf,radix:Ix,radix2:Dx,join:Mx,padding:Ox};/*! scure-bip39 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */const Fx=e=>e[0]==="あいこくしん";function Av(e){if(typeof e!="string")throw new TypeError(`Invalid mnemonic type: ${typeof e}`);return e.normalize("NFKD")}function Nv(e){const t=Av(e),r=t.split(" ");if(![12,15,18,21,24].includes(r.length))throw new Error("Invalid mnemonic");return{nfkd:t,words:r}}function Rv(e){Ol(e,16,20,24,28,32)}function zx(e,t=128){if(yi(t),t%32!==0||t>256)throw new TypeError("Invalid entropy");return Wx(Zm(t/8),e)}const $x=e=>{const t=8-e.length/4;return new Uint8Array([lx(e)[0]>>t<<t])};function Tv(e){if(!Array.isArray(e)||e.length!==2048||typeof e[0]!="string")throw new Error("Wordlist: expected array of 2048 strings");return e.forEach(t=>{if(typeof t!="string")throw new Error(`Wordlist: non-string element: ${t}`)}),_a.chain(_a.checksum(1,$x),_a.radix2(11,!0),_a.alphabet(e))}function Hx(e,t){const{words:r}=Nv(e),n=Tv(t).decode(r);return Rv(n),n}function Wx(e,t){return Rv(e),Tv(t).encode(e).join(Fx(t)?"　":" ")}function Lv(e,t){try{Hx(e,t)}catch{return!1}return!0}const Vx=e=>Av(`mnemonic${e}`);function Kx(e,t=""){return tx(Lx,Nv(e).nfkd,Vx(t),{c:2048,dkLen:64})}const wc=`abandon
ability
able
about
above
absent
absorb
abstract
absurd
abuse
access
accident
account
accuse
achieve
acid
acoustic
acquire
across
act
action
actor
actress
actual
adapt
add
addict
address
adjust
admit
adult
advance
advice
aerobic
affair
afford
afraid
again
age
agent
agree
ahead
aim
air
airport
aisle
alarm
album
alcohol
alert
alien
all
alley
allow
almost
alone
alpha
already
also
alter
always
amateur
amazing
among
amount
amused
analyst
anchor
ancient
anger
angle
angry
animal
ankle
announce
annual
another
answer
antenna
antique
anxiety
any
apart
apology
appear
apple
approve
april
arch
arctic
area
arena
argue
arm
armed
armor
army
around
arrange
arrest
arrive
arrow
art
artefact
artist
artwork
ask
aspect
assault
asset
assist
assume
asthma
athlete
atom
attack
attend
attitude
attract
auction
audit
august
aunt
author
auto
autumn
average
avocado
avoid
awake
aware
away
awesome
awful
awkward
axis
baby
bachelor
bacon
badge
bag
balance
balcony
ball
bamboo
banana
banner
bar
barely
bargain
barrel
base
basic
basket
battle
beach
bean
beauty
because
become
beef
before
begin
behave
behind
believe
below
belt
bench
benefit
best
betray
better
between
beyond
bicycle
bid
bike
bind
biology
bird
birth
bitter
black
blade
blame
blanket
blast
bleak
bless
blind
blood
blossom
blouse
blue
blur
blush
board
boat
body
boil
bomb
bone
bonus
book
boost
border
boring
borrow
boss
bottom
bounce
box
boy
bracket
brain
brand
brass
brave
bread
breeze
brick
bridge
brief
bright
bring
brisk
broccoli
broken
bronze
broom
brother
brown
brush
bubble
buddy
budget
buffalo
build
bulb
bulk
bullet
bundle
bunker
burden
burger
burst
bus
business
busy
butter
buyer
buzz
cabbage
cabin
cable
cactus
cage
cake
call
calm
camera
camp
can
canal
cancel
candy
cannon
canoe
canvas
canyon
capable
capital
captain
car
carbon
card
cargo
carpet
carry
cart
case
cash
casino
castle
casual
cat
catalog
catch
category
cattle
caught
cause
caution
cave
ceiling
celery
cement
census
century
cereal
certain
chair
chalk
champion
change
chaos
chapter
charge
chase
chat
cheap
check
cheese
chef
cherry
chest
chicken
chief
child
chimney
choice
choose
chronic
chuckle
chunk
churn
cigar
cinnamon
circle
citizen
city
civil
claim
clap
clarify
claw
clay
clean
clerk
clever
click
client
cliff
climb
clinic
clip
clock
clog
close
cloth
cloud
clown
club
clump
cluster
clutch
coach
coast
coconut
code
coffee
coil
coin
collect
color
column
combine
come
comfort
comic
common
company
concert
conduct
confirm
congress
connect
consider
control
convince
cook
cool
copper
copy
coral
core
corn
correct
cost
cotton
couch
country
couple
course
cousin
cover
coyote
crack
cradle
craft
cram
crane
crash
crater
crawl
crazy
cream
credit
creek
crew
cricket
crime
crisp
critic
crop
cross
crouch
crowd
crucial
cruel
cruise
crumble
crunch
crush
cry
crystal
cube
culture
cup
cupboard
curious
current
curtain
curve
cushion
custom
cute
cycle
dad
damage
damp
dance
danger
daring
dash
daughter
dawn
day
deal
debate
debris
decade
december
decide
decline
decorate
decrease
deer
defense
define
defy
degree
delay
deliver
demand
demise
denial
dentist
deny
depart
depend
deposit
depth
deputy
derive
describe
desert
design
desk
despair
destroy
detail
detect
develop
device
devote
diagram
dial
diamond
diary
dice
diesel
diet
differ
digital
dignity
dilemma
dinner
dinosaur
direct
dirt
disagree
discover
disease
dish
dismiss
disorder
display
distance
divert
divide
divorce
dizzy
doctor
document
dog
doll
dolphin
domain
donate
donkey
donor
door
dose
double
dove
draft
dragon
drama
drastic
draw
dream
dress
drift
drill
drink
drip
drive
drop
drum
dry
duck
dumb
dune
during
dust
dutch
duty
dwarf
dynamic
eager
eagle
early
earn
earth
easily
east
easy
echo
ecology
economy
edge
edit
educate
effort
egg
eight
either
elbow
elder
electric
elegant
element
elephant
elevator
elite
else
embark
embody
embrace
emerge
emotion
employ
empower
empty
enable
enact
end
endless
endorse
enemy
energy
enforce
engage
engine
enhance
enjoy
enlist
enough
enrich
enroll
ensure
enter
entire
entry
envelope
episode
equal
equip
era
erase
erode
erosion
error
erupt
escape
essay
essence
estate
eternal
ethics
evidence
evil
evoke
evolve
exact
example
excess
exchange
excite
exclude
excuse
execute
exercise
exhaust
exhibit
exile
exist
exit
exotic
expand
expect
expire
explain
expose
express
extend
extra
eye
eyebrow
fabric
face
faculty
fade
faint
faith
fall
false
fame
family
famous
fan
fancy
fantasy
farm
fashion
fat
fatal
father
fatigue
fault
favorite
feature
february
federal
fee
feed
feel
female
fence
festival
fetch
fever
few
fiber
fiction
field
figure
file
film
filter
final
find
fine
finger
finish
fire
firm
first
fiscal
fish
fit
fitness
fix
flag
flame
flash
flat
flavor
flee
flight
flip
float
flock
floor
flower
fluid
flush
fly
foam
focus
fog
foil
fold
follow
food
foot
force
forest
forget
fork
fortune
forum
forward
fossil
foster
found
fox
fragile
frame
frequent
fresh
friend
fringe
frog
front
frost
frown
frozen
fruit
fuel
fun
funny
furnace
fury
future
gadget
gain
galaxy
gallery
game
gap
garage
garbage
garden
garlic
garment
gas
gasp
gate
gather
gauge
gaze
general
genius
genre
gentle
genuine
gesture
ghost
giant
gift
giggle
ginger
giraffe
girl
give
glad
glance
glare
glass
glide
glimpse
globe
gloom
glory
glove
glow
glue
goat
goddess
gold
good
goose
gorilla
gospel
gossip
govern
gown
grab
grace
grain
grant
grape
grass
gravity
great
green
grid
grief
grit
grocery
group
grow
grunt
guard
guess
guide
guilt
guitar
gun
gym
habit
hair
half
hammer
hamster
hand
happy
harbor
hard
harsh
harvest
hat
have
hawk
hazard
head
health
heart
heavy
hedgehog
height
hello
helmet
help
hen
hero
hidden
high
hill
hint
hip
hire
history
hobby
hockey
hold
hole
holiday
hollow
home
honey
hood
hope
horn
horror
horse
hospital
host
hotel
hour
hover
hub
huge
human
humble
humor
hundred
hungry
hunt
hurdle
hurry
hurt
husband
hybrid
ice
icon
idea
identify
idle
ignore
ill
illegal
illness
image
imitate
immense
immune
impact
impose
improve
impulse
inch
include
income
increase
index
indicate
indoor
industry
infant
inflict
inform
inhale
inherit
initial
inject
injury
inmate
inner
innocent
input
inquiry
insane
insect
inside
inspire
install
intact
interest
into
invest
invite
involve
iron
island
isolate
issue
item
ivory
jacket
jaguar
jar
jazz
jealous
jeans
jelly
jewel
job
join
joke
journey
joy
judge
juice
jump
jungle
junior
junk
just
kangaroo
keen
keep
ketchup
key
kick
kid
kidney
kind
kingdom
kiss
kit
kitchen
kite
kitten
kiwi
knee
knife
knock
know
lab
label
labor
ladder
lady
lake
lamp
language
laptop
large
later
latin
laugh
laundry
lava
law
lawn
lawsuit
layer
lazy
leader
leaf
learn
leave
lecture
left
leg
legal
legend
leisure
lemon
lend
length
lens
leopard
lesson
letter
level
liar
liberty
library
license
life
lift
light
like
limb
limit
link
lion
liquid
list
little
live
lizard
load
loan
lobster
local
lock
logic
lonely
long
loop
lottery
loud
lounge
love
loyal
lucky
luggage
lumber
lunar
lunch
luxury
lyrics
machine
mad
magic
magnet
maid
mail
main
major
make
mammal
man
manage
mandate
mango
mansion
manual
maple
marble
march
margin
marine
market
marriage
mask
mass
master
match
material
math
matrix
matter
maximum
maze
meadow
mean
measure
meat
mechanic
medal
media
melody
melt
member
memory
mention
menu
mercy
merge
merit
merry
mesh
message
metal
method
middle
midnight
milk
million
mimic
mind
minimum
minor
minute
miracle
mirror
misery
miss
mistake
mix
mixed
mixture
mobile
model
modify
mom
moment
monitor
monkey
monster
month
moon
moral
more
morning
mosquito
mother
motion
motor
mountain
mouse
move
movie
much
muffin
mule
multiply
muscle
museum
mushroom
music
must
mutual
myself
mystery
myth
naive
name
napkin
narrow
nasty
nation
nature
near
neck
need
negative
neglect
neither
nephew
nerve
nest
net
network
neutral
never
news
next
nice
night
noble
noise
nominee
noodle
normal
north
nose
notable
note
nothing
notice
novel
now
nuclear
number
nurse
nut
oak
obey
object
oblige
obscure
observe
obtain
obvious
occur
ocean
october
odor
off
offer
office
often
oil
okay
old
olive
olympic
omit
once
one
onion
online
only
open
opera
opinion
oppose
option
orange
orbit
orchard
order
ordinary
organ
orient
original
orphan
ostrich
other
outdoor
outer
output
outside
oval
oven
over
own
owner
oxygen
oyster
ozone
pact
paddle
page
pair
palace
palm
panda
panel
panic
panther
paper
parade
parent
park
parrot
party
pass
patch
path
patient
patrol
pattern
pause
pave
payment
peace
peanut
pear
peasant
pelican
pen
penalty
pencil
people
pepper
perfect
permit
person
pet
phone
photo
phrase
physical
piano
picnic
picture
piece
pig
pigeon
pill
pilot
pink
pioneer
pipe
pistol
pitch
pizza
place
planet
plastic
plate
play
please
pledge
pluck
plug
plunge
poem
poet
point
polar
pole
police
pond
pony
pool
popular
portion
position
possible
post
potato
pottery
poverty
powder
power
practice
praise
predict
prefer
prepare
present
pretty
prevent
price
pride
primary
print
priority
prison
private
prize
problem
process
produce
profit
program
project
promote
proof
property
prosper
protect
proud
provide
public
pudding
pull
pulp
pulse
pumpkin
punch
pupil
puppy
purchase
purity
purpose
purse
push
put
puzzle
pyramid
quality
quantum
quarter
question
quick
quit
quiz
quote
rabbit
raccoon
race
rack
radar
radio
rail
rain
raise
rally
ramp
ranch
random
range
rapid
rare
rate
rather
raven
raw
razor
ready
real
reason
rebel
rebuild
recall
receive
recipe
record
recycle
reduce
reflect
reform
refuse
region
regret
regular
reject
relax
release
relief
rely
remain
remember
remind
remove
render
renew
rent
reopen
repair
repeat
replace
report
require
rescue
resemble
resist
resource
response
result
retire
retreat
return
reunion
reveal
review
reward
rhythm
rib
ribbon
rice
rich
ride
ridge
rifle
right
rigid
ring
riot
ripple
risk
ritual
rival
river
road
roast
robot
robust
rocket
romance
roof
rookie
room
rose
rotate
rough
round
route
royal
rubber
rude
rug
rule
run
runway
rural
sad
saddle
sadness
safe
sail
salad
salmon
salon
salt
salute
same
sample
sand
satisfy
satoshi
sauce
sausage
save
say
scale
scan
scare
scatter
scene
scheme
school
science
scissors
scorpion
scout
scrap
screen
script
scrub
sea
search
season
seat
second
secret
section
security
seed
seek
segment
select
sell
seminar
senior
sense
sentence
series
service
session
settle
setup
seven
shadow
shaft
shallow
share
shed
shell
sheriff
shield
shift
shine
ship
shiver
shock
shoe
shoot
shop
short
shoulder
shove
shrimp
shrug
shuffle
shy
sibling
sick
side
siege
sight
sign
silent
silk
silly
silver
similar
simple
since
sing
siren
sister
situate
six
size
skate
sketch
ski
skill
skin
skirt
skull
slab
slam
sleep
slender
slice
slide
slight
slim
slogan
slot
slow
slush
small
smart
smile
smoke
smooth
snack
snake
snap
sniff
snow
soap
soccer
social
sock
soda
soft
solar
soldier
solid
solution
solve
someone
song
soon
sorry
sort
soul
sound
soup
source
south
space
spare
spatial
spawn
speak
special
speed
spell
spend
sphere
spice
spider
spike
spin
spirit
split
spoil
sponsor
spoon
sport
spot
spray
spread
spring
spy
square
squeeze
squirrel
stable
stadium
staff
stage
stairs
stamp
stand
start
state
stay
steak
steel
stem
step
stereo
stick
still
sting
stock
stomach
stone
stool
story
stove
strategy
street
strike
strong
struggle
student
stuff
stumble
style
subject
submit
subway
success
such
sudden
suffer
sugar
suggest
suit
summer
sun
sunny
sunset
super
supply
supreme
sure
surface
surge
surprise
surround
survey
suspect
sustain
swallow
swamp
swap
swarm
swear
sweet
swift
swim
swing
switch
sword
symbol
symptom
syrup
system
table
tackle
tag
tail
talent
talk
tank
tape
target
task
taste
tattoo
taxi
teach
team
tell
ten
tenant
tennis
tent
term
test
text
thank
that
theme
then
theory
there
they
thing
this
thought
three
thrive
throw
thumb
thunder
ticket
tide
tiger
tilt
timber
time
tiny
tip
tired
tissue
title
toast
tobacco
today
toddler
toe
together
toilet
token
tomato
tomorrow
tone
tongue
tonight
tool
tooth
top
topic
topple
torch
tornado
tortoise
toss
total
tourist
toward
tower
town
toy
track
trade
traffic
tragic
train
transfer
trap
trash
travel
tray
treat
tree
trend
trial
tribe
trick
trigger
trim
trip
trophy
trouble
truck
true
truly
trumpet
trust
truth
try
tube
tuition
tumble
tuna
tunnel
turkey
turn
turtle
twelve
twenty
twice
twin
twist
two
type
typical
ugly
umbrella
unable
unaware
uncle
uncover
under
undo
unfair
unfold
unhappy
uniform
unique
unit
universe
unknown
unlock
until
unusual
unveil
update
upgrade
uphold
upon
upper
upset
urban
urge
usage
use
used
useful
useless
usual
utility
vacant
vacuum
vague
valid
valley
valve
van
vanish
vapor
various
vast
vault
vehicle
velvet
vendor
venture
venue
verb
verify
version
very
vessel
veteran
viable
vibrant
vicious
victory
video
view
village
vintage
violin
virtual
virus
visa
visit
visual
vital
vivid
vocal
voice
void
volcano
volume
vote
voyage
wage
wagon
wait
walk
wall
walnut
want
warfare
warm
warrior
wash
wasp
waste
water
wave
way
wealth
weapon
wear
weasel
weather
web
wedding
weekend
weird
welcome
west
wet
whale
what
wheat
wheel
when
where
whip
whisper
wide
width
wife
wild
will
win
window
wine
wing
wink
winner
winter
wire
wisdom
wise
wish
witness
wolf
woman
wonder
wood
wool
word
work
world
worry
worth
wrap
wreck
wrestle
wrist
write
wrong
yard
year
yellow
you
young
youth
zebra
zero
zone
zoo`.split(`
`);var Bv={},vf={exports:{}};typeof Object.create=="function"?vf.exports=function(t,r){r&&(t.super_=r,t.prototype=Object.create(r.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}))}:vf.exports=function(t,r){if(r){t.super_=r;var n=function(){};n.prototype=r.prototype,t.prototype=new n,t.prototype.constructor=t}};var yt=vf.exports,yf={exports:{}};/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */(function(e,t){var r=Xr,n=r.Buffer;function i(a,s){for(var u in a)s[u]=a[u]}n.from&&n.alloc&&n.allocUnsafe&&n.allocUnsafeSlow?e.exports=r:(i(r,t),t.Buffer=o);function o(a,s,u){return n(a,s,u)}o.prototype=Object.create(n.prototype),i(n,o),o.from=function(a,s,u){if(typeof a=="number")throw new TypeError("Argument must not be a number");return n(a,s,u)},o.alloc=function(a,s,u){if(typeof a!="number")throw new TypeError("Argument must be a number");var d=n(a);return s!==void 0?typeof u=="string"?d.fill(s,u):d.fill(s):d.fill(0),d},o.allocUnsafe=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return n(a)},o.allocUnsafeSlow=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return r.SlowBuffer(a)}})(yf,yf.exports);var Qt=yf.exports,gf={exports:{}},_c={exports:{}},gi=typeof Reflect=="object"?Reflect:null,Gd=gi&&typeof gi.apply=="function"?gi.apply:function(t,r,n){return Function.prototype.apply.call(t,r,n)},Ua;gi&&typeof gi.ownKeys=="function"?Ua=gi.ownKeys:Object.getOwnPropertySymbols?Ua=function(t){return Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t))}:Ua=function(t){return Object.getOwnPropertyNames(t)};function qx(e){console&&console.warn&&console.warn(e)}var Pv=Number.isNaN||function(t){return t!==t};function rt(){rt.init.call(this)}_c.exports=rt;_c.exports.once=Xx;rt.EventEmitter=rt;rt.prototype._events=void 0;rt.prototype._eventsCount=0;rt.prototype._maxListeners=void 0;var Yd=10;function Il(e){if(typeof e!="function")throw new TypeError('The "listener" argument must be of type Function. Received type '+typeof e)}Object.defineProperty(rt,"defaultMaxListeners",{enumerable:!0,get:function(){return Yd},set:function(e){if(typeof e!="number"||e<0||Pv(e))throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received '+e+".");Yd=e}});rt.init=function(){(this._events===void 0||this._events===Object.getPrototypeOf(this)._events)&&(this._events=Object.create(null),this._eventsCount=0),this._maxListeners=this._maxListeners||void 0};rt.prototype.setMaxListeners=function(t){if(typeof t!="number"||t<0||Pv(t))throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received '+t+".");return this._maxListeners=t,this};function Mv(e){return e._maxListeners===void 0?rt.defaultMaxListeners:e._maxListeners}rt.prototype.getMaxListeners=function(){return Mv(this)};rt.prototype.emit=function(t){for(var r=[],n=1;n<arguments.length;n++)r.push(arguments[n]);var i=t==="error",o=this._events;if(o!==void 0)i=i&&o.error===void 0;else if(!i)return!1;if(i){var a;if(r.length>0&&(a=r[0]),a instanceof Error)throw a;var s=new Error("Unhandled error."+(a?" ("+a.message+")":""));throw s.context=a,s}var u=o[t];if(u===void 0)return!1;if(typeof u=="function")Gd(u,this,r);else for(var d=u.length,_=Fv(u,d),n=0;n<d;++n)Gd(_[n],this,r);return!0};function Ov(e,t,r,n){var i,o,a;if(Il(r),o=e._events,o===void 0?(o=e._events=Object.create(null),e._eventsCount=0):(o.newListener!==void 0&&(e.emit("newListener",t,r.listener?r.listener:r),o=e._events),a=o[t]),a===void 0)a=o[t]=r,++e._eventsCount;else if(typeof a=="function"?a=o[t]=n?[r,a]:[a,r]:n?a.unshift(r):a.push(r),i=Mv(e),i>0&&a.length>i&&!a.warned){a.warned=!0;var s=new Error("Possible EventEmitter memory leak detected. "+a.length+" "+String(t)+" listeners added. Use emitter.setMaxListeners() to increase limit");s.name="MaxListenersExceededWarning",s.emitter=e,s.type=t,s.count=a.length,qx(s)}return e}rt.prototype.addListener=function(t,r){return Ov(this,t,r,!1)};rt.prototype.on=rt.prototype.addListener;rt.prototype.prependListener=function(t,r){return Ov(this,t,r,!0)};function Gx(){if(!this.fired)return this.target.removeListener(this.type,this.wrapFn),this.fired=!0,arguments.length===0?this.listener.call(this.target):this.listener.apply(this.target,arguments)}function Iv(e,t,r){var n={fired:!1,wrapFn:void 0,target:e,type:t,listener:r},i=Gx.bind(n);return i.listener=r,n.wrapFn=i,i}rt.prototype.once=function(t,r){return Il(r),this.on(t,Iv(this,t,r)),this};rt.prototype.prependOnceListener=function(t,r){return Il(r),this.prependListener(t,Iv(this,t,r)),this};rt.prototype.removeListener=function(t,r){var n,i,o,a,s;if(Il(r),i=this._events,i===void 0)return this;if(n=i[t],n===void 0)return this;if(n===r||n.listener===r)--this._eventsCount===0?this._events=Object.create(null):(delete i[t],i.removeListener&&this.emit("removeListener",t,n.listener||r));else if(typeof n!="function"){for(o=-1,a=n.length-1;a>=0;a--)if(n[a]===r||n[a].listener===r){s=n[a].listener,o=a;break}if(o<0)return this;o===0?n.shift():Yx(n,o),n.length===1&&(i[t]=n[0]),i.removeListener!==void 0&&this.emit("removeListener",t,s||r)}return this};rt.prototype.off=rt.prototype.removeListener;rt.prototype.removeAllListeners=function(t){var r,n,i;if(n=this._events,n===void 0)return this;if(n.removeListener===void 0)return arguments.length===0?(this._events=Object.create(null),this._eventsCount=0):n[t]!==void 0&&(--this._eventsCount===0?this._events=Object.create(null):delete n[t]),this;if(arguments.length===0){var o=Object.keys(n),a;for(i=0;i<o.length;++i)a=o[i],a!=="removeListener"&&this.removeAllListeners(a);return this.removeAllListeners("removeListener"),this._events=Object.create(null),this._eventsCount=0,this}if(r=n[t],typeof r=="function")this.removeListener(t,r);else if(r!==void 0)for(i=r.length-1;i>=0;i--)this.removeListener(t,r[i]);return this};function Dv(e,t,r){var n=e._events;if(n===void 0)return[];var i=n[t];return i===void 0?[]:typeof i=="function"?r?[i.listener||i]:[i]:r?Qx(i):Fv(i,i.length)}rt.prototype.listeners=function(t){return Dv(this,t,!0)};rt.prototype.rawListeners=function(t){return Dv(this,t,!1)};rt.listenerCount=function(e,t){return typeof e.listenerCount=="function"?e.listenerCount(t):Uv.call(e,t)};rt.prototype.listenerCount=Uv;function Uv(e){var t=this._events;if(t!==void 0){var r=t[e];if(typeof r=="function")return 1;if(r!==void 0)return r.length}return 0}rt.prototype.eventNames=function(){return this._eventsCount>0?Ua(this._events):[]};function Fv(e,t){for(var r=new Array(t),n=0;n<t;++n)r[n]=e[n];return r}function Yx(e,t){for(;t+1<e.length;t++)e[t]=e[t+1];e.pop()}function Qx(e){for(var t=new Array(e.length),r=0;r<t.length;++r)t[r]=e[r].listener||e[r];return t}function Xx(e,t){return new Promise(function(r,n){function i(a){e.removeListener(t,o),n(a)}function o(){typeof e.removeListener=="function"&&e.removeListener("error",i),r([].slice.call(arguments))}zv(e,t,o,{once:!0}),t!=="error"&&Zx(e,i,{once:!0})})}function Zx(e,t,r){typeof e.on=="function"&&zv(e,"error",t,r)}function zv(e,t,r,n){if(typeof e.on=="function")n.once?e.once(t,r):e.on(t,r);else if(typeof e.addEventListener=="function")e.addEventListener(t,function i(o){n.once&&e.removeEventListener(t,i),r(o)});else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type '+typeof e)}var Dl=_c.exports,$v=Dl.EventEmitter;const Jx={},e2=Object.freeze(Object.defineProperty({__proto__:null,default:Jx},Symbol.toStringTag,{value:"Module"})),Ho=ry(e2);var Rs,Qd;function t2(){if(Qd)return Rs;Qd=1;function e(R,N){var P=Object.keys(R);if(Object.getOwnPropertySymbols){var p=Object.getOwnPropertySymbols(R);N&&(p=p.filter(function(v){return Object.getOwnPropertyDescriptor(R,v).enumerable})),P.push.apply(P,p)}return P}function t(R){for(var N=1;N<arguments.length;N++){var P=arguments[N]!=null?arguments[N]:{};N%2?e(Object(P),!0).forEach(function(p){r(R,p,P[p])}):Object.getOwnPropertyDescriptors?Object.defineProperties(R,Object.getOwnPropertyDescriptors(P)):e(Object(P)).forEach(function(p){Object.defineProperty(R,p,Object.getOwnPropertyDescriptor(P,p))})}return R}function r(R,N,P){return N=a(N),N in R?Object.defineProperty(R,N,{value:P,enumerable:!0,configurable:!0,writable:!0}):R[N]=P,R}function n(R,N){if(!(R instanceof N))throw new TypeError("Cannot call a class as a function")}function i(R,N){for(var P=0;P<N.length;P++){var p=N[P];p.enumerable=p.enumerable||!1,p.configurable=!0,"value"in p&&(p.writable=!0),Object.defineProperty(R,a(p.key),p)}}function o(R,N,P){return N&&i(R.prototype,N),Object.defineProperty(R,"prototype",{writable:!1}),R}function a(R){var N=s(R,"string");return typeof N=="symbol"?N:String(N)}function s(R,N){if(typeof R!="object"||R===null)return R;var P=R[Symbol.toPrimitive];if(P!==void 0){var p=P.call(R,N);if(typeof p!="object")return p;throw new TypeError("@@toPrimitive must return a primitive value.")}return String(R)}var u=Xr,d=u.Buffer,_=Ho,m=_.inspect,E=m&&m.custom||"inspect";function B(R,N,P){d.prototype.copy.call(R,N,P)}return Rs=function(){function R(){n(this,R),this.head=null,this.tail=null,this.length=0}return o(R,[{key:"push",value:function(P){var p={data:P,next:null};this.length>0?this.tail.next=p:this.head=p,this.tail=p,++this.length}},{key:"unshift",value:function(P){var p={data:P,next:this.head};this.length===0&&(this.tail=p),this.head=p,++this.length}},{key:"shift",value:function(){if(this.length!==0){var P=this.head.data;return this.length===1?this.head=this.tail=null:this.head=this.head.next,--this.length,P}}},{key:"clear",value:function(){this.head=this.tail=null,this.length=0}},{key:"join",value:function(P){if(this.length===0)return"";for(var p=this.head,v=""+p.data;p=p.next;)v+=P+p.data;return v}},{key:"concat",value:function(P){if(this.length===0)return d.alloc(0);for(var p=d.allocUnsafe(P>>>0),v=this.head,x=0;v;)B(v.data,p,x),x+=v.data.length,v=v.next;return p}},{key:"consume",value:function(P,p){var v;return P<this.head.data.length?(v=this.head.data.slice(0,P),this.head.data=this.head.data.slice(P)):P===this.head.data.length?v=this.shift():v=p?this._getString(P):this._getBuffer(P),v}},{key:"first",value:function(){return this.head.data}},{key:"_getString",value:function(P){var p=this.head,v=1,x=p.data;for(P-=x.length;p=p.next;){var C=p.data,O=P>C.length?C.length:P;if(O===C.length?x+=C:x+=C.slice(0,P),P-=O,P===0){O===C.length?(++v,p.next?this.head=p.next:this.head=this.tail=null):(this.head=p,p.data=C.slice(O));break}++v}return this.length-=v,x}},{key:"_getBuffer",value:function(P){var p=d.allocUnsafe(P),v=this.head,x=1;for(v.data.copy(p),P-=v.data.length;v=v.next;){var C=v.data,O=P>C.length?C.length:P;if(C.copy(p,p.length-P,0,O),P-=O,P===0){O===C.length?(++x,v.next?this.head=v.next:this.head=this.tail=null):(this.head=v,v.data=C.slice(O));break}++x}return this.length-=x,p}},{key:E,value:function(P,p){return m(this,t(t({},p),{},{depth:0,customInspect:!1}))}}]),R}(),Rs}function r2(e,t){var r=this,n=this._readableState&&this._readableState.destroyed,i=this._writableState&&this._writableState.destroyed;return n||i?(t?t(e):e&&(this._writableState?this._writableState.errorEmitted||(this._writableState.errorEmitted=!0,process.nextTick(mf,this,e)):process.nextTick(mf,this,e)),this):(this._readableState&&(this._readableState.destroyed=!0),this._writableState&&(this._writableState.destroyed=!0),this._destroy(e||null,function(o){!t&&o?r._writableState?r._writableState.errorEmitted?process.nextTick(Fa,r):(r._writableState.errorEmitted=!0,process.nextTick(Xd,r,o)):process.nextTick(Xd,r,o):t?(process.nextTick(Fa,r),t(o)):process.nextTick(Fa,r)}),this)}function Xd(e,t){mf(e,t),Fa(e)}function Fa(e){e._writableState&&!e._writableState.emitClose||e._readableState&&!e._readableState.emitClose||e.emit("close")}function n2(){this._readableState&&(this._readableState.destroyed=!1,this._readableState.reading=!1,this._readableState.ended=!1,this._readableState.endEmitted=!1),this._writableState&&(this._writableState.destroyed=!1,this._writableState.ended=!1,this._writableState.ending=!1,this._writableState.finalCalled=!1,this._writableState.prefinished=!1,this._writableState.finished=!1,this._writableState.errorEmitted=!1)}function mf(e,t){e.emit("error",t)}function i2(e,t){var r=e._readableState,n=e._writableState;r&&r.autoDestroy||n&&n.autoDestroy?e.destroy(t):e.emit("error",t)}var Hv={destroy:r2,undestroy:n2,errorOrDestroy:i2},Hn={};function o2(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,e.__proto__=t}var Wv={};function br(e,t,r){r||(r=Error);function n(o,a,s){return typeof t=="string"?t:t(o,a,s)}var i=function(o){o2(a,o);function a(s,u,d){return o.call(this,n(s,u,d))||this}return a}(r);i.prototype.name=r.name,i.prototype.code=e,Wv[e]=i}function Zd(e,t){if(Array.isArray(e)){var r=e.length;return e=e.map(function(n){return String(n)}),r>2?"one of ".concat(t," ").concat(e.slice(0,r-1).join(", "),", or ")+e[r-1]:r===2?"one of ".concat(t," ").concat(e[0]," or ").concat(e[1]):"of ".concat(t," ").concat(e[0])}else return"of ".concat(t," ").concat(String(e))}function a2(e,t,r){return e.substr(0,t.length)===t}function l2(e,t,r){return(r===void 0||r>e.length)&&(r=e.length),e.substring(r-t.length,r)===t}function s2(e,t,r){return typeof r!="number"&&(r=0),r+t.length>e.length?!1:e.indexOf(t,r)!==-1}br("ERR_INVALID_OPT_VALUE",function(e,t){return'The value "'+t+'" is invalid for option "'+e+'"'},TypeError);br("ERR_INVALID_ARG_TYPE",function(e,t,r){var n;typeof t=="string"&&a2(t,"not ")?(n="must not be",t=t.replace(/^not /,"")):n="must be";var i;if(l2(e," argument"))i="The ".concat(e," ").concat(n," ").concat(Zd(t,"type"));else{var o=s2(e,".")?"property":"argument";i='The "'.concat(e,'" ').concat(o," ").concat(n," ").concat(Zd(t,"type"))}return i+=". Received type ".concat(typeof r),i},TypeError);br("ERR_STREAM_PUSH_AFTER_EOF","stream.push() after EOF");br("ERR_METHOD_NOT_IMPLEMENTED",function(e){return"The "+e+" method is not implemented"});br("ERR_STREAM_PREMATURE_CLOSE","Premature close");br("ERR_STREAM_DESTROYED",function(e){return"Cannot call "+e+" after a stream was destroyed"});br("ERR_MULTIPLE_CALLBACK","Callback called multiple times");br("ERR_STREAM_CANNOT_PIPE","Cannot pipe, not readable");br("ERR_STREAM_WRITE_AFTER_END","write after end");br("ERR_STREAM_NULL_VALUES","May not write null values to stream",TypeError);br("ERR_UNKNOWN_ENCODING",function(e){return"Unknown encoding: "+e},TypeError);br("ERR_STREAM_UNSHIFT_AFTER_END_EVENT","stream.unshift() after end event");Hn.codes=Wv;var u2=Hn.codes.ERR_INVALID_OPT_VALUE;function f2(e,t,r){return e.highWaterMark!=null?e.highWaterMark:t?e[r]:null}function c2(e,t,r,n){var i=f2(t,n,r);if(i!=null){if(!(isFinite(i)&&Math.floor(i)===i)||i<0){var o=n?r:"highWaterMark";throw new u2(o,i)}return Math.floor(i)}return e.objectMode?16:16*1024}var Vv={getHighWaterMark:c2},Kv=d2;function d2(e,t){if(Ts("noDeprecation"))return e;var r=!1;function n(){if(!r){if(Ts("throwDeprecation"))throw new Error(t);Ts("traceDeprecation")?console.trace(t):console.warn(t),r=!0}return e.apply(this,arguments)}return n}function Ts(e){try{if(!gr.localStorage)return!1}catch{return!1}var t=gr.localStorage[e];return t==null?!1:String(t).toLowerCase()==="true"}var Ls,Jd;function qv(){if(Jd)return Ls;Jd=1,Ls=V;function e(T){var h=this;this.next=null,this.entry=null,this.finish=function(){ge(h,T)}}var t;V.WritableState=H;var r={deprecate:Kv},n=$v,i=Xr.Buffer,o=(typeof gr<"u"?gr:typeof window<"u"?window:typeof self<"u"?self:{}).Uint8Array||function(){};function a(T){return i.from(T)}function s(T){return i.isBuffer(T)||T instanceof o}var u=Hv,d=Vv,_=d.getHighWaterMark,m=Hn.codes,E=m.ERR_INVALID_ARG_TYPE,B=m.ERR_METHOD_NOT_IMPLEMENTED,R=m.ERR_MULTIPLE_CALLBACK,N=m.ERR_STREAM_CANNOT_PIPE,P=m.ERR_STREAM_DESTROYED,p=m.ERR_STREAM_NULL_VALUES,v=m.ERR_STREAM_WRITE_AFTER_END,x=m.ERR_UNKNOWN_ENCODING,C=u.errorOrDestroy;yt(V,n);function O(){}function H(T,h,b){t=t||ji(),T=T||{},typeof b!="boolean"&&(b=h instanceof t),this.objectMode=!!T.objectMode,b&&(this.objectMode=this.objectMode||!!T.writableObjectMode),this.highWaterMark=_(this,T,"writableHighWaterMark",b),this.finalCalled=!1,this.needDrain=!1,this.ending=!1,this.ended=!1,this.finished=!1,this.destroyed=!1;var F=T.decodeStrings===!1;this.decodeStrings=!F,this.defaultEncoding=T.defaultEncoding||"utf8",this.length=0,this.writing=!1,this.corked=0,this.sync=!0,this.bufferProcessing=!1,this.onwrite=function(K){tt(h,K)},this.writecb=null,this.writelen=0,this.bufferedRequest=null,this.lastBufferedRequest=null,this.pendingcb=0,this.prefinished=!1,this.errorEmitted=!1,this.emitClose=T.emitClose!==!1,this.autoDestroy=!!T.autoDestroy,this.bufferedRequestCount=0,this.corkedRequestsFree=new e(this)}H.prototype.getBuffer=function(){for(var h=this.bufferedRequest,b=[];h;)b.push(h),h=h.next;return b},function(){try{Object.defineProperty(H.prototype,"buffer",{get:r.deprecate(function(){return this.getBuffer()},"_writableState.buffer is deprecated. Use _writableState.getBuffer instead.","DEP0003")})}catch{}}();var Q;typeof Symbol=="function"&&Symbol.hasInstance&&typeof Function.prototype[Symbol.hasInstance]=="function"?(Q=Function.prototype[Symbol.hasInstance],Object.defineProperty(V,Symbol.hasInstance,{value:function(h){return Q.call(this,h)?!0:this!==V?!1:h&&h._writableState instanceof H}})):Q=function(h){return h instanceof this};function V(T){t=t||ji();var h=this instanceof t;if(!h&&!Q.call(V,this))return new V(T);this._writableState=new H(T,this,h),this.writable=!0,T&&(typeof T.write=="function"&&(this._write=T.write),typeof T.writev=="function"&&(this._writev=T.writev),typeof T.destroy=="function"&&(this._destroy=T.destroy),typeof T.final=="function"&&(this._final=T.final)),n.call(this)}V.prototype.pipe=function(){C(this,new N)};function X(T,h){var b=new v;C(T,b),process.nextTick(h,b)}function pe(T,h,b,F){var K;return b===null?K=new p:typeof b!="string"&&!h.objectMode&&(K=new E("chunk",["string","Buffer"],b)),K?(C(T,K),process.nextTick(F,K),!1):!0}V.prototype.write=function(T,h,b){var F=this._writableState,K=!1,S=!F.objectMode&&s(T);return S&&!i.isBuffer(T)&&(T=a(T)),typeof h=="function"&&(b=h,h=null),S?h="buffer":h||(h=F.defaultEncoding),typeof b!="function"&&(b=O),F.ending?X(this,b):(S||pe(this,F,T,b))&&(F.pendingcb++,K=$e(this,F,S,T,h,b)),K},V.prototype.cork=function(){this._writableState.corked++},V.prototype.uncork=function(){var T=this._writableState;T.corked&&(T.corked--,!T.writing&&!T.corked&&!T.bufferProcessing&&T.bufferedRequest&&D(this,T))},V.prototype.setDefaultEncoding=function(h){if(typeof h=="string"&&(h=h.toLowerCase()),!(["hex","utf8","utf-8","ascii","binary","base64","ucs2","ucs-2","utf16le","utf-16le","raw"].indexOf((h+"").toLowerCase())>-1))throw new x(h);return this._writableState.defaultEncoding=h,this},Object.defineProperty(V.prototype,"writableBuffer",{enumerable:!1,get:function(){return this._writableState&&this._writableState.getBuffer()}});function De(T,h,b){return!T.objectMode&&T.decodeStrings!==!1&&typeof h=="string"&&(h=i.from(h,b)),h}Object.defineProperty(V.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}});function $e(T,h,b,F,K,S){if(!b){var k=De(h,F,K);F!==k&&(b=!0,K="buffer",F=k)}var U=h.objectMode?1:F.length;h.length+=U;var ie=h.length<h.highWaterMark;if(ie||(h.needDrain=!0),h.writing||h.corked){var Xe=h.lastBufferedRequest;h.lastBufferedRequest={chunk:F,encoding:K,isBuf:b,callback:S,next:null},Xe?Xe.next=h.lastBufferedRequest:h.bufferedRequest=h.lastBufferedRequest,h.bufferedRequestCount+=1}else _e(T,h,!1,U,F,K,S);return ie}function _e(T,h,b,F,K,S,k){h.writelen=F,h.writecb=k,h.writing=!0,h.sync=!0,h.destroyed?h.onwrite(new P("write")):b?T._writev(K,h.onwrite):T._write(K,S,h.onwrite),h.sync=!1}function He(T,h,b,F,K){--h.pendingcb,b?(process.nextTick(K,F),process.nextTick(Ne,T,h),T._writableState.errorEmitted=!0,C(T,F)):(K(F),T._writableState.errorEmitted=!0,C(T,F),Ne(T,h))}function nt(T){T.writing=!1,T.writecb=null,T.length-=T.writelen,T.writelen=0}function tt(T,h){var b=T._writableState,F=b.sync,K=b.writecb;if(typeof K!="function")throw new R;if(nt(b),h)He(T,b,F,h,K);else{var S=J(b)||T.destroyed;!S&&!b.corked&&!b.bufferProcessing&&b.bufferedRequest&&D(T,b),F?process.nextTick(I,T,b,S,K):I(T,b,S,K)}}function I(T,h,b,F){b||A(T,h),h.pendingcb--,F(),Ne(T,h)}function A(T,h){h.length===0&&h.needDrain&&(h.needDrain=!1,T.emit("drain"))}function D(T,h){h.bufferProcessing=!0;var b=h.bufferedRequest;if(T._writev&&b&&b.next){var F=h.bufferedRequestCount,K=new Array(F),S=h.corkedRequestsFree;S.entry=b;for(var k=0,U=!0;b;)K[k]=b,b.isBuf||(U=!1),b=b.next,k+=1;K.allBuffers=U,_e(T,h,!0,h.length,K,"",S.finish),h.pendingcb++,h.lastBufferedRequest=null,S.next?(h.corkedRequestsFree=S.next,S.next=null):h.corkedRequestsFree=new e(h),h.bufferedRequestCount=0}else{for(;b;){var ie=b.chunk,Xe=b.encoding,Ce=b.callback,Ke=h.objectMode?1:ie.length;if(_e(T,h,!1,Ke,ie,Xe,Ce),b=b.next,h.bufferedRequestCount--,h.writing)break}b===null&&(h.lastBufferedRequest=null)}h.bufferedRequest=b,h.bufferProcessing=!1}V.prototype._write=function(T,h,b){b(new B("_write()"))},V.prototype._writev=null,V.prototype.end=function(T,h,b){var F=this._writableState;return typeof T=="function"?(b=T,T=null,h=null):typeof h=="function"&&(b=h,h=null),T!=null&&this.write(T,h),F.corked&&(F.corked=1,this.uncork()),F.ending||Re(this,F,b),this},Object.defineProperty(V.prototype,"writableLength",{enumerable:!1,get:function(){return this._writableState.length}});function J(T){return T.ending&&T.length===0&&T.bufferedRequest===null&&!T.finished&&!T.writing}function le(T,h){T._final(function(b){h.pendingcb--,b&&C(T,b),h.prefinished=!0,T.emit("prefinish"),Ne(T,h)})}function de(T,h){!h.prefinished&&!h.finalCalled&&(typeof T._final=="function"&&!h.destroyed?(h.pendingcb++,h.finalCalled=!0,process.nextTick(le,T,h)):(h.prefinished=!0,T.emit("prefinish")))}function Ne(T,h){var b=J(h);if(b&&(de(T,h),h.pendingcb===0&&(h.finished=!0,T.emit("finish"),h.autoDestroy))){var F=T._readableState;(!F||F.autoDestroy&&F.endEmitted)&&T.destroy()}return b}function Re(T,h,b){h.ending=!0,Ne(T,h),b&&(h.finished?process.nextTick(b):T.once("finish",b)),h.ended=!0,T.writable=!1}function ge(T,h,b){var F=T.entry;for(T.entry=null;F;){var K=F.callback;h.pendingcb--,K(b),F=F.next}h.corkedRequestsFree.next=T}return Object.defineProperty(V.prototype,"destroyed",{enumerable:!1,get:function(){return this._writableState===void 0?!1:this._writableState.destroyed},set:function(h){this._writableState&&(this._writableState.destroyed=h)}}),V.prototype.destroy=u.destroy,V.prototype._undestroy=u.undestroy,V.prototype._destroy=function(T,h){h(T)},Ls}var Bs,eh;function ji(){if(eh)return Bs;eh=1;var e=Object.keys||function(d){var _=[];for(var m in d)_.push(m);return _};Bs=a;var t=Yv(),r=qv();yt(a,t);for(var n=e(r.prototype),i=0;i<n.length;i++){var o=n[i];a.prototype[o]||(a.prototype[o]=r.prototype[o])}function a(d){if(!(this instanceof a))return new a(d);t.call(this,d),r.call(this,d),this.allowHalfOpen=!0,d&&(d.readable===!1&&(this.readable=!1),d.writable===!1&&(this.writable=!1),d.allowHalfOpen===!1&&(this.allowHalfOpen=!1,this.once("end",s)))}Object.defineProperty(a.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}}),Object.defineProperty(a.prototype,"writableBuffer",{enumerable:!1,get:function(){return this._writableState&&this._writableState.getBuffer()}}),Object.defineProperty(a.prototype,"writableLength",{enumerable:!1,get:function(){return this._writableState.length}});function s(){this._writableState.ended||process.nextTick(u,this)}function u(d){d.end()}return Object.defineProperty(a.prototype,"destroyed",{enumerable:!1,get:function(){return this._readableState===void 0||this._writableState===void 0?!1:this._readableState.destroyed&&this._writableState.destroyed},set:function(_){this._readableState===void 0||this._writableState===void 0||(this._readableState.destroyed=_,this._writableState.destroyed=_)}}),Bs}var yl={},kc=Qt.Buffer,th=kc.isEncoding||function(e){switch(e=""+e,e&&e.toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":case"raw":return!0;default:return!1}};function h2(e){if(!e)return"utf8";for(var t;;)switch(e){case"utf8":case"utf-8":return"utf8";case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return"utf16le";case"latin1":case"binary":return"latin1";case"base64":case"ascii":case"hex":return e;default:if(t)return;e=(""+e).toLowerCase(),t=!0}}function p2(e){var t=h2(e);if(typeof t!="string"&&(kc.isEncoding===th||!th(e)))throw new Error("Unknown encoding: "+e);return t||e}yl.StringDecoder=Wo;function Wo(e){this.encoding=p2(e);var t;switch(this.encoding){case"utf16le":this.text=b2,this.end=w2,t=4;break;case"utf8":this.fillLast=g2,t=4;break;case"base64":this.text=_2,this.end=k2,t=3;break;default:this.write=S2,this.end=E2;return}this.lastNeed=0,this.lastTotal=0,this.lastChar=kc.allocUnsafe(t)}Wo.prototype.write=function(e){if(e.length===0)return"";var t,r;if(this.lastNeed){if(t=this.fillLast(e),t===void 0)return"";r=this.lastNeed,this.lastNeed=0}else r=0;return r<e.length?t?t+this.text(e,r):this.text(e,r):t||""};Wo.prototype.end=x2;Wo.prototype.text=m2;Wo.prototype.fillLast=function(e){if(this.lastNeed<=e.length)return e.copy(this.lastChar,this.lastTotal-this.lastNeed,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal);e.copy(this.lastChar,this.lastTotal-this.lastNeed,0,e.length),this.lastNeed-=e.length};function Ps(e){return e<=127?0:e>>5===6?2:e>>4===14?3:e>>3===30?4:e>>6===2?-1:-2}function v2(e,t,r){var n=t.length-1;if(n<r)return 0;var i=Ps(t[n]);return i>=0?(i>0&&(e.lastNeed=i-1),i):--n<r||i===-2?0:(i=Ps(t[n]),i>=0?(i>0&&(e.lastNeed=i-2),i):--n<r||i===-2?0:(i=Ps(t[n]),i>=0?(i>0&&(i===2?i=0:e.lastNeed=i-3),i):0))}function y2(e,t,r){if((t[0]&192)!==128)return e.lastNeed=0,"�";if(e.lastNeed>1&&t.length>1){if((t[1]&192)!==128)return e.lastNeed=1,"�";if(e.lastNeed>2&&t.length>2&&(t[2]&192)!==128)return e.lastNeed=2,"�"}}function g2(e){var t=this.lastTotal-this.lastNeed,r=y2(this,e);if(r!==void 0)return r;if(this.lastNeed<=e.length)return e.copy(this.lastChar,t,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal);e.copy(this.lastChar,t,0,e.length),this.lastNeed-=e.length}function m2(e,t){var r=v2(this,e,t);if(!this.lastNeed)return e.toString("utf8",t);this.lastTotal=r;var n=e.length-(r-this.lastNeed);return e.copy(this.lastChar,0,n),e.toString("utf8",t,n)}function x2(e){var t=e&&e.length?this.write(e):"";return this.lastNeed?t+"�":t}function b2(e,t){if((e.length-t)%2===0){var r=e.toString("utf16le",t);if(r){var n=r.charCodeAt(r.length-1);if(n>=55296&&n<=56319)return this.lastNeed=2,this.lastTotal=4,this.lastChar[0]=e[e.length-2],this.lastChar[1]=e[e.length-1],r.slice(0,-1)}return r}return this.lastNeed=1,this.lastTotal=2,this.lastChar[0]=e[e.length-1],e.toString("utf16le",t,e.length-1)}function w2(e){var t=e&&e.length?this.write(e):"";if(this.lastNeed){var r=this.lastTotal-this.lastNeed;return t+this.lastChar.toString("utf16le",0,r)}return t}function _2(e,t){var r=(e.length-t)%3;return r===0?e.toString("base64",t):(this.lastNeed=3-r,this.lastTotal=3,r===1?this.lastChar[0]=e[e.length-1]:(this.lastChar[0]=e[e.length-2],this.lastChar[1]=e[e.length-1]),e.toString("base64",t,e.length-r))}function k2(e){var t=e&&e.length?this.write(e):"";return this.lastNeed?t+this.lastChar.toString("base64",0,3-this.lastNeed):t}function S2(e){return e.toString(this.encoding)}function E2(e){return e&&e.length?this.write(e):""}var rh=Hn.codes.ERR_STREAM_PREMATURE_CLOSE;function j2(e){var t=!1;return function(){if(!t){t=!0;for(var r=arguments.length,n=new Array(r),i=0;i<r;i++)n[i]=arguments[i];e.apply(this,n)}}}function C2(){}function A2(e){return e.setHeader&&typeof e.abort=="function"}function Gv(e,t,r){if(typeof t=="function")return Gv(e,null,t);t||(t={}),r=j2(r||C2);var n=t.readable||t.readable!==!1&&e.readable,i=t.writable||t.writable!==!1&&e.writable,o=function(){e.writable||s()},a=e._writableState&&e._writableState.finished,s=function(){i=!1,a=!0,n||r.call(e)},u=e._readableState&&e._readableState.endEmitted,d=function(){n=!1,u=!0,i||r.call(e)},_=function(R){r.call(e,R)},m=function(){var R;if(n&&!u)return(!e._readableState||!e._readableState.ended)&&(R=new rh),r.call(e,R);if(i&&!a)return(!e._writableState||!e._writableState.ended)&&(R=new rh),r.call(e,R)},E=function(){e.req.on("finish",s)};return A2(e)?(e.on("complete",s),e.on("abort",m),e.req?E():e.on("request",E)):i&&!e._writableState&&(e.on("end",o),e.on("close",o)),e.on("end",d),e.on("finish",s),t.error!==!1&&e.on("error",_),e.on("close",m),function(){e.removeListener("complete",s),e.removeListener("abort",m),e.removeListener("request",E),e.req&&e.req.removeListener("finish",s),e.removeListener("end",o),e.removeListener("close",o),e.removeListener("finish",s),e.removeListener("end",d),e.removeListener("error",_),e.removeListener("close",m)}}var Sc=Gv,Ms,nh;function N2(){if(nh)return Ms;nh=1;var e;function t(x,C,O){return C=r(C),C in x?Object.defineProperty(x,C,{value:O,enumerable:!0,configurable:!0,writable:!0}):x[C]=O,x}function r(x){var C=n(x,"string");return typeof C=="symbol"?C:String(C)}function n(x,C){if(typeof x!="object"||x===null)return x;var O=x[Symbol.toPrimitive];if(O!==void 0){var H=O.call(x,C);if(typeof H!="object")return H;throw new TypeError("@@toPrimitive must return a primitive value.")}return(C==="string"?String:Number)(x)}var i=Sc,o=Symbol("lastResolve"),a=Symbol("lastReject"),s=Symbol("error"),u=Symbol("ended"),d=Symbol("lastPromise"),_=Symbol("handlePromise"),m=Symbol("stream");function E(x,C){return{value:x,done:C}}function B(x){var C=x[o];if(C!==null){var O=x[m].read();O!==null&&(x[d]=null,x[o]=null,x[a]=null,C(E(O,!1)))}}function R(x){process.nextTick(B,x)}function N(x,C){return function(O,H){x.then(function(){if(C[u]){O(E(void 0,!0));return}C[_](O,H)},H)}}var P=Object.getPrototypeOf(function(){}),p=Object.setPrototypeOf((e={get stream(){return this[m]},next:function(){var C=this,O=this[s];if(O!==null)return Promise.reject(O);if(this[u])return Promise.resolve(E(void 0,!0));if(this[m].destroyed)return new Promise(function(X,pe){process.nextTick(function(){C[s]?pe(C[s]):X(E(void 0,!0))})});var H=this[d],Q;if(H)Q=new Promise(N(H,this));else{var V=this[m].read();if(V!==null)return Promise.resolve(E(V,!1));Q=new Promise(this[_])}return this[d]=Q,Q}},t(e,Symbol.asyncIterator,function(){return this}),t(e,"return",function(){var C=this;return new Promise(function(O,H){C[m].destroy(null,function(Q){if(Q){H(Q);return}O(E(void 0,!0))})})}),e),P),v=function(C){var O,H=Object.create(p,(O={},t(O,m,{value:C,writable:!0}),t(O,o,{value:null,writable:!0}),t(O,a,{value:null,writable:!0}),t(O,s,{value:null,writable:!0}),t(O,u,{value:C._readableState.endEmitted,writable:!0}),t(O,_,{value:function(V,X){var pe=H[m].read();pe?(H[d]=null,H[o]=null,H[a]=null,V(E(pe,!1))):(H[o]=V,H[a]=X)},writable:!0}),O));return H[d]=null,i(C,function(Q){if(Q&&Q.code!=="ERR_STREAM_PREMATURE_CLOSE"){var V=H[a];V!==null&&(H[d]=null,H[o]=null,H[a]=null,V(Q)),H[s]=Q;return}var X=H[o];X!==null&&(H[d]=null,H[o]=null,H[a]=null,X(E(void 0,!0))),H[u]=!0}),C.on("readable",R.bind(null,H)),H};return Ms=v,Ms}var Os,ih;function R2(){return ih||(ih=1,Os=function(){throw new Error("Readable.from is not available in the browser")}),Os}var Is,oh;function Yv(){if(oh)return Is;oh=1,Is=X;var e;X.ReadableState=V,Dl.EventEmitter;var t=function(k,U){return k.listeners(U).length},r=$v,n=Xr.Buffer,i=(typeof gr<"u"?gr:typeof window<"u"?window:typeof self<"u"?self:{}).Uint8Array||function(){};function o(S){return n.from(S)}function a(S){return n.isBuffer(S)||S instanceof i}var s=Ho,u;s&&s.debuglog?u=s.debuglog("stream"):u=function(){};var d=t2(),_=Hv,m=Vv,E=m.getHighWaterMark,B=Hn.codes,R=B.ERR_INVALID_ARG_TYPE,N=B.ERR_STREAM_PUSH_AFTER_EOF,P=B.ERR_METHOD_NOT_IMPLEMENTED,p=B.ERR_STREAM_UNSHIFT_AFTER_END_EVENT,v,x,C;yt(X,r);var O=_.errorOrDestroy,H=["error","close","destroy","pause","resume"];function Q(S,k,U){if(typeof S.prependListener=="function")return S.prependListener(k,U);!S._events||!S._events[k]?S.on(k,U):Array.isArray(S._events[k])?S._events[k].unshift(U):S._events[k]=[U,S._events[k]]}function V(S,k,U){e=e||ji(),S=S||{},typeof U!="boolean"&&(U=k instanceof e),this.objectMode=!!S.objectMode,U&&(this.objectMode=this.objectMode||!!S.readableObjectMode),this.highWaterMark=E(this,S,"readableHighWaterMark",U),this.buffer=new d,this.length=0,this.pipes=null,this.pipesCount=0,this.flowing=null,this.ended=!1,this.endEmitted=!1,this.reading=!1,this.sync=!0,this.needReadable=!1,this.emittedReadable=!1,this.readableListening=!1,this.resumeScheduled=!1,this.paused=!0,this.emitClose=S.emitClose!==!1,this.autoDestroy=!!S.autoDestroy,this.destroyed=!1,this.defaultEncoding=S.defaultEncoding||"utf8",this.awaitDrain=0,this.readingMore=!1,this.decoder=null,this.encoding=null,S.encoding&&(v||(v=yl.StringDecoder),this.decoder=new v(S.encoding),this.encoding=S.encoding)}function X(S){if(e=e||ji(),!(this instanceof X))return new X(S);var k=this instanceof e;this._readableState=new V(S,this,k),this.readable=!0,S&&(typeof S.read=="function"&&(this._read=S.read),typeof S.destroy=="function"&&(this._destroy=S.destroy)),r.call(this)}Object.defineProperty(X.prototype,"destroyed",{enumerable:!1,get:function(){return this._readableState===void 0?!1:this._readableState.destroyed},set:function(k){this._readableState&&(this._readableState.destroyed=k)}}),X.prototype.destroy=_.destroy,X.prototype._undestroy=_.undestroy,X.prototype._destroy=function(S,k){k(S)},X.prototype.push=function(S,k){var U=this._readableState,ie;return U.objectMode?ie=!0:typeof S=="string"&&(k=k||U.defaultEncoding,k!==U.encoding&&(S=n.from(S,k),k=""),ie=!0),pe(this,S,k,!1,ie)},X.prototype.unshift=function(S){return pe(this,S,null,!0,!1)};function pe(S,k,U,ie,Xe){u("readableAddChunk",k);var Ce=S._readableState;if(k===null)Ce.reading=!1,tt(S,Ce);else{var Ke;if(Xe||(Ke=$e(Ce,k)),Ke)O(S,Ke);else if(Ce.objectMode||k&&k.length>0)if(typeof k!="string"&&!Ce.objectMode&&Object.getPrototypeOf(k)!==n.prototype&&(k=o(k)),ie)Ce.endEmitted?O(S,new p):De(S,Ce,k,!0);else if(Ce.ended)O(S,new N);else{if(Ce.destroyed)return!1;Ce.reading=!1,Ce.decoder&&!U?(k=Ce.decoder.write(k),Ce.objectMode||k.length!==0?De(S,Ce,k,!1):D(S,Ce)):De(S,Ce,k,!1)}else ie||(Ce.reading=!1,D(S,Ce))}return!Ce.ended&&(Ce.length<Ce.highWaterMark||Ce.length===0)}function De(S,k,U,ie){k.flowing&&k.length===0&&!k.sync?(k.awaitDrain=0,S.emit("data",U)):(k.length+=k.objectMode?1:U.length,ie?k.buffer.unshift(U):k.buffer.push(U),k.needReadable&&I(S)),D(S,k)}function $e(S,k){var U;return!a(k)&&typeof k!="string"&&k!==void 0&&!S.objectMode&&(U=new R("chunk",["string","Buffer","Uint8Array"],k)),U}X.prototype.isPaused=function(){return this._readableState.flowing===!1},X.prototype.setEncoding=function(S){v||(v=yl.StringDecoder);var k=new v(S);this._readableState.decoder=k,this._readableState.encoding=this._readableState.decoder.encoding;for(var U=this._readableState.buffer.head,ie="";U!==null;)ie+=k.write(U.data),U=U.next;return this._readableState.buffer.clear(),ie!==""&&this._readableState.buffer.push(ie),this._readableState.length=ie.length,this};var _e=1073741824;function He(S){return S>=_e?S=_e:(S--,S|=S>>>1,S|=S>>>2,S|=S>>>4,S|=S>>>8,S|=S>>>16,S++),S}function nt(S,k){return S<=0||k.length===0&&k.ended?0:k.objectMode?1:S!==S?k.flowing&&k.length?k.buffer.head.data.length:k.length:(S>k.highWaterMark&&(k.highWaterMark=He(S)),S<=k.length?S:k.ended?k.length:(k.needReadable=!0,0))}X.prototype.read=function(S){u("read",S),S=parseInt(S,10);var k=this._readableState,U=S;if(S!==0&&(k.emittedReadable=!1),S===0&&k.needReadable&&((k.highWaterMark!==0?k.length>=k.highWaterMark:k.length>0)||k.ended))return u("read: emitReadable",k.length,k.ended),k.length===0&&k.ended?b(this):I(this),null;if(S=nt(S,k),S===0&&k.ended)return k.length===0&&b(this),null;var ie=k.needReadable;u("need readable",ie),(k.length===0||k.length-S<k.highWaterMark)&&(ie=!0,u("length less than watermark",ie)),k.ended||k.reading?(ie=!1,u("reading or ended",ie)):ie&&(u("do read"),k.reading=!0,k.sync=!0,k.length===0&&(k.needReadable=!0),this._read(k.highWaterMark),k.sync=!1,k.reading||(S=nt(U,k)));var Xe;return S>0?Xe=h(S,k):Xe=null,Xe===null?(k.needReadable=k.length<=k.highWaterMark,S=0):(k.length-=S,k.awaitDrain=0),k.length===0&&(k.ended||(k.needReadable=!0),U!==S&&k.ended&&b(this)),Xe!==null&&this.emit("data",Xe),Xe};function tt(S,k){if(u("onEofChunk"),!k.ended){if(k.decoder){var U=k.decoder.end();U&&U.length&&(k.buffer.push(U),k.length+=k.objectMode?1:U.length)}k.ended=!0,k.sync?I(S):(k.needReadable=!1,k.emittedReadable||(k.emittedReadable=!0,A(S)))}}function I(S){var k=S._readableState;u("emitReadable",k.needReadable,k.emittedReadable),k.needReadable=!1,k.emittedReadable||(u("emitReadable",k.flowing),k.emittedReadable=!0,process.nextTick(A,S))}function A(S){var k=S._readableState;u("emitReadable_",k.destroyed,k.length,k.ended),!k.destroyed&&(k.length||k.ended)&&(S.emit("readable"),k.emittedReadable=!1),k.needReadable=!k.flowing&&!k.ended&&k.length<=k.highWaterMark,T(S)}function D(S,k){k.readingMore||(k.readingMore=!0,process.nextTick(J,S,k))}function J(S,k){for(;!k.reading&&!k.ended&&(k.length<k.highWaterMark||k.flowing&&k.length===0);){var U=k.length;if(u("maybeReadMore read 0"),S.read(0),U===k.length)break}k.readingMore=!1}X.prototype._read=function(S){O(this,new P("_read()"))},X.prototype.pipe=function(S,k){var U=this,ie=this._readableState;switch(ie.pipesCount){case 0:ie.pipes=S;break;case 1:ie.pipes=[ie.pipes,S];break;default:ie.pipes.push(S);break}ie.pipesCount+=1,u("pipe count=%d opts=%j",ie.pipesCount,k);var Xe=(!k||k.end!==!1)&&S!==process.stdout&&S!==process.stderr,Ce=Xe?Wt:ze;ie.endEmitted?process.nextTick(Ce):U.once("end",Ce),S.on("unpipe",Ke);function Ke(Ze,gt){u("onunpipe"),Ze===U&&gt&&gt.hasUnpiped===!1&&(gt.hasUnpiped=!0,Rr())}function Wt(){u("onend"),S.end()}var Nt=le(U);S.on("drain",Nt);var rr=!1;function Rr(){u("cleanup"),S.removeListener("close",W),S.removeListener("finish",ne),S.removeListener("drain",Nt),S.removeListener("error",Vt),S.removeListener("unpipe",Ke),U.removeListener("end",Wt),U.removeListener("end",ze),U.removeListener("data",cr),rr=!0,ie.awaitDrain&&(!S._writableState||S._writableState.needDrain)&&Nt()}U.on("data",cr);function cr(Ze){u("ondata");var gt=S.write(Ze);u("dest.write",gt),gt===!1&&((ie.pipesCount===1&&ie.pipes===S||ie.pipesCount>1&&K(ie.pipes,S)!==-1)&&!rr&&(u("false write response, pause",ie.awaitDrain),ie.awaitDrain++),U.pause())}function Vt(Ze){u("onerror",Ze),ze(),S.removeListener("error",Vt),t(S,"error")===0&&O(S,Ze)}Q(S,"error",Vt);function W(){S.removeListener("finish",ne),ze()}S.once("close",W);function ne(){u("onfinish"),S.removeListener("close",W),ze()}S.once("finish",ne);function ze(){u("unpipe"),U.unpipe(S)}return S.emit("pipe",U),ie.flowing||(u("pipe resume"),U.resume()),S};function le(S){return function(){var U=S._readableState;u("pipeOnDrain",U.awaitDrain),U.awaitDrain&&U.awaitDrain--,U.awaitDrain===0&&t(S,"data")&&(U.flowing=!0,T(S))}}X.prototype.unpipe=function(S){var k=this._readableState,U={hasUnpiped:!1};if(k.pipesCount===0)return this;if(k.pipesCount===1)return S&&S!==k.pipes?this:(S||(S=k.pipes),k.pipes=null,k.pipesCount=0,k.flowing=!1,S&&S.emit("unpipe",this,U),this);if(!S){var ie=k.pipes,Xe=k.pipesCount;k.pipes=null,k.pipesCount=0,k.flowing=!1;for(var Ce=0;Ce<Xe;Ce++)ie[Ce].emit("unpipe",this,{hasUnpiped:!1});return this}var Ke=K(k.pipes,S);return Ke===-1?this:(k.pipes.splice(Ke,1),k.pipesCount-=1,k.pipesCount===1&&(k.pipes=k.pipes[0]),S.emit("unpipe",this,U),this)},X.prototype.on=function(S,k){var U=r.prototype.on.call(this,S,k),ie=this._readableState;return S==="data"?(ie.readableListening=this.listenerCount("readable")>0,ie.flowing!==!1&&this.resume()):S==="readable"&&!ie.endEmitted&&!ie.readableListening&&(ie.readableListening=ie.needReadable=!0,ie.flowing=!1,ie.emittedReadable=!1,u("on readable",ie.length,ie.reading),ie.length?I(this):ie.reading||process.nextTick(Ne,this)),U},X.prototype.addListener=X.prototype.on,X.prototype.removeListener=function(S,k){var U=r.prototype.removeListener.call(this,S,k);return S==="readable"&&process.nextTick(de,this),U},X.prototype.removeAllListeners=function(S){var k=r.prototype.removeAllListeners.apply(this,arguments);return(S==="readable"||S===void 0)&&process.nextTick(de,this),k};function de(S){var k=S._readableState;k.readableListening=S.listenerCount("readable")>0,k.resumeScheduled&&!k.paused?k.flowing=!0:S.listenerCount("data")>0&&S.resume()}function Ne(S){u("readable nexttick read 0"),S.read(0)}X.prototype.resume=function(){var S=this._readableState;return S.flowing||(u("resume"),S.flowing=!S.readableListening,Re(this,S)),S.paused=!1,this};function Re(S,k){k.resumeScheduled||(k.resumeScheduled=!0,process.nextTick(ge,S,k))}function ge(S,k){u("resume",k.reading),k.reading||S.read(0),k.resumeScheduled=!1,S.emit("resume"),T(S),k.flowing&&!k.reading&&S.read(0)}X.prototype.pause=function(){return u("call pause flowing=%j",this._readableState.flowing),this._readableState.flowing!==!1&&(u("pause"),this._readableState.flowing=!1,this.emit("pause")),this._readableState.paused=!0,this};function T(S){var k=S._readableState;for(u("flow",k.flowing);k.flowing&&S.read()!==null;);}X.prototype.wrap=function(S){var k=this,U=this._readableState,ie=!1;S.on("end",function(){if(u("wrapped end"),U.decoder&&!U.ended){var Ke=U.decoder.end();Ke&&Ke.length&&k.push(Ke)}k.push(null)}),S.on("data",function(Ke){if(u("wrapped data"),U.decoder&&(Ke=U.decoder.write(Ke)),!(U.objectMode&&Ke==null)&&!(!U.objectMode&&(!Ke||!Ke.length))){var Wt=k.push(Ke);Wt||(ie=!0,S.pause())}});for(var Xe in S)this[Xe]===void 0&&typeof S[Xe]=="function"&&(this[Xe]=function(Wt){return function(){return S[Wt].apply(S,arguments)}}(Xe));for(var Ce=0;Ce<H.length;Ce++)S.on(H[Ce],this.emit.bind(this,H[Ce]));return this._read=function(Ke){u("wrapped _read",Ke),ie&&(ie=!1,S.resume())},this},typeof Symbol=="function"&&(X.prototype[Symbol.asyncIterator]=function(){return x===void 0&&(x=N2()),x(this)}),Object.defineProperty(X.prototype,"readableHighWaterMark",{enumerable:!1,get:function(){return this._readableState.highWaterMark}}),Object.defineProperty(X.prototype,"readableBuffer",{enumerable:!1,get:function(){return this._readableState&&this._readableState.buffer}}),Object.defineProperty(X.prototype,"readableFlowing",{enumerable:!1,get:function(){return this._readableState.flowing},set:function(k){this._readableState&&(this._readableState.flowing=k)}}),X._fromList=h,Object.defineProperty(X.prototype,"readableLength",{enumerable:!1,get:function(){return this._readableState.length}});function h(S,k){if(k.length===0)return null;var U;return k.objectMode?U=k.buffer.shift():!S||S>=k.length?(k.decoder?U=k.buffer.join(""):k.buffer.length===1?U=k.buffer.first():U=k.buffer.concat(k.length),k.buffer.clear()):U=k.buffer.consume(S,k.decoder),U}function b(S){var k=S._readableState;u("endReadable",k.endEmitted),k.endEmitted||(k.ended=!0,process.nextTick(F,k,S))}function F(S,k){if(u("endReadableNT",S.endEmitted,S.length),!S.endEmitted&&S.length===0&&(S.endEmitted=!0,k.readable=!1,k.emit("end"),S.autoDestroy)){var U=k._writableState;(!U||U.autoDestroy&&U.finished)&&k.destroy()}}typeof Symbol=="function"&&(X.from=function(S,k){return C===void 0&&(C=R2()),C(X,S,k)});function K(S,k){for(var U=0,ie=S.length;U<ie;U++)if(S[U]===k)return U;return-1}return Is}var Qv=Yr,Ul=Hn.codes,T2=Ul.ERR_METHOD_NOT_IMPLEMENTED,L2=Ul.ERR_MULTIPLE_CALLBACK,B2=Ul.ERR_TRANSFORM_ALREADY_TRANSFORMING,P2=Ul.ERR_TRANSFORM_WITH_LENGTH_0,Fl=ji();yt(Yr,Fl);function M2(e,t){var r=this._transformState;r.transforming=!1;var n=r.writecb;if(n===null)return this.emit("error",new L2);r.writechunk=null,r.writecb=null,t!=null&&this.push(t),n(e);var i=this._readableState;i.reading=!1,(i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}function Yr(e){if(!(this instanceof Yr))return new Yr(e);Fl.call(this,e),this._transformState={afterTransform:M2.bind(this),needTransform:!1,transforming:!1,writecb:null,writechunk:null,writeencoding:null},this._readableState.needReadable=!0,this._readableState.sync=!1,e&&(typeof e.transform=="function"&&(this._transform=e.transform),typeof e.flush=="function"&&(this._flush=e.flush)),this.on("prefinish",O2)}function O2(){var e=this;typeof this._flush=="function"&&!this._readableState.destroyed?this._flush(function(t,r){ah(e,t,r)}):ah(this,null,null)}Yr.prototype.push=function(e,t){return this._transformState.needTransform=!1,Fl.prototype.push.call(this,e,t)};Yr.prototype._transform=function(e,t,r){r(new T2("_transform()"))};Yr.prototype._write=function(e,t,r){var n=this._transformState;if(n.writecb=r,n.writechunk=e,n.writeencoding=t,!n.transforming){var i=this._readableState;(n.needTransform||i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}};Yr.prototype._read=function(e){var t=this._transformState;t.writechunk!==null&&!t.transforming?(t.transforming=!0,this._transform(t.writechunk,t.writeencoding,t.afterTransform)):t.needTransform=!0};Yr.prototype._destroy=function(e,t){Fl.prototype._destroy.call(this,e,function(r){t(r)})};function ah(e,t,r){if(t)return e.emit("error",t);if(r!=null&&e.push(r),e._writableState.length)throw new P2;if(e._transformState.transforming)throw new B2;return e.push(null)}var I2=Po,Xv=Qv;yt(Po,Xv);function Po(e){if(!(this instanceof Po))return new Po(e);Xv.call(this,e)}Po.prototype._transform=function(e,t,r){r(null,e)};var Ds;function D2(e){var t=!1;return function(){t||(t=!0,e.apply(void 0,arguments))}}var Zv=Hn.codes,U2=Zv.ERR_MISSING_ARGS,F2=Zv.ERR_STREAM_DESTROYED;function lh(e){if(e)throw e}function z2(e){return e.setHeader&&typeof e.abort=="function"}function $2(e,t,r,n){n=D2(n);var i=!1;e.on("close",function(){i=!0}),Ds===void 0&&(Ds=Sc),Ds(e,{readable:t,writable:r},function(a){if(a)return n(a);i=!0,n()});var o=!1;return function(a){if(!i&&!o){if(o=!0,z2(e))return e.abort();if(typeof e.destroy=="function")return e.destroy();n(a||new F2("pipe"))}}}function sh(e){e()}function H2(e,t){return e.pipe(t)}function W2(e){return!e.length||typeof e[e.length-1]!="function"?lh:e.pop()}function V2(){for(var e=arguments.length,t=new Array(e),r=0;r<e;r++)t[r]=arguments[r];var n=W2(t);if(Array.isArray(t[0])&&(t=t[0]),t.length<2)throw new U2("streams");var i,o=t.map(function(a,s){var u=s<t.length-1,d=s>0;return $2(a,u,d,function(_){i||(i=_),_&&o.forEach(sh),!u&&(o.forEach(sh),n(i))})});return t.reduce(H2)}var K2=V2;(function(e,t){t=e.exports=Yv(),t.Stream=t,t.Readable=t,t.Writable=qv(),t.Duplex=ji(),t.Transform=Qv,t.PassThrough=I2,t.finished=Sc,t.pipeline=K2})(gf,gf.exports);var q2=gf.exports,G2={}.toString,Y2=Array.isArray||function(e){return G2.call(e)=="[object Array]"},Vo=TypeError,Jv=Object,Q2=Error,X2=EvalError,Z2=RangeError,J2=ReferenceError,e1=SyntaxError,eb=URIError,tb=Math.abs,rb=Math.floor,nb=Math.max,ib=Math.min,ob=Math.pow,ab=Math.round,lb=Number.isNaN||function(t){return t!==t},sb=lb,ub=function(t){return sb(t)||t===0?t:t<0?-1:1},fb=Object.getOwnPropertyDescriptor,za=fb;if(za)try{za([],"length")}catch{za=null}var Ko=za,$a=Object.defineProperty||!1;if($a)try{$a({},"a",{value:1})}catch{$a=!1}var zl=$a,Us,uh;function t1(){return uh||(uh=1,Us=function(){if(typeof Symbol!="function"||typeof Object.getOwnPropertySymbols!="function")return!1;if(typeof Symbol.iterator=="symbol")return!0;var t={},r=Symbol("test"),n=Object(r);if(typeof r=="string"||Object.prototype.toString.call(r)!=="[object Symbol]"||Object.prototype.toString.call(n)!=="[object Symbol]")return!1;var i=42;t[r]=i;for(var o in t)return!1;if(typeof Object.keys=="function"&&Object.keys(t).length!==0||typeof Object.getOwnPropertyNames=="function"&&Object.getOwnPropertyNames(t).length!==0)return!1;var a=Object.getOwnPropertySymbols(t);if(a.length!==1||a[0]!==r||!Object.prototype.propertyIsEnumerable.call(t,r))return!1;if(typeof Object.getOwnPropertyDescriptor=="function"){var s=Object.getOwnPropertyDescriptor(t,r);if(s.value!==i||s.enumerable!==!0)return!1}return!0}),Us}var Fs,fh;function cb(){if(fh)return Fs;fh=1;var e=typeof Symbol<"u"&&Symbol,t=t1();return Fs=function(){return typeof e!="function"||typeof Symbol!="function"||typeof e("foo")!="symbol"||typeof Symbol("bar")!="symbol"?!1:t()},Fs}var zs,ch;function r1(){return ch||(ch=1,zs=typeof Reflect<"u"&&Reflect.getPrototypeOf||null),zs}var $s,dh;function n1(){if(dh)return $s;dh=1;var e=Jv;return $s=e.getPrototypeOf||null,$s}var db="Function.prototype.bind called on incompatible ",hb=Object.prototype.toString,pb=Math.max,vb="[object Function]",hh=function(t,r){for(var n=[],i=0;i<t.length;i+=1)n[i]=t[i];for(var o=0;o<r.length;o+=1)n[o+t.length]=r[o];return n},yb=function(t,r){for(var n=[],i=r,o=0;i<t.length;i+=1,o+=1)n[o]=t[i];return n},gb=function(e,t){for(var r="",n=0;n<e.length;n+=1)r+=e[n],n+1<e.length&&(r+=t);return r},mb=function(t){var r=this;if(typeof r!="function"||hb.apply(r)!==vb)throw new TypeError(db+r);for(var n=yb(arguments,1),i,o=function(){if(this instanceof i){var _=r.apply(this,hh(n,arguments));return Object(_)===_?_:this}return r.apply(t,hh(n,arguments))},a=pb(0,r.length-n.length),s=[],u=0;u<a;u++)s[u]="$"+u;if(i=Function("binder","return function ("+gb(s,",")+"){ return binder.apply(this,arguments); }")(o),r.prototype){var d=function(){};d.prototype=r.prototype,i.prototype=new d,d.prototype=null}return i},xb=mb,qo=Function.prototype.bind||xb,Ec=Function.prototype.call,jc=Function.prototype.apply,bb=typeof Reflect<"u"&&Reflect&&Reflect.apply,wb=qo,_b=jc,kb=Ec,Sb=bb,i1=Sb||wb.call(kb,_b),Eb=qo,jb=Vo,Cb=Ec,Ab=i1,Cc=function(t){if(t.length<1||typeof t[0]!="function")throw new jb("a function is required");return Ab(Eb,Cb,t)},Hs,ph;function Nb(){if(ph)return Hs;ph=1;var e=Cc,t=Ko,r;try{r=[].__proto__===Array.prototype}catch(a){if(!a||typeof a!="object"||!("code"in a)||a.code!=="ERR_PROTO_ACCESS")throw a}var n=!!r&&t&&t(Object.prototype,"__proto__"),i=Object,o=i.getPrototypeOf;return Hs=n&&typeof n.get=="function"?e([n.get]):typeof o=="function"?function(s){return o(s==null?s:i(s))}:!1,Hs}var Ws,vh;function o1(){if(vh)return Ws;vh=1;var e=r1(),t=n1(),r=Nb();return Ws=e?function(i){return e(i)}:t?function(i){if(!i||typeof i!="object"&&typeof i!="function")throw new TypeError("getProto: not an object");return t(i)}:r?function(i){return r(i)}:null,Ws}var Vs,yh;function Rb(){if(yh)return Vs;yh=1;var e=Function.prototype.call,t=Object.prototype.hasOwnProperty,r=qo;return Vs=r.call(e,t),Vs}var Ue,Tb=Jv,Lb=Q2,Bb=X2,Pb=Z2,Mb=J2,Ci=e1,mi=Vo,Ob=eb,Ib=tb,Db=rb,Ub=nb,Fb=ib,zb=ob,$b=ab,Hb=ub,a1=Function,Ks=function(e){try{return a1('"use strict"; return ('+e+").constructor;")()}catch{}},Mo=Ko,Wb=zl,qs=function(){throw new mi},Vb=Mo?function(){try{return arguments.callee,qs}catch{try{return Mo(arguments,"callee").get}catch{return qs}}}():qs,Yn=cb()(),jt=o1(),Kb=n1(),qb=r1(),l1=jc,Go=Ec,Xn={},Gb=typeof Uint8Array>"u"||!jt?Ue:jt(Uint8Array),Pn={__proto__:null,"%AggregateError%":typeof AggregateError>"u"?Ue:AggregateError,"%Array%":Array,"%ArrayBuffer%":typeof ArrayBuffer>"u"?Ue:ArrayBuffer,"%ArrayIteratorPrototype%":Yn&&jt?jt([][Symbol.iterator]()):Ue,"%AsyncFromSyncIteratorPrototype%":Ue,"%AsyncFunction%":Xn,"%AsyncGenerator%":Xn,"%AsyncGeneratorFunction%":Xn,"%AsyncIteratorPrototype%":Xn,"%Atomics%":typeof Atomics>"u"?Ue:Atomics,"%BigInt%":typeof BigInt>"u"?Ue:BigInt,"%BigInt64Array%":typeof BigInt64Array>"u"?Ue:BigInt64Array,"%BigUint64Array%":typeof BigUint64Array>"u"?Ue:BigUint64Array,"%Boolean%":Boolean,"%DataView%":typeof DataView>"u"?Ue:DataView,"%Date%":Date,"%decodeURI%":decodeURI,"%decodeURIComponent%":decodeURIComponent,"%encodeURI%":encodeURI,"%encodeURIComponent%":encodeURIComponent,"%Error%":Lb,"%eval%":eval,"%EvalError%":Bb,"%Float16Array%":typeof Float16Array>"u"?Ue:Float16Array,"%Float32Array%":typeof Float32Array>"u"?Ue:Float32Array,"%Float64Array%":typeof Float64Array>"u"?Ue:Float64Array,"%FinalizationRegistry%":typeof FinalizationRegistry>"u"?Ue:FinalizationRegistry,"%Function%":a1,"%GeneratorFunction%":Xn,"%Int8Array%":typeof Int8Array>"u"?Ue:Int8Array,"%Int16Array%":typeof Int16Array>"u"?Ue:Int16Array,"%Int32Array%":typeof Int32Array>"u"?Ue:Int32Array,"%isFinite%":isFinite,"%isNaN%":isNaN,"%IteratorPrototype%":Yn&&jt?jt(jt([][Symbol.iterator]())):Ue,"%JSON%":typeof JSON=="object"?JSON:Ue,"%Map%":typeof Map>"u"?Ue:Map,"%MapIteratorPrototype%":typeof Map>"u"||!Yn||!jt?Ue:jt(new Map()[Symbol.iterator]()),"%Math%":Math,"%Number%":Number,"%Object%":Tb,"%Object.getOwnPropertyDescriptor%":Mo,"%parseFloat%":parseFloat,"%parseInt%":parseInt,"%Promise%":typeof Promise>"u"?Ue:Promise,"%Proxy%":typeof Proxy>"u"?Ue:Proxy,"%RangeError%":Pb,"%ReferenceError%":Mb,"%Reflect%":typeof Reflect>"u"?Ue:Reflect,"%RegExp%":RegExp,"%Set%":typeof Set>"u"?Ue:Set,"%SetIteratorPrototype%":typeof Set>"u"||!Yn||!jt?Ue:jt(new Set()[Symbol.iterator]()),"%SharedArrayBuffer%":typeof SharedArrayBuffer>"u"?Ue:SharedArrayBuffer,"%String%":String,"%StringIteratorPrototype%":Yn&&jt?jt(""[Symbol.iterator]()):Ue,"%Symbol%":Yn?Symbol:Ue,"%SyntaxError%":Ci,"%ThrowTypeError%":Vb,"%TypedArray%":Gb,"%TypeError%":mi,"%Uint8Array%":typeof Uint8Array>"u"?Ue:Uint8Array,"%Uint8ClampedArray%":typeof Uint8ClampedArray>"u"?Ue:Uint8ClampedArray,"%Uint16Array%":typeof Uint16Array>"u"?Ue:Uint16Array,"%Uint32Array%":typeof Uint32Array>"u"?Ue:Uint32Array,"%URIError%":Ob,"%WeakMap%":typeof WeakMap>"u"?Ue:WeakMap,"%WeakRef%":typeof WeakRef>"u"?Ue:WeakRef,"%WeakSet%":typeof WeakSet>"u"?Ue:WeakSet,"%Function.prototype.call%":Go,"%Function.prototype.apply%":l1,"%Object.defineProperty%":Wb,"%Object.getPrototypeOf%":Kb,"%Math.abs%":Ib,"%Math.floor%":Db,"%Math.max%":Ub,"%Math.min%":Fb,"%Math.pow%":zb,"%Math.round%":$b,"%Math.sign%":Hb,"%Reflect.getPrototypeOf%":qb};if(jt)try{null.error}catch(e){var Yb=jt(jt(e));Pn["%Error.prototype%"]=Yb}var Qb=function e(t){var r;if(t==="%AsyncFunction%")r=Ks("async function () {}");else if(t==="%GeneratorFunction%")r=Ks("function* () {}");else if(t==="%AsyncGeneratorFunction%")r=Ks("async function* () {}");else if(t==="%AsyncGenerator%"){var n=e("%AsyncGeneratorFunction%");n&&(r=n.prototype)}else if(t==="%AsyncIteratorPrototype%"){var i=e("%AsyncGenerator%");i&&jt&&(r=jt(i.prototype))}return Pn[t]=r,r},gh={__proto__:null,"%ArrayBufferPrototype%":["ArrayBuffer","prototype"],"%ArrayPrototype%":["Array","prototype"],"%ArrayProto_entries%":["Array","prototype","entries"],"%ArrayProto_forEach%":["Array","prototype","forEach"],"%ArrayProto_keys%":["Array","prototype","keys"],"%ArrayProto_values%":["Array","prototype","values"],"%AsyncFunctionPrototype%":["AsyncFunction","prototype"],"%AsyncGenerator%":["AsyncGeneratorFunction","prototype"],"%AsyncGeneratorPrototype%":["AsyncGeneratorFunction","prototype","prototype"],"%BooleanPrototype%":["Boolean","prototype"],"%DataViewPrototype%":["DataView","prototype"],"%DatePrototype%":["Date","prototype"],"%ErrorPrototype%":["Error","prototype"],"%EvalErrorPrototype%":["EvalError","prototype"],"%Float32ArrayPrototype%":["Float32Array","prototype"],"%Float64ArrayPrototype%":["Float64Array","prototype"],"%FunctionPrototype%":["Function","prototype"],"%Generator%":["GeneratorFunction","prototype"],"%GeneratorPrototype%":["GeneratorFunction","prototype","prototype"],"%Int8ArrayPrototype%":["Int8Array","prototype"],"%Int16ArrayPrototype%":["Int16Array","prototype"],"%Int32ArrayPrototype%":["Int32Array","prototype"],"%JSONParse%":["JSON","parse"],"%JSONStringify%":["JSON","stringify"],"%MapPrototype%":["Map","prototype"],"%NumberPrototype%":["Number","prototype"],"%ObjectPrototype%":["Object","prototype"],"%ObjProto_toString%":["Object","prototype","toString"],"%ObjProto_valueOf%":["Object","prototype","valueOf"],"%PromisePrototype%":["Promise","prototype"],"%PromiseProto_then%":["Promise","prototype","then"],"%Promise_all%":["Promise","all"],"%Promise_reject%":["Promise","reject"],"%Promise_resolve%":["Promise","resolve"],"%RangeErrorPrototype%":["RangeError","prototype"],"%ReferenceErrorPrototype%":["ReferenceError","prototype"],"%RegExpPrototype%":["RegExp","prototype"],"%SetPrototype%":["Set","prototype"],"%SharedArrayBufferPrototype%":["SharedArrayBuffer","prototype"],"%StringPrototype%":["String","prototype"],"%SymbolPrototype%":["Symbol","prototype"],"%SyntaxErrorPrototype%":["SyntaxError","prototype"],"%TypedArrayPrototype%":["TypedArray","prototype"],"%TypeErrorPrototype%":["TypeError","prototype"],"%Uint8ArrayPrototype%":["Uint8Array","prototype"],"%Uint8ClampedArrayPrototype%":["Uint8ClampedArray","prototype"],"%Uint16ArrayPrototype%":["Uint16Array","prototype"],"%Uint32ArrayPrototype%":["Uint32Array","prototype"],"%URIErrorPrototype%":["URIError","prototype"],"%WeakMapPrototype%":["WeakMap","prototype"],"%WeakSetPrototype%":["WeakSet","prototype"]},Yo=qo,gl=Rb(),Xb=Yo.call(Go,Array.prototype.concat),Zb=Yo.call(l1,Array.prototype.splice),mh=Yo.call(Go,String.prototype.replace),ml=Yo.call(Go,String.prototype.slice),Jb=Yo.call(Go,RegExp.prototype.exec),ew=/[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,tw=/\\(\\)?/g,rw=function(t){var r=ml(t,0,1),n=ml(t,-1);if(r==="%"&&n!=="%")throw new Ci("invalid intrinsic syntax, expected closing `%`");if(n==="%"&&r!=="%")throw new Ci("invalid intrinsic syntax, expected opening `%`");var i=[];return mh(t,ew,function(o,a,s,u){i[i.length]=s?mh(u,tw,"$1"):a||o}),i},nw=function(t,r){var n=t,i;if(gl(gh,n)&&(i=gh[n],n="%"+i[0]+"%"),gl(Pn,n)){var o=Pn[n];if(o===Xn&&(o=Qb(n)),typeof o>"u"&&!r)throw new mi("intrinsic "+t+" exists, but is not available. Please file an issue!");return{alias:i,name:n,value:o}}throw new Ci("intrinsic "+t+" does not exist!")},s1=function(t,r){if(typeof t!="string"||t.length===0)throw new mi("intrinsic name must be a non-empty string");if(arguments.length>1&&typeof r!="boolean")throw new mi('"allowMissing" argument must be a boolean');if(Jb(/^%?[^%]*%?$/,t)===null)throw new Ci("`%` may not be present anywhere but at the beginning and end of the intrinsic name");var n=rw(t),i=n.length>0?n[0]:"",o=nw("%"+i+"%",r),a=o.name,s=o.value,u=!1,d=o.alias;d&&(i=d[0],Zb(n,Xb([0,1],d)));for(var _=1,m=!0;_<n.length;_+=1){var E=n[_],B=ml(E,0,1),R=ml(E,-1);if((B==='"'||B==="'"||B==="`"||R==='"'||R==="'"||R==="`")&&B!==R)throw new Ci("property names with quotes must have matching quotes");if((E==="constructor"||!m)&&(u=!0),i+="."+E,a="%"+i+"%",gl(Pn,a))s=Pn[a];else if(s!=null){if(!(E in s)){if(!r)throw new mi("base intrinsic for "+t+" exists, but the property is not available.");return}if(Mo&&_+1>=n.length){var N=Mo(s,E);m=!!N,m&&"get"in N&&!("originalValue"in N.get)?s=N.get:s=s[E]}else m=gl(s,E),s=s[E];m&&!u&&(Pn[a]=s)}}return s},u1=s1,f1=Cc,iw=f1([u1("%String.prototype.indexOf%")]),c1=function(t,r){var n=u1(t,!!r);return typeof n=="function"&&iw(t,".prototype.")>-1?f1([n]):n},Gs,xh;function ow(){if(xh)return Gs;xh=1;var e=Function.prototype.toString,t=typeof Reflect=="object"&&Reflect!==null&&Reflect.apply,r,n;if(typeof t=="function"&&typeof Object.defineProperty=="function")try{r=Object.defineProperty({},"length",{get:function(){throw n}}),n={},t(function(){throw 42},null,r)}catch(v){v!==n&&(t=null)}else t=null;var i=/^\s*class\b/,o=function(x){try{var C=e.call(x);return i.test(C)}catch{return!1}},a=function(x){try{return o(x)?!1:(e.call(x),!0)}catch{return!1}},s=Object.prototype.toString,u="[object Object]",d="[object Function]",_="[object GeneratorFunction]",m="[object HTMLAllCollection]",E="[object HTML document.all class]",B="[object HTMLCollection]",R=typeof Symbol=="function"&&!!Symbol.toStringTag,N=!(0 in[,]),P=function(){return!1};if(typeof document=="object"){var p=document.all;s.call(p)===s.call(document.all)&&(P=function(x){if((N||!x)&&(typeof x>"u"||typeof x=="object"))try{var C=s.call(x);return(C===m||C===E||C===B||C===u)&&x("")==null}catch{}return!1})}return Gs=t?function(x){if(P(x))return!0;if(!x||typeof x!="function"&&typeof x!="object")return!1;try{t(x,null,r)}catch(C){if(C!==n)return!1}return!o(x)&&a(x)}:function(x){if(P(x))return!0;if(!x||typeof x!="function"&&typeof x!="object")return!1;if(R)return a(x);if(o(x))return!1;var C=s.call(x);return C!==d&&C!==_&&!/^\[object HTML/.test(C)?!1:a(x)},Gs}var Ys,bh;function aw(){if(bh)return Ys;bh=1;var e=ow(),t=Object.prototype.toString,r=Object.prototype.hasOwnProperty,n=function(u,d,_){for(var m=0,E=u.length;m<E;m++)r.call(u,m)&&(_==null?d(u[m],m,u):d.call(_,u[m],m,u))},i=function(u,d,_){for(var m=0,E=u.length;m<E;m++)_==null?d(u.charAt(m),m,u):d.call(_,u.charAt(m),m,u)},o=function(u,d,_){for(var m in u)r.call(u,m)&&(_==null?d(u[m],m,u):d.call(_,u[m],m,u))};function a(s){return t.call(s)==="[object Array]"}return Ys=function(u,d,_){if(!e(d))throw new TypeError("iterator must be a function");var m;arguments.length>=3&&(m=_),a(u)?n(u,d,m):typeof u=="string"?i(u,d,m):o(u,d,m)},Ys}var Qs,wh;function lw(){return wh||(wh=1,Qs=["Float16Array","Float32Array","Float64Array","Int8Array","Int16Array","Int32Array","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","BigInt64Array","BigUint64Array"]),Qs}var Xs,_h;function sw(){if(_h)return Xs;_h=1;var e=lw(),t=typeof globalThis>"u"?gr:globalThis;return Xs=function(){for(var n=[],i=0;i<e.length;i++)typeof t[e[i]]=="function"&&(n[n.length]=e[i]);return n},Xs}var Zs={exports:{}},Js,kh;function uw(){if(kh)return Js;kh=1;var e=zl,t=e1,r=Vo,n=Ko;return Js=function(o,a,s){if(!o||typeof o!="object"&&typeof o!="function")throw new r("`obj` must be an object or a function`");if(typeof a!="string"&&typeof a!="symbol")throw new r("`property` must be a string or a symbol`");if(arguments.length>3&&typeof arguments[3]!="boolean"&&arguments[3]!==null)throw new r("`nonEnumerable`, if provided, must be a boolean or null");if(arguments.length>4&&typeof arguments[4]!="boolean"&&arguments[4]!==null)throw new r("`nonWritable`, if provided, must be a boolean or null");if(arguments.length>5&&typeof arguments[5]!="boolean"&&arguments[5]!==null)throw new r("`nonConfigurable`, if provided, must be a boolean or null");if(arguments.length>6&&typeof arguments[6]!="boolean")throw new r("`loose`, if provided, must be a boolean");var u=arguments.length>3?arguments[3]:null,d=arguments.length>4?arguments[4]:null,_=arguments.length>5?arguments[5]:null,m=arguments.length>6?arguments[6]:!1,E=!!n&&n(o,a);if(e)e(o,a,{configurable:_===null&&E?E.configurable:!_,enumerable:u===null&&E?E.enumerable:!u,value:s,writable:d===null&&E?E.writable:!d});else if(m||!u&&!d&&!_)o[a]=s;else throw new t("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.")},Js}var eu,Sh;function fw(){if(Sh)return eu;Sh=1;var e=zl,t=function(){return!!e};return t.hasArrayLengthDefineBug=function(){if(!e)return null;try{return e([],"length",{value:1}).length!==1}catch{return!0}},eu=t,eu}var tu,Eh;function cw(){if(Eh)return tu;Eh=1;var e=s1,t=uw(),r=fw()(),n=Ko,i=Vo,o=e("%Math.floor%");return tu=function(s,u){if(typeof s!="function")throw new i("`fn` is not a function");if(typeof u!="number"||u<0||u>4294967295||o(u)!==u)throw new i("`length` must be a positive 32-bit integer");var d=arguments.length>2&&!!arguments[2],_=!0,m=!0;if("length"in s&&n){var E=n(s,"length");E&&!E.configurable&&(_=!1),E&&!E.writable&&(m=!1)}return(_||m||!d)&&(r?t(s,"length",u,!0,!0):t(s,"length",u)),s},tu}var ru,jh;function dw(){if(jh)return ru;jh=1;var e=qo,t=jc,r=i1;return ru=function(){return r(e,t,arguments)},ru}var Ch;function hw(){return Ch||(Ch=1,function(e){var t=cw(),r=zl,n=Cc,i=dw();e.exports=function(a){var s=n(arguments),u=1+a.length-(arguments.length-1);return t(s,u>0?u:0,!0)},r?r(e.exports,"apply",{value:i}):e.exports.apply=i}(Zs)),Zs.exports}var nu,Ah;function pw(){if(Ah)return nu;Ah=1;var e=t1();return nu=function(){return e()&&!!Symbol.toStringTag},nu}var iu,Nh;function vw(){if(Nh)return iu;Nh=1;var e=aw(),t=sw(),r=hw(),n=c1,i=Ko,o=o1(),a=n("Object.prototype.toString"),s=pw()(),u=typeof globalThis>"u"?gr:globalThis,d=t(),_=n("String.prototype.slice"),m=n("Array.prototype.indexOf",!0)||function(p,v){for(var x=0;x<p.length;x+=1)if(p[x]===v)return x;return-1},E={__proto__:null};s&&i&&o?e(d,function(P){var p=new u[P];if(Symbol.toStringTag in p&&o){var v=o(p),x=i(v,Symbol.toStringTag);if(!x&&v){var C=o(v);x=i(C,Symbol.toStringTag)}if(x&&x.get){var O=r(x.get);E["$"+P]=O}}}):e(d,function(P){var p=new u[P],v=p.slice||p.set;if(v){var x=r(v);E["$"+P]=x}});function B(P){var p=!1;return e(E,function(v,x){if(!p)try{"$"+v(P)===x&&(p=_(x,1))}catch{}}),p}function R(P){var p=!1;return e(E,function(v,x){if(!p)try{v(P),p=_(x,1)}catch{}}),p}function N(P){return m(d,P)>-1}return iu=function(p){if(!p||typeof p!="object")return!1;if(!s){var v=_(a(p),8,-1);return N(v)?v:v!=="Object"?!1:R(p)}return i?B(p):null},iu}var ou,Rh;function yw(){if(Rh)return ou;Rh=1;var e=vw();return ou=function(r){return!!e(r)},ou}var gw=Vo,mw=c1,xw=mw("TypedArray.prototype.buffer",!0),bw=yw(),ww=xw||function(t){if(!bw(t))throw new gw("Not a Typed Array");return t.buffer},_r=Qt.Buffer,_w=Y2,kw=ww,Sw=ArrayBuffer.isView||function(t){try{return kw(t),!0}catch{return!1}},Ew=typeof Uint8Array<"u",d1=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",jw=d1&&(_r.prototype instanceof Uint8Array||_r.TYPED_ARRAY_SUPPORT),Ac=function(t,r){if(_r.isBuffer(t))return t.constructor&&!("isBuffer"in t)?_r.from(t):t;if(typeof t=="string")return _r.from(t,r);if(d1&&Sw(t)){if(t.byteLength===0)return _r.alloc(0);if(jw){var n=_r.from(t.buffer,t.byteOffset,t.byteLength);if(n.byteLength===t.byteLength)return n}var i=t instanceof Uint8Array?t:new Uint8Array(t.buffer,t.byteOffset,t.byteLength),o=_r.from(i);if(o.length===t.byteLength)return o}if(Ew&&t instanceof Uint8Array)return _r.from(t);var a=_w(t);if(a)for(var s=0;s<t.length;s+=1){var u=t[s];if(typeof u!="number"||u<0||u>255||~~u!==u)throw new RangeError("Array items must be numbers in the range 0-255.")}if(a||_r.isBuffer(t)&&t.constructor&&typeof t.constructor.isBuffer=="function"&&t.constructor.isBuffer(t))return _r.from(t);throw new TypeError('The "data" argument must be a string, an Array, a Buffer, a Uint8Array, or a DataView.')},Cw=Qt.Buffer,h1=q2.Transform,Aw=yl.StringDecoder,Nw=yt,Rw=Ac;function Nr(e){h1.call(this),this.hashMode=typeof e=="string",this.hashMode?this[e]=this._finalOrDigest:this.final=this._finalOrDigest,this._final&&(this.__final=this._final,this._final=null),this._decoder=null,this._encoding=null}Nw(Nr,h1);Nr.prototype.update=function(e,t,r){var n=Rw(e,t),i=this._update(n);return this.hashMode?this:(r&&(i=this._toString(i,r)),i)};Nr.prototype.setAutoPadding=function(){};Nr.prototype.getAuthTag=function(){throw new Error("trying to get auth tag in unsupported state")};Nr.prototype.setAuthTag=function(){throw new Error("trying to set auth tag in unsupported state")};Nr.prototype.setAAD=function(){throw new Error("trying to set aad in unsupported state")};Nr.prototype._transform=function(e,t,r){var n;try{this.hashMode?this._update(e):this.push(this._update(e))}catch(i){n=i}finally{r(n)}};Nr.prototype._flush=function(e){var t;try{this.push(this.__final())}catch(r){t=r}e(t)};Nr.prototype._finalOrDigest=function(e){var t=this.__final()||Cw.alloc(0);return e&&(t=this._toString(t,e,!0)),t};Nr.prototype._toString=function(e,t,r){if(this._decoder||(this._decoder=new Aw(t),this._encoding=t),this._encoding!==t)throw new Error("can’t switch encodings");var n=this._decoder.write(e);return r&&(n+=this._decoder.end()),n};var p1=Nr,Tw=yt,Tn=Qt.Buffer,v1=p1,Lw=Tn.alloc(128),Qn=64;function $l(e,t){v1.call(this,"digest"),typeof t=="string"&&(t=Tn.from(t)),this._alg=e,this._key=t,t.length>Qn?t=e(t):t.length<Qn&&(t=Tn.concat([t,Lw],Qn));for(var r=this._ipad=Tn.allocUnsafe(Qn),n=this._opad=Tn.allocUnsafe(Qn),i=0;i<Qn;i++)r[i]=t[i]^54,n[i]=t[i]^92;this._hash=[r]}Tw($l,v1);$l.prototype._update=function(e){this._hash.push(e)};$l.prototype._final=function(){var e=this._alg(Tn.concat(this._hash));return this._alg(Tn.concat([this._opad,e]))};var Bw=$l,Pw=Qt.Buffer,Mw=Ac,y1=typeof Uint8Array<"u",Ow=y1&&typeof ArrayBuffer<"u",Th=Ow&&ArrayBuffer.isView,Iw=function(e,t){if(typeof e=="string"||Pw.isBuffer(e)||y1&&e instanceof Uint8Array||Th&&Th(e))return Mw(e,t);throw new TypeError('The "data" argument must be a string, a Buffer, a Uint8Array, or a DataView')},xf={exports:{}},bf={exports:{}};typeof process>"u"||!process.version||process.version.indexOf("v0.")===0||process.version.indexOf("v1.")===0&&process.version.indexOf("v1.8.")!==0?bf.exports={nextTick:Dw}:bf.exports=process;function Dw(e,t,r,n){if(typeof e!="function")throw new TypeError('"callback" argument must be a function');var i=arguments.length,o,a;switch(i){case 0:case 1:return process.nextTick(e);case 2:return process.nextTick(function(){e.call(null,t)});case 3:return process.nextTick(function(){e.call(null,t,r)});case 4:return process.nextTick(function(){e.call(null,t,r,n)});default:for(o=new Array(i-1),a=0;a<o.length;)o[a++]=arguments[a];return process.nextTick(function(){e.apply(null,o)})}}var Hl=bf.exports,Uw={}.toString,Fw=Array.isArray||function(e){return Uw.call(e)=="[object Array]"},g1=Dl.EventEmitter,wf={exports:{}};(function(e,t){var r=Xr,n=r.Buffer;function i(a,s){for(var u in a)s[u]=a[u]}n.from&&n.alloc&&n.allocUnsafe&&n.allocUnsafeSlow?e.exports=r:(i(r,t),t.Buffer=o);function o(a,s,u){return n(a,s,u)}i(n,o),o.from=function(a,s,u){if(typeof a=="number")throw new TypeError("Argument must not be a number");return n(a,s,u)},o.alloc=function(a,s,u){if(typeof a!="number")throw new TypeError("Argument must be a number");var d=n(a);return s!==void 0?typeof u=="string"?d.fill(s,u):d.fill(s):d.fill(0),d},o.allocUnsafe=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return n(a)},o.allocUnsafeSlow=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return r.SlowBuffer(a)}})(wf,wf.exports);var Nc=wf.exports,wt={};function zw(e){return Array.isArray?Array.isArray(e):Wl(e)==="[object Array]"}wt.isArray=zw;function $w(e){return typeof e=="boolean"}wt.isBoolean=$w;function Hw(e){return e===null}wt.isNull=Hw;function Ww(e){return e==null}wt.isNullOrUndefined=Ww;function Vw(e){return typeof e=="number"}wt.isNumber=Vw;function Kw(e){return typeof e=="string"}wt.isString=Kw;function qw(e){return typeof e=="symbol"}wt.isSymbol=qw;function Gw(e){return e===void 0}wt.isUndefined=Gw;function Yw(e){return Wl(e)==="[object RegExp]"}wt.isRegExp=Yw;function Qw(e){return typeof e=="object"&&e!==null}wt.isObject=Qw;function Xw(e){return Wl(e)==="[object Date]"}wt.isDate=Xw;function Zw(e){return Wl(e)==="[object Error]"||e instanceof Error}wt.isError=Zw;function Jw(e){return typeof e=="function"}wt.isFunction=Jw;function e_(e){return e===null||typeof e=="boolean"||typeof e=="number"||typeof e=="string"||typeof e=="symbol"||typeof e>"u"}wt.isPrimitive=e_;wt.isBuffer=Xr.Buffer.isBuffer;function Wl(e){return Object.prototype.toString.call(e)}var au={exports:{}},Lh;function t_(){return Lh||(Lh=1,function(e){function t(o,a){if(!(o instanceof a))throw new TypeError("Cannot call a class as a function")}var r=Nc.Buffer,n=Ho;function i(o,a,s){o.copy(a,s)}e.exports=function(){function o(){t(this,o),this.head=null,this.tail=null,this.length=0}return o.prototype.push=function(s){var u={data:s,next:null};this.length>0?this.tail.next=u:this.head=u,this.tail=u,++this.length},o.prototype.unshift=function(s){var u={data:s,next:this.head};this.length===0&&(this.tail=u),this.head=u,++this.length},o.prototype.shift=function(){if(this.length!==0){var s=this.head.data;return this.length===1?this.head=this.tail=null:this.head=this.head.next,--this.length,s}},o.prototype.clear=function(){this.head=this.tail=null,this.length=0},o.prototype.join=function(s){if(this.length===0)return"";for(var u=this.head,d=""+u.data;u=u.next;)d+=s+u.data;return d},o.prototype.concat=function(s){if(this.length===0)return r.alloc(0);for(var u=r.allocUnsafe(s>>>0),d=this.head,_=0;d;)i(d.data,u,_),_+=d.data.length,d=d.next;return u},o}(),n&&n.inspect&&n.inspect.custom&&(e.exports.prototype[n.inspect.custom]=function(){var o=n.inspect({length:this.length});return this.constructor.name+" "+o})}(au)),au.exports}var ka=Hl;function r_(e,t){var r=this,n=this._readableState&&this._readableState.destroyed,i=this._writableState&&this._writableState.destroyed;return n||i?(t?t(e):e&&(this._writableState?this._writableState.errorEmitted||(this._writableState.errorEmitted=!0,ka.nextTick(Sa,this,e)):ka.nextTick(Sa,this,e)),this):(this._readableState&&(this._readableState.destroyed=!0),this._writableState&&(this._writableState.destroyed=!0),this._destroy(e||null,function(o){!t&&o?r._writableState?r._writableState.errorEmitted||(r._writableState.errorEmitted=!0,ka.nextTick(Sa,r,o)):ka.nextTick(Sa,r,o):t&&t(o)}),this)}function n_(){this._readableState&&(this._readableState.destroyed=!1,this._readableState.reading=!1,this._readableState.ended=!1,this._readableState.endEmitted=!1),this._writableState&&(this._writableState.destroyed=!1,this._writableState.ended=!1,this._writableState.ending=!1,this._writableState.finalCalled=!1,this._writableState.prefinished=!1,this._writableState.finished=!1,this._writableState.errorEmitted=!1)}function Sa(e,t){e.emit("error",t)}var m1={destroy:r_,undestroy:n_},lu,Bh;function x1(){if(Bh)return lu;Bh=1;var e=Hl;lu=N;function t(I){var A=this;this.next=null,this.entry=null,this.finish=function(){tt(A,I)}}var r=!process.browser&&["v0.10","v0.9."].indexOf(process.version.slice(0,5))>-1?setImmediate:e.nextTick,n;N.WritableState=B;var i=Object.create(wt);i.inherits=yt;var o={deprecate:Kv},a=g1,s=Nc.Buffer,u=(typeof gr<"u"?gr:typeof window<"u"?window:typeof self<"u"?self:{}).Uint8Array||function(){};function d(I){return s.from(I)}function _(I){return s.isBuffer(I)||I instanceof u}var m=m1;i.inherits(N,a);function E(){}function B(I,A){n=n||Ai(),I=I||{};var D=A instanceof n;this.objectMode=!!I.objectMode,D&&(this.objectMode=this.objectMode||!!I.writableObjectMode);var J=I.highWaterMark,le=I.writableHighWaterMark,de=this.objectMode?16:16*1024;J||J===0?this.highWaterMark=J:D&&(le||le===0)?this.highWaterMark=le:this.highWaterMark=de,this.highWaterMark=Math.floor(this.highWaterMark),this.finalCalled=!1,this.needDrain=!1,this.ending=!1,this.ended=!1,this.finished=!1,this.destroyed=!1;var Ne=I.decodeStrings===!1;this.decodeStrings=!Ne,this.defaultEncoding=I.defaultEncoding||"utf8",this.length=0,this.writing=!1,this.corked=0,this.sync=!0,this.bufferProcessing=!1,this.onwrite=function(Re){Q(A,Re)},this.writecb=null,this.writelen=0,this.bufferedRequest=null,this.lastBufferedRequest=null,this.pendingcb=0,this.prefinished=!1,this.errorEmitted=!1,this.bufferedRequestCount=0,this.corkedRequestsFree=new t(this)}B.prototype.getBuffer=function(){for(var A=this.bufferedRequest,D=[];A;)D.push(A),A=A.next;return D},function(){try{Object.defineProperty(B.prototype,"buffer",{get:o.deprecate(function(){return this.getBuffer()},"_writableState.buffer is deprecated. Use _writableState.getBuffer instead.","DEP0003")})}catch{}}();var R;typeof Symbol=="function"&&Symbol.hasInstance&&typeof Function.prototype[Symbol.hasInstance]=="function"?(R=Function.prototype[Symbol.hasInstance],Object.defineProperty(N,Symbol.hasInstance,{value:function(I){return R.call(this,I)?!0:this!==N?!1:I&&I._writableState instanceof B}})):R=function(I){return I instanceof this};function N(I){if(n=n||Ai(),!R.call(N,this)&&!(this instanceof n))return new N(I);this._writableState=new B(I,this),this.writable=!0,I&&(typeof I.write=="function"&&(this._write=I.write),typeof I.writev=="function"&&(this._writev=I.writev),typeof I.destroy=="function"&&(this._destroy=I.destroy),typeof I.final=="function"&&(this._final=I.final)),a.call(this)}N.prototype.pipe=function(){this.emit("error",new Error("Cannot pipe, not readable"))};function P(I,A){var D=new Error("write after end");I.emit("error",D),e.nextTick(A,D)}function p(I,A,D,J){var le=!0,de=!1;return D===null?de=new TypeError("May not write null values to stream"):typeof D!="string"&&D!==void 0&&!A.objectMode&&(de=new TypeError("Invalid non-string/buffer chunk")),de&&(I.emit("error",de),e.nextTick(J,de),le=!1),le}N.prototype.write=function(I,A,D){var J=this._writableState,le=!1,de=!J.objectMode&&_(I);return de&&!s.isBuffer(I)&&(I=d(I)),typeof A=="function"&&(D=A,A=null),de?A="buffer":A||(A=J.defaultEncoding),typeof D!="function"&&(D=E),J.ended?P(this,D):(de||p(this,J,I,D))&&(J.pendingcb++,le=x(this,J,de,I,A,D)),le},N.prototype.cork=function(){var I=this._writableState;I.corked++},N.prototype.uncork=function(){var I=this._writableState;I.corked&&(I.corked--,!I.writing&&!I.corked&&!I.bufferProcessing&&I.bufferedRequest&&pe(this,I))},N.prototype.setDefaultEncoding=function(A){if(typeof A=="string"&&(A=A.toLowerCase()),!(["hex","utf8","utf-8","ascii","binary","base64","ucs2","ucs-2","utf16le","utf-16le","raw"].indexOf((A+"").toLowerCase())>-1))throw new TypeError("Unknown encoding: "+A);return this._writableState.defaultEncoding=A,this};function v(I,A,D){return!I.objectMode&&I.decodeStrings!==!1&&typeof A=="string"&&(A=s.from(A,D)),A}Object.defineProperty(N.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}});function x(I,A,D,J,le,de){if(!D){var Ne=v(A,J,le);J!==Ne&&(D=!0,le="buffer",J=Ne)}var Re=A.objectMode?1:J.length;A.length+=Re;var ge=A.length<A.highWaterMark;if(ge||(A.needDrain=!0),A.writing||A.corked){var T=A.lastBufferedRequest;A.lastBufferedRequest={chunk:J,encoding:le,isBuf:D,callback:de,next:null},T?T.next=A.lastBufferedRequest:A.bufferedRequest=A.lastBufferedRequest,A.bufferedRequestCount+=1}else C(I,A,!1,Re,J,le,de);return ge}function C(I,A,D,J,le,de,Ne){A.writelen=J,A.writecb=Ne,A.writing=!0,A.sync=!0,D?I._writev(le,A.onwrite):I._write(le,de,A.onwrite),A.sync=!1}function O(I,A,D,J,le){--A.pendingcb,D?(e.nextTick(le,J),e.nextTick(He,I,A),I._writableState.errorEmitted=!0,I.emit("error",J)):(le(J),I._writableState.errorEmitted=!0,I.emit("error",J),He(I,A))}function H(I){I.writing=!1,I.writecb=null,I.length-=I.writelen,I.writelen=0}function Q(I,A){var D=I._writableState,J=D.sync,le=D.writecb;if(H(D),A)O(I,D,J,A,le);else{var de=De(D);!de&&!D.corked&&!D.bufferProcessing&&D.bufferedRequest&&pe(I,D),J?r(V,I,D,de,le):V(I,D,de,le)}}function V(I,A,D,J){D||X(I,A),A.pendingcb--,J(),He(I,A)}function X(I,A){A.length===0&&A.needDrain&&(A.needDrain=!1,I.emit("drain"))}function pe(I,A){A.bufferProcessing=!0;var D=A.bufferedRequest;if(I._writev&&D&&D.next){var J=A.bufferedRequestCount,le=new Array(J),de=A.corkedRequestsFree;de.entry=D;for(var Ne=0,Re=!0;D;)le[Ne]=D,D.isBuf||(Re=!1),D=D.next,Ne+=1;le.allBuffers=Re,C(I,A,!0,A.length,le,"",de.finish),A.pendingcb++,A.lastBufferedRequest=null,de.next?(A.corkedRequestsFree=de.next,de.next=null):A.corkedRequestsFree=new t(A),A.bufferedRequestCount=0}else{for(;D;){var ge=D.chunk,T=D.encoding,h=D.callback,b=A.objectMode?1:ge.length;if(C(I,A,!1,b,ge,T,h),D=D.next,A.bufferedRequestCount--,A.writing)break}D===null&&(A.lastBufferedRequest=null)}A.bufferedRequest=D,A.bufferProcessing=!1}N.prototype._write=function(I,A,D){D(new Error("_write() is not implemented"))},N.prototype._writev=null,N.prototype.end=function(I,A,D){var J=this._writableState;typeof I=="function"?(D=I,I=null,A=null):typeof A=="function"&&(D=A,A=null),I!=null&&this.write(I,A),J.corked&&(J.corked=1,this.uncork()),J.ending||nt(this,J,D)};function De(I){return I.ending&&I.length===0&&I.bufferedRequest===null&&!I.finished&&!I.writing}function $e(I,A){I._final(function(D){A.pendingcb--,D&&I.emit("error",D),A.prefinished=!0,I.emit("prefinish"),He(I,A)})}function _e(I,A){!A.prefinished&&!A.finalCalled&&(typeof I._final=="function"?(A.pendingcb++,A.finalCalled=!0,e.nextTick($e,I,A)):(A.prefinished=!0,I.emit("prefinish")))}function He(I,A){var D=De(A);return D&&(_e(I,A),A.pendingcb===0&&(A.finished=!0,I.emit("finish"))),D}function nt(I,A,D){A.ending=!0,He(I,A),D&&(A.finished?e.nextTick(D):I.once("finish",D)),A.ended=!0,I.writable=!1}function tt(I,A,D){var J=I.entry;for(I.entry=null;J;){var le=J.callback;A.pendingcb--,le(D),J=J.next}A.corkedRequestsFree.next=I}return Object.defineProperty(N.prototype,"destroyed",{get:function(){return this._writableState===void 0?!1:this._writableState.destroyed},set:function(I){this._writableState&&(this._writableState.destroyed=I)}}),N.prototype.destroy=m.destroy,N.prototype._undestroy=m.undestroy,N.prototype._destroy=function(I,A){this.end(),A(I)},lu}var su,Ph;function Ai(){if(Ph)return su;Ph=1;var e=Hl,t=Object.keys||function(m){var E=[];for(var B in m)E.push(B);return E};su=u;var r=Object.create(wt);r.inherits=yt;var n=b1(),i=x1();r.inherits(u,n);for(var o=t(i.prototype),a=0;a<o.length;a++){var s=o[a];u.prototype[s]||(u.prototype[s]=i.prototype[s])}function u(m){if(!(this instanceof u))return new u(m);n.call(this,m),i.call(this,m),m&&m.readable===!1&&(this.readable=!1),m&&m.writable===!1&&(this.writable=!1),this.allowHalfOpen=!0,m&&m.allowHalfOpen===!1&&(this.allowHalfOpen=!1),this.once("end",d)}Object.defineProperty(u.prototype,"writableHighWaterMark",{enumerable:!1,get:function(){return this._writableState.highWaterMark}});function d(){this.allowHalfOpen||this._writableState.ended||e.nextTick(_,this)}function _(m){m.end()}return Object.defineProperty(u.prototype,"destroyed",{get:function(){return this._readableState===void 0||this._writableState===void 0?!1:this._readableState.destroyed&&this._writableState.destroyed},set:function(m){this._readableState===void 0||this._writableState===void 0||(this._readableState.destroyed=m,this._writableState.destroyed=m)}}),u.prototype._destroy=function(m,E){this.push(null),this.end(),e.nextTick(E,m)},su}var uu={},Ea={exports:{}},Mh;function i_(){return Mh||(Mh=1,function(e,t){var r=Xr,n=r.Buffer;function i(a,s){for(var u in a)s[u]=a[u]}n.from&&n.alloc&&n.allocUnsafe&&n.allocUnsafeSlow?e.exports=r:(i(r,t),t.Buffer=o);function o(a,s,u){return n(a,s,u)}i(n,o),o.from=function(a,s,u){if(typeof a=="number")throw new TypeError("Argument must not be a number");return n(a,s,u)},o.alloc=function(a,s,u){if(typeof a!="number")throw new TypeError("Argument must be a number");var d=n(a);return s!==void 0?typeof u=="string"?d.fill(s,u):d.fill(s):d.fill(0),d},o.allocUnsafe=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return n(a)},o.allocUnsafeSlow=function(a){if(typeof a!="number")throw new TypeError("Argument must be a number");return r.SlowBuffer(a)}}(Ea,Ea.exports)),Ea.exports}var Oh;function Ih(){if(Oh)return uu;Oh=1;var e=i_().Buffer,t=e.isEncoding||function(p){switch(p=""+p,p&&p.toLowerCase()){case"hex":case"utf8":case"utf-8":case"ascii":case"binary":case"base64":case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":case"raw":return!0;default:return!1}};function r(p){if(!p)return"utf8";for(var v;;)switch(p){case"utf8":case"utf-8":return"utf8";case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return"utf16le";case"latin1":case"binary":return"latin1";case"base64":case"ascii":case"hex":return p;default:if(v)return;p=(""+p).toLowerCase(),v=!0}}function n(p){var v=r(p);if(typeof v!="string"&&(e.isEncoding===t||!t(p)))throw new Error("Unknown encoding: "+p);return v||p}uu.StringDecoder=i;function i(p){this.encoding=n(p);var v;switch(this.encoding){case"utf16le":this.text=m,this.end=E,v=4;break;case"utf8":this.fillLast=u,v=4;break;case"base64":this.text=B,this.end=R,v=3;break;default:this.write=N,this.end=P;return}this.lastNeed=0,this.lastTotal=0,this.lastChar=e.allocUnsafe(v)}i.prototype.write=function(p){if(p.length===0)return"";var v,x;if(this.lastNeed){if(v=this.fillLast(p),v===void 0)return"";x=this.lastNeed,this.lastNeed=0}else x=0;return x<p.length?v?v+this.text(p,x):this.text(p,x):v||""},i.prototype.end=_,i.prototype.text=d,i.prototype.fillLast=function(p){if(this.lastNeed<=p.length)return p.copy(this.lastChar,this.lastTotal-this.lastNeed,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal);p.copy(this.lastChar,this.lastTotal-this.lastNeed,0,p.length),this.lastNeed-=p.length};function o(p){return p<=127?0:p>>5===6?2:p>>4===14?3:p>>3===30?4:p>>6===2?-1:-2}function a(p,v,x){var C=v.length-1;if(C<x)return 0;var O=o(v[C]);return O>=0?(O>0&&(p.lastNeed=O-1),O):--C<x||O===-2?0:(O=o(v[C]),O>=0?(O>0&&(p.lastNeed=O-2),O):--C<x||O===-2?0:(O=o(v[C]),O>=0?(O>0&&(O===2?O=0:p.lastNeed=O-3),O):0))}function s(p,v,x){if((v[0]&192)!==128)return p.lastNeed=0,"�";if(p.lastNeed>1&&v.length>1){if((v[1]&192)!==128)return p.lastNeed=1,"�";if(p.lastNeed>2&&v.length>2&&(v[2]&192)!==128)return p.lastNeed=2,"�"}}function u(p){var v=this.lastTotal-this.lastNeed,x=s(this,p);if(x!==void 0)return x;if(this.lastNeed<=p.length)return p.copy(this.lastChar,v,0,this.lastNeed),this.lastChar.toString(this.encoding,0,this.lastTotal);p.copy(this.lastChar,v,0,p.length),this.lastNeed-=p.length}function d(p,v){var x=a(this,p,v);if(!this.lastNeed)return p.toString("utf8",v);this.lastTotal=x;var C=p.length-(x-this.lastNeed);return p.copy(this.lastChar,0,C),p.toString("utf8",v,C)}function _(p){var v=p&&p.length?this.write(p):"";return this.lastNeed?v+"�":v}function m(p,v){if((p.length-v)%2===0){var x=p.toString("utf16le",v);if(x){var C=x.charCodeAt(x.length-1);if(C>=55296&&C<=56319)return this.lastNeed=2,this.lastTotal=4,this.lastChar[0]=p[p.length-2],this.lastChar[1]=p[p.length-1],x.slice(0,-1)}return x}return this.lastNeed=1,this.lastTotal=2,this.lastChar[0]=p[p.length-1],p.toString("utf16le",v,p.length-1)}function E(p){var v=p&&p.length?this.write(p):"";if(this.lastNeed){var x=this.lastTotal-this.lastNeed;return v+this.lastChar.toString("utf16le",0,x)}return v}function B(p,v){var x=(p.length-v)%3;return x===0?p.toString("base64",v):(this.lastNeed=3-x,this.lastTotal=3,x===1?this.lastChar[0]=p[p.length-1]:(this.lastChar[0]=p[p.length-2],this.lastChar[1]=p[p.length-1]),p.toString("base64",v,p.length-x))}function R(p){var v=p&&p.length?this.write(p):"";return this.lastNeed?v+this.lastChar.toString("base64",0,3-this.lastNeed):v}function N(p){return p.toString(this.encoding)}function P(p){return p&&p.length?this.write(p):""}return uu}var fu,Dh;function b1(){if(Dh)return fu;Dh=1;var e=Hl;fu=v;var t=Fw,r;v.ReadableState=p,Dl.EventEmitter;var n=function(h,b){return h.listeners(b).length},i=g1,o=Nc.Buffer,a=(typeof gr<"u"?gr:typeof window<"u"?window:typeof self<"u"?self:{}).Uint8Array||function(){};function s(h){return o.from(h)}function u(h){return o.isBuffer(h)||h instanceof a}var d=Object.create(wt);d.inherits=yt;var _=Ho,m=void 0;_&&_.debuglog?m=_.debuglog("stream"):m=function(){};var E=t_(),B=m1,R;d.inherits(v,i);var N=["error","close","destroy","pause","resume"];function P(h,b,F){if(typeof h.prependListener=="function")return h.prependListener(b,F);!h._events||!h._events[b]?h.on(b,F):t(h._events[b])?h._events[b].unshift(F):h._events[b]=[F,h._events[b]]}function p(h,b){r=r||Ai(),h=h||{};var F=b instanceof r;this.objectMode=!!h.objectMode,F&&(this.objectMode=this.objectMode||!!h.readableObjectMode);var K=h.highWaterMark,S=h.readableHighWaterMark,k=this.objectMode?16:16*1024;K||K===0?this.highWaterMark=K:F&&(S||S===0)?this.highWaterMark=S:this.highWaterMark=k,this.highWaterMark=Math.floor(this.highWaterMark),this.buffer=new E,this.length=0,this.pipes=null,this.pipesCount=0,this.flowing=null,this.ended=!1,this.endEmitted=!1,this.reading=!1,this.sync=!0,this.needReadable=!1,this.emittedReadable=!1,this.readableListening=!1,this.resumeScheduled=!1,this.destroyed=!1,this.defaultEncoding=h.defaultEncoding||"utf8",this.awaitDrain=0,this.readingMore=!1,this.decoder=null,this.encoding=null,h.encoding&&(R||(R=Ih().StringDecoder),this.decoder=new R(h.encoding),this.encoding=h.encoding)}function v(h){if(r=r||Ai(),!(this instanceof v))return new v(h);this._readableState=new p(h,this),this.readable=!0,h&&(typeof h.read=="function"&&(this._read=h.read),typeof h.destroy=="function"&&(this._destroy=h.destroy)),i.call(this)}Object.defineProperty(v.prototype,"destroyed",{get:function(){return this._readableState===void 0?!1:this._readableState.destroyed},set:function(h){this._readableState&&(this._readableState.destroyed=h)}}),v.prototype.destroy=B.destroy,v.prototype._undestroy=B.undestroy,v.prototype._destroy=function(h,b){this.push(null),b(h)},v.prototype.push=function(h,b){var F=this._readableState,K;return F.objectMode?K=!0:typeof h=="string"&&(b=b||F.defaultEncoding,b!==F.encoding&&(h=o.from(h,b),b=""),K=!0),x(this,h,b,!1,K)},v.prototype.unshift=function(h){return x(this,h,null,!0,!1)};function x(h,b,F,K,S){var k=h._readableState;if(b===null)k.reading=!1,pe(h,k);else{var U;S||(U=O(k,b)),U?h.emit("error",U):k.objectMode||b&&b.length>0?(typeof b!="string"&&!k.objectMode&&Object.getPrototypeOf(b)!==o.prototype&&(b=s(b)),K?k.endEmitted?h.emit("error",new Error("stream.unshift() after end event")):C(h,k,b,!0):k.ended?h.emit("error",new Error("stream.push() after EOF")):(k.reading=!1,k.decoder&&!F?(b=k.decoder.write(b),k.objectMode||b.length!==0?C(h,k,b,!1):_e(h,k)):C(h,k,b,!1))):K||(k.reading=!1)}return H(k)}function C(h,b,F,K){b.flowing&&b.length===0&&!b.sync?(h.emit("data",F),h.read(0)):(b.length+=b.objectMode?1:F.length,K?b.buffer.unshift(F):b.buffer.push(F),b.needReadable&&De(h)),_e(h,b)}function O(h,b){var F;return!u(b)&&typeof b!="string"&&b!==void 0&&!h.objectMode&&(F=new TypeError("Invalid non-string/buffer chunk")),F}function H(h){return!h.ended&&(h.needReadable||h.length<h.highWaterMark||h.length===0)}v.prototype.isPaused=function(){return this._readableState.flowing===!1},v.prototype.setEncoding=function(h){return R||(R=Ih().StringDecoder),this._readableState.decoder=new R(h),this._readableState.encoding=h,this};var Q=8388608;function V(h){return h>=Q?h=Q:(h--,h|=h>>>1,h|=h>>>2,h|=h>>>4,h|=h>>>8,h|=h>>>16,h++),h}function X(h,b){return h<=0||b.length===0&&b.ended?0:b.objectMode?1:h!==h?b.flowing&&b.length?b.buffer.head.data.length:b.length:(h>b.highWaterMark&&(b.highWaterMark=V(h)),h<=b.length?h:b.ended?b.length:(b.needReadable=!0,0))}v.prototype.read=function(h){m("read",h),h=parseInt(h,10);var b=this._readableState,F=h;if(h!==0&&(b.emittedReadable=!1),h===0&&b.needReadable&&(b.length>=b.highWaterMark||b.ended))return m("read: emitReadable",b.length,b.ended),b.length===0&&b.ended?Re(this):De(this),null;if(h=X(h,b),h===0&&b.ended)return b.length===0&&Re(this),null;var K=b.needReadable;m("need readable",K),(b.length===0||b.length-h<b.highWaterMark)&&(K=!0,m("length less than watermark",K)),b.ended||b.reading?(K=!1,m("reading or ended",K)):K&&(m("do read"),b.reading=!0,b.sync=!0,b.length===0&&(b.needReadable=!0),this._read(b.highWaterMark),b.sync=!1,b.reading||(h=X(F,b)));var S;return h>0?S=J(h,b):S=null,S===null?(b.needReadable=!0,h=0):b.length-=h,b.length===0&&(b.ended||(b.needReadable=!0),F!==h&&b.ended&&Re(this)),S!==null&&this.emit("data",S),S};function pe(h,b){if(!b.ended){if(b.decoder){var F=b.decoder.end();F&&F.length&&(b.buffer.push(F),b.length+=b.objectMode?1:F.length)}b.ended=!0,De(h)}}function De(h){var b=h._readableState;b.needReadable=!1,b.emittedReadable||(m("emitReadable",b.flowing),b.emittedReadable=!0,b.sync?e.nextTick($e,h):$e(h))}function $e(h){m("emit readable"),h.emit("readable"),D(h)}function _e(h,b){b.readingMore||(b.readingMore=!0,e.nextTick(He,h,b))}function He(h,b){for(var F=b.length;!b.reading&&!b.flowing&&!b.ended&&b.length<b.highWaterMark&&(m("maybeReadMore read 0"),h.read(0),F!==b.length);)F=b.length;b.readingMore=!1}v.prototype._read=function(h){this.emit("error",new Error("_read() is not implemented"))},v.prototype.pipe=function(h,b){var F=this,K=this._readableState;switch(K.pipesCount){case 0:K.pipes=h;break;case 1:K.pipes=[K.pipes,h];break;default:K.pipes.push(h);break}K.pipesCount+=1,m("pipe count=%d opts=%j",K.pipesCount,b);var S=(!b||b.end!==!1)&&h!==process.stdout&&h!==process.stderr,k=S?ie:Vt;K.endEmitted?e.nextTick(k):F.once("end",k),h.on("unpipe",U);function U(W,ne){m("onunpipe"),W===F&&ne&&ne.hasUnpiped===!1&&(ne.hasUnpiped=!0,Ke())}function ie(){m("onend"),h.end()}var Xe=nt(F);h.on("drain",Xe);var Ce=!1;function Ke(){m("cleanup"),h.removeListener("close",Rr),h.removeListener("finish",cr),h.removeListener("drain",Xe),h.removeListener("error",rr),h.removeListener("unpipe",U),F.removeListener("end",ie),F.removeListener("end",Vt),F.removeListener("data",Nt),Ce=!0,K.awaitDrain&&(!h._writableState||h._writableState.needDrain)&&Xe()}var Wt=!1;F.on("data",Nt);function Nt(W){m("ondata"),Wt=!1;var ne=h.write(W);ne===!1&&!Wt&&((K.pipesCount===1&&K.pipes===h||K.pipesCount>1&&T(K.pipes,h)!==-1)&&!Ce&&(m("false write response, pause",K.awaitDrain),K.awaitDrain++,Wt=!0),F.pause())}function rr(W){m("onerror",W),Vt(),h.removeListener("error",rr),n(h,"error")===0&&h.emit("error",W)}P(h,"error",rr);function Rr(){h.removeListener("finish",cr),Vt()}h.once("close",Rr);function cr(){m("onfinish"),h.removeListener("close",Rr),Vt()}h.once("finish",cr);function Vt(){m("unpipe"),F.unpipe(h)}return h.emit("pipe",F),K.flowing||(m("pipe resume"),F.resume()),h};function nt(h){return function(){var b=h._readableState;m("pipeOnDrain",b.awaitDrain),b.awaitDrain&&b.awaitDrain--,b.awaitDrain===0&&n(h,"data")&&(b.flowing=!0,D(h))}}v.prototype.unpipe=function(h){var b=this._readableState,F={hasUnpiped:!1};if(b.pipesCount===0)return this;if(b.pipesCount===1)return h&&h!==b.pipes?this:(h||(h=b.pipes),b.pipes=null,b.pipesCount=0,b.flowing=!1,h&&h.emit("unpipe",this,F),this);if(!h){var K=b.pipes,S=b.pipesCount;b.pipes=null,b.pipesCount=0,b.flowing=!1;for(var k=0;k<S;k++)K[k].emit("unpipe",this,{hasUnpiped:!1});return this}var U=T(b.pipes,h);return U===-1?this:(b.pipes.splice(U,1),b.pipesCount-=1,b.pipesCount===1&&(b.pipes=b.pipes[0]),h.emit("unpipe",this,F),this)},v.prototype.on=function(h,b){var F=i.prototype.on.call(this,h,b);if(h==="data")this._readableState.flowing!==!1&&this.resume();else if(h==="readable"){var K=this._readableState;!K.endEmitted&&!K.readableListening&&(K.readableListening=K.needReadable=!0,K.emittedReadable=!1,K.reading?K.length&&De(this):e.nextTick(tt,this))}return F},v.prototype.addListener=v.prototype.on;function tt(h){m("readable nexttick read 0"),h.read(0)}v.prototype.resume=function(){var h=this._readableState;return h.flowing||(m("resume"),h.flowing=!0,I(this,h)),this};function I(h,b){b.resumeScheduled||(b.resumeScheduled=!0,e.nextTick(A,h,b))}function A(h,b){b.reading||(m("resume read 0"),h.read(0)),b.resumeScheduled=!1,b.awaitDrain=0,h.emit("resume"),D(h),b.flowing&&!b.reading&&h.read(0)}v.prototype.pause=function(){return m("call pause flowing=%j",this._readableState.flowing),this._readableState.flowing!==!1&&(m("pause"),this._readableState.flowing=!1,this.emit("pause")),this};function D(h){var b=h._readableState;for(m("flow",b.flowing);b.flowing&&h.read()!==null;);}v.prototype.wrap=function(h){var b=this,F=this._readableState,K=!1;h.on("end",function(){if(m("wrapped end"),F.decoder&&!F.ended){var U=F.decoder.end();U&&U.length&&b.push(U)}b.push(null)}),h.on("data",function(U){if(m("wrapped data"),F.decoder&&(U=F.decoder.write(U)),!(F.objectMode&&U==null)&&!(!F.objectMode&&(!U||!U.length))){var ie=b.push(U);ie||(K=!0,h.pause())}});for(var S in h)this[S]===void 0&&typeof h[S]=="function"&&(this[S]=function(U){return function(){return h[U].apply(h,arguments)}}(S));for(var k=0;k<N.length;k++)h.on(N[k],this.emit.bind(this,N[k]));return this._read=function(U){m("wrapped _read",U),K&&(K=!1,h.resume())},this},Object.defineProperty(v.prototype,"readableHighWaterMark",{enumerable:!1,get:function(){return this._readableState.highWaterMark}}),v._fromList=J;function J(h,b){if(b.length===0)return null;var F;return b.objectMode?F=b.buffer.shift():!h||h>=b.length?(b.decoder?F=b.buffer.join(""):b.buffer.length===1?F=b.buffer.head.data:F=b.buffer.concat(b.length),b.buffer.clear()):F=le(h,b.buffer,b.decoder),F}function le(h,b,F){var K;return h<b.head.data.length?(K=b.head.data.slice(0,h),b.head.data=b.head.data.slice(h)):h===b.head.data.length?K=b.shift():K=F?de(h,b):Ne(h,b),K}function de(h,b){var F=b.head,K=1,S=F.data;for(h-=S.length;F=F.next;){var k=F.data,U=h>k.length?k.length:h;if(U===k.length?S+=k:S+=k.slice(0,h),h-=U,h===0){U===k.length?(++K,F.next?b.head=F.next:b.head=b.tail=null):(b.head=F,F.data=k.slice(U));break}++K}return b.length-=K,S}function Ne(h,b){var F=o.allocUnsafe(h),K=b.head,S=1;for(K.data.copy(F),h-=K.data.length;K=K.next;){var k=K.data,U=h>k.length?k.length:h;if(k.copy(F,F.length-h,0,U),h-=U,h===0){U===k.length?(++S,K.next?b.head=K.next:b.head=b.tail=null):(b.head=K,K.data=k.slice(U));break}++S}return b.length-=S,F}function Re(h){var b=h._readableState;if(b.length>0)throw new Error('"endReadable()" called on non-empty stream');b.endEmitted||(b.ended=!0,e.nextTick(ge,b,h))}function ge(h,b){!h.endEmitted&&h.length===0&&(h.endEmitted=!0,b.readable=!1,b.emit("end"))}function T(h,b){for(var F=0,K=h.length;F<K;F++)if(h[F]===b)return F;return-1}return fu}var w1=Qr,Vl=Ai(),_1=Object.create(wt);_1.inherits=yt;_1.inherits(Qr,Vl);function o_(e,t){var r=this._transformState;r.transforming=!1;var n=r.writecb;if(!n)return this.emit("error",new Error("write callback called multiple times"));r.writechunk=null,r.writecb=null,t!=null&&this.push(t),n(e);var i=this._readableState;i.reading=!1,(i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}function Qr(e){if(!(this instanceof Qr))return new Qr(e);Vl.call(this,e),this._transformState={afterTransform:o_.bind(this),needTransform:!1,transforming:!1,writecb:null,writechunk:null,writeencoding:null},this._readableState.needReadable=!0,this._readableState.sync=!1,e&&(typeof e.transform=="function"&&(this._transform=e.transform),typeof e.flush=="function"&&(this._flush=e.flush)),this.on("prefinish",a_)}function a_(){var e=this;typeof this._flush=="function"?this._flush(function(t,r){Uh(e,t,r)}):Uh(this,null,null)}Qr.prototype.push=function(e,t){return this._transformState.needTransform=!1,Vl.prototype.push.call(this,e,t)};Qr.prototype._transform=function(e,t,r){throw new Error("_transform() is not implemented")};Qr.prototype._write=function(e,t,r){var n=this._transformState;if(n.writecb=r,n.writechunk=e,n.writeencoding=t,!n.transforming){var i=this._readableState;(n.needTransform||i.needReadable||i.length<i.highWaterMark)&&this._read(i.highWaterMark)}};Qr.prototype._read=function(e){var t=this._transformState;t.writechunk!==null&&t.writecb&&!t.transforming?(t.transforming=!0,this._transform(t.writechunk,t.writeencoding,t.afterTransform)):t.needTransform=!0};Qr.prototype._destroy=function(e,t){var r=this;Vl.prototype._destroy.call(this,e,function(n){t(n),r.emit("close")})};function Uh(e,t,r){if(t)return e.emit("error",t);if(r!=null&&e.push(r),e._writableState.length)throw new Error("Calling transform done when ws.length != 0");if(e._transformState.transforming)throw new Error("Calling transform done when still transforming");return e.push(null)}var l_=Oo,k1=w1,S1=Object.create(wt);S1.inherits=yt;S1.inherits(Oo,k1);function Oo(e){if(!(this instanceof Oo))return new Oo(e);k1.call(this,e)}Oo.prototype._transform=function(e,t,r){r(null,e)};(function(e,t){t=e.exports=b1(),t.Stream=t,t.Readable=t,t.Writable=x1(),t.Duplex=Ai(),t.Transform=w1,t.PassThrough=l_})(xf,xf.exports);var s_=xf.exports,u_=Qt.Buffer,f_=Iw,E1=s_.Transform,c_=yt;function Sn(e){E1.call(this),this._block=u_.allocUnsafe(e),this._blockSize=e,this._blockOffset=0,this._length=[0,0,0,0],this._finalized=!1}c_(Sn,E1);Sn.prototype._transform=function(e,t,r){var n=null;try{this.update(e,t)}catch(i){n=i}r(n)};Sn.prototype._flush=function(e){var t=null;try{this.push(this.digest())}catch(r){t=r}e(t)};Sn.prototype.update=function(e,t){if(this._finalized)throw new Error("Digest already called");for(var r=f_(e,t),n=this._block,i=0;this._blockOffset+r.length-i>=this._blockSize;){for(var o=this._blockOffset;o<this._blockSize;)n[o]=r[i],o+=1,i+=1;this._update(),this._blockOffset=0}for(;i<r.length;)n[this._blockOffset]=r[i],this._blockOffset+=1,i+=1;for(var a=0,s=r.length*8;s>0;++a)this._length[a]+=s,s=this._length[a]/4294967296|0,s>0&&(this._length[a]-=4294967296*s);return this};Sn.prototype._update=function(){throw new Error("_update is not implemented")};Sn.prototype.digest=function(e){if(this._finalized)throw new Error("Digest already called");this._finalized=!0;var t=this._digest();e!==void 0&&(t=t.toString(e)),this._block.fill(0),this._blockOffset=0;for(var r=0;r<4;++r)this._length[r]=0;return t};Sn.prototype._digest=function(){throw new Error("_digest is not implemented")};var j1=Sn,d_=yt,C1=j1,h_=Qt.Buffer,p_=new Array(16);function Kl(){C1.call(this,64),this._a=1732584193,this._b=4023233417,this._c=2562383102,this._d=271733878}d_(Kl,C1);Kl.prototype._update=function(){for(var e=p_,t=0;t<16;++t)e[t]=this._block.readInt32LE(t*4);var r=this._a,n=this._b,i=this._c,o=this._d;r=Dt(r,n,i,o,e[0],3614090360,7),o=Dt(o,r,n,i,e[1],3905402710,12),i=Dt(i,o,r,n,e[2],606105819,17),n=Dt(n,i,o,r,e[3],3250441966,22),r=Dt(r,n,i,o,e[4],4118548399,7),o=Dt(o,r,n,i,e[5],1200080426,12),i=Dt(i,o,r,n,e[6],2821735955,17),n=Dt(n,i,o,r,e[7],4249261313,22),r=Dt(r,n,i,o,e[8],1770035416,7),o=Dt(o,r,n,i,e[9],2336552879,12),i=Dt(i,o,r,n,e[10],4294925233,17),n=Dt(n,i,o,r,e[11],2304563134,22),r=Dt(r,n,i,o,e[12],1804603682,7),o=Dt(o,r,n,i,e[13],4254626195,12),i=Dt(i,o,r,n,e[14],2792965006,17),n=Dt(n,i,o,r,e[15],1236535329,22),r=Ut(r,n,i,o,e[1],4129170786,5),o=Ut(o,r,n,i,e[6],3225465664,9),i=Ut(i,o,r,n,e[11],643717713,14),n=Ut(n,i,o,r,e[0],3921069994,20),r=Ut(r,n,i,o,e[5],3593408605,5),o=Ut(o,r,n,i,e[10],38016083,9),i=Ut(i,o,r,n,e[15],3634488961,14),n=Ut(n,i,o,r,e[4],3889429448,20),r=Ut(r,n,i,o,e[9],568446438,5),o=Ut(o,r,n,i,e[14],3275163606,9),i=Ut(i,o,r,n,e[3],4107603335,14),n=Ut(n,i,o,r,e[8],1163531501,20),r=Ut(r,n,i,o,e[13],2850285829,5),o=Ut(o,r,n,i,e[2],4243563512,9),i=Ut(i,o,r,n,e[7],1735328473,14),n=Ut(n,i,o,r,e[12],2368359562,20),r=Ft(r,n,i,o,e[5],4294588738,4),o=Ft(o,r,n,i,e[8],2272392833,11),i=Ft(i,o,r,n,e[11],1839030562,16),n=Ft(n,i,o,r,e[14],4259657740,23),r=Ft(r,n,i,o,e[1],2763975236,4),o=Ft(o,r,n,i,e[4],1272893353,11),i=Ft(i,o,r,n,e[7],4139469664,16),n=Ft(n,i,o,r,e[10],3200236656,23),r=Ft(r,n,i,o,e[13],681279174,4),o=Ft(o,r,n,i,e[0],3936430074,11),i=Ft(i,o,r,n,e[3],3572445317,16),n=Ft(n,i,o,r,e[6],76029189,23),r=Ft(r,n,i,o,e[9],3654602809,4),o=Ft(o,r,n,i,e[12],3873151461,11),i=Ft(i,o,r,n,e[15],530742520,16),n=Ft(n,i,o,r,e[2],3299628645,23),r=zt(r,n,i,o,e[0],4096336452,6),o=zt(o,r,n,i,e[7],1126891415,10),i=zt(i,o,r,n,e[14],2878612391,15),n=zt(n,i,o,r,e[5],4237533241,21),r=zt(r,n,i,o,e[12],1700485571,6),o=zt(o,r,n,i,e[3],2399980690,10),i=zt(i,o,r,n,e[10],4293915773,15),n=zt(n,i,o,r,e[1],2240044497,21),r=zt(r,n,i,o,e[8],1873313359,6),o=zt(o,r,n,i,e[15],4264355552,10),i=zt(i,o,r,n,e[6],2734768916,15),n=zt(n,i,o,r,e[13],1309151649,21),r=zt(r,n,i,o,e[4],4149444226,6),o=zt(o,r,n,i,e[11],3174756917,10),i=zt(i,o,r,n,e[2],718787259,15),n=zt(n,i,o,r,e[9],3951481745,21),this._a=this._a+r|0,this._b=this._b+n|0,this._c=this._c+i|0,this._d=this._d+o|0};Kl.prototype._digest=function(){this._block[this._blockOffset++]=128,this._blockOffset>56&&(this._block.fill(0,this._blockOffset,64),this._update(),this._blockOffset=0),this._block.fill(0,this._blockOffset,56),this._block.writeUInt32LE(this._length[0],56),this._block.writeUInt32LE(this._length[1],60),this._update();var e=h_.allocUnsafe(16);return e.writeInt32LE(this._a,0),e.writeInt32LE(this._b,4),e.writeInt32LE(this._c,8),e.writeInt32LE(this._d,12),e};function ql(e,t){return e<<t|e>>>32-t}function Dt(e,t,r,n,i,o,a){return ql(e+(t&r|~t&n)+i+o|0,a)+t|0}function Ut(e,t,r,n,i,o,a){return ql(e+(t&n|r&~n)+i+o|0,a)+t|0}function Ft(e,t,r,n,i,o,a){return ql(e+(t^r^n)+i+o|0,a)+t|0}function zt(e,t,r,n,i,o,a){return ql(e+(r^(t|~n))+i+o|0,a)+t|0}var v_=Kl,y_=v_,g_=function(e){return new y_().update(e).digest()},cu=Xr.Buffer,m_=yt,A1=j1,x_=new Array(16),Gi=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13],Yi=[5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11],Qi=[11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6],Xi=[8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11],Zi=[0,1518500249,1859775393,2400959708,2840853838],Ji=[1352829926,1548603684,1836072691,2053994217,0];function Fn(e,t){return e<<t|e>>>32-t}function Fh(e,t,r,n,i,o,a,s){return Fn(e+(t^r^n)+o+a|0,s)+i|0}function zh(e,t,r,n,i,o,a,s){return Fn(e+(t&r|~t&n)+o+a|0,s)+i|0}function $h(e,t,r,n,i,o,a,s){return Fn(e+((t|~r)^n)+o+a|0,s)+i|0}function Hh(e,t,r,n,i,o,a,s){return Fn(e+(t&n|r&~n)+o+a|0,s)+i|0}function Wh(e,t,r,n,i,o,a,s){return Fn(e+(t^(r|~n))+o+a|0,s)+i|0}function Gl(){A1.call(this,64),this._a=1732584193,this._b=4023233417,this._c=2562383102,this._d=271733878,this._e=3285377520}m_(Gl,A1);Gl.prototype._update=function(){for(var e=x_,t=0;t<16;++t)e[t]=this._block.readInt32LE(t*4);for(var r=this._a|0,n=this._b|0,i=this._c|0,o=this._d|0,a=this._e|0,s=this._a|0,u=this._b|0,d=this._c|0,_=this._d|0,m=this._e|0,E=0;E<80;E+=1){var B,R;E<16?(B=Fh(r,n,i,o,a,e[Gi[E]],Zi[0],Qi[E]),R=Wh(s,u,d,_,m,e[Yi[E]],Ji[0],Xi[E])):E<32?(B=zh(r,n,i,o,a,e[Gi[E]],Zi[1],Qi[E]),R=Hh(s,u,d,_,m,e[Yi[E]],Ji[1],Xi[E])):E<48?(B=$h(r,n,i,o,a,e[Gi[E]],Zi[2],Qi[E]),R=$h(s,u,d,_,m,e[Yi[E]],Ji[2],Xi[E])):E<64?(B=Hh(r,n,i,o,a,e[Gi[E]],Zi[3],Qi[E]),R=zh(s,u,d,_,m,e[Yi[E]],Ji[3],Xi[E])):(B=Wh(r,n,i,o,a,e[Gi[E]],Zi[4],Qi[E]),R=Fh(s,u,d,_,m,e[Yi[E]],Ji[4],Xi[E])),r=a,a=o,o=Fn(i,10),i=n,n=B,s=m,m=_,_=Fn(d,10),d=u,u=R}var N=this._b+i+_|0;this._b=this._c+o+m|0,this._c=this._d+a+s|0,this._d=this._e+r+u|0,this._e=this._a+n+d|0,this._a=N};Gl.prototype._digest=function(){this._block[this._blockOffset]=128,this._blockOffset+=1,this._blockOffset>56&&(this._block.fill(0,this._blockOffset,64),this._update(),this._blockOffset=0),this._block.fill(0,this._blockOffset,56),this._block.writeUInt32LE(this._length[0],56),this._block.writeUInt32LE(this._length[1],60),this._update();var e=cu.alloc?cu.alloc(20):new cu(20);return e.writeInt32LE(this._a,0),e.writeInt32LE(this._b,4),e.writeInt32LE(this._c,8),e.writeInt32LE(this._d,12),e.writeInt32LE(this._e,16),e};var b_=Gl,N1={exports:{}},w_=Qt.Buffer,__=Ac;function Yl(e,t){this._block=w_.alloc(e),this._finalSize=t,this._blockSize=e,this._len=0}Yl.prototype.update=function(e,t){e=__(e,t||"utf8");for(var r=this._block,n=this._blockSize,i=e.length,o=this._len,a=0;a<i;){for(var s=o%n,u=Math.min(i-a,n-s),d=0;d<u;d++)r[s+d]=e[a+d];o+=u,a+=u,o%n===0&&this._update(r)}return this._len+=i,this};Yl.prototype.digest=function(e){var t=this._len%this._blockSize;this._block[t]=128,this._block.fill(0,t+1),t>=this._finalSize&&(this._update(this._block),this._block.fill(0));var r=this._len*8;if(r<=4294967295)this._block.writeUInt32BE(r,this._blockSize-4);else{var n=(r&4294967295)>>>0,i=(r-n)/4294967296;this._block.writeUInt32BE(i,this._blockSize-8),this._block.writeUInt32BE(n,this._blockSize-4)}this._update(this._block);var o=this._hash();return e?o.toString(e):o};Yl.prototype._update=function(){throw new Error("_update must be implemented by subclass")};var Pi=Yl,k_=yt,R1=Pi,S_=Qt.Buffer,E_=[1518500249,1859775393,-1894007588,-899497514],j_=new Array(80);function Qo(){this.init(),this._w=j_,R1.call(this,64,56)}k_(Qo,R1);Qo.prototype.init=function(){return this._a=1732584193,this._b=4023233417,this._c=2562383102,this._d=271733878,this._e=3285377520,this};function C_(e){return e<<5|e>>>27}function A_(e){return e<<30|e>>>2}function N_(e,t,r,n){return e===0?t&r|~t&n:e===2?t&r|t&n|r&n:t^r^n}Qo.prototype._update=function(e){for(var t=this._w,r=this._a|0,n=this._b|0,i=this._c|0,o=this._d|0,a=this._e|0,s=0;s<16;++s)t[s]=e.readInt32BE(s*4);for(;s<80;++s)t[s]=t[s-3]^t[s-8]^t[s-14]^t[s-16];for(var u=0;u<80;++u){var d=~~(u/20),_=C_(r)+N_(d,n,i,o)+a+t[u]+E_[d]|0;a=o,o=i,i=A_(n),n=r,r=_}this._a=r+this._a|0,this._b=n+this._b|0,this._c=i+this._c|0,this._d=o+this._d|0,this._e=a+this._e|0};Qo.prototype._hash=function(){var e=S_.allocUnsafe(20);return e.writeInt32BE(this._a|0,0),e.writeInt32BE(this._b|0,4),e.writeInt32BE(this._c|0,8),e.writeInt32BE(this._d|0,12),e.writeInt32BE(this._e|0,16),e};var R_=Qo,T_=yt,T1=Pi,L_=Qt.Buffer,B_=[1518500249,1859775393,-1894007588,-899497514],P_=new Array(80);function Xo(){this.init(),this._w=P_,T1.call(this,64,56)}T_(Xo,T1);Xo.prototype.init=function(){return this._a=1732584193,this._b=4023233417,this._c=2562383102,this._d=271733878,this._e=3285377520,this};function M_(e){return e<<1|e>>>31}function O_(e){return e<<5|e>>>27}function I_(e){return e<<30|e>>>2}function D_(e,t,r,n){return e===0?t&r|~t&n:e===2?t&r|t&n|r&n:t^r^n}Xo.prototype._update=function(e){for(var t=this._w,r=this._a|0,n=this._b|0,i=this._c|0,o=this._d|0,a=this._e|0,s=0;s<16;++s)t[s]=e.readInt32BE(s*4);for(;s<80;++s)t[s]=M_(t[s-3]^t[s-8]^t[s-14]^t[s-16]);for(var u=0;u<80;++u){var d=~~(u/20),_=O_(r)+D_(d,n,i,o)+a+t[u]+B_[d]|0;a=o,o=i,i=I_(n),n=r,r=_}this._a=r+this._a|0,this._b=n+this._b|0,this._c=i+this._c|0,this._d=o+this._d|0,this._e=a+this._e|0};Xo.prototype._hash=function(){var e=L_.allocUnsafe(20);return e.writeInt32BE(this._a|0,0),e.writeInt32BE(this._b|0,4),e.writeInt32BE(this._c|0,8),e.writeInt32BE(this._d|0,12),e.writeInt32BE(this._e|0,16),e};var U_=Xo,F_=yt,L1=Pi,z_=Qt.Buffer,$_=[1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298],H_=new Array(64);function Zo(){this.init(),this._w=H_,L1.call(this,64,56)}F_(Zo,L1);Zo.prototype.init=function(){return this._a=1779033703,this._b=3144134277,this._c=1013904242,this._d=2773480762,this._e=1359893119,this._f=2600822924,this._g=528734635,this._h=1541459225,this};function W_(e,t,r){return r^e&(t^r)}function V_(e,t,r){return e&t|r&(e|t)}function K_(e){return(e>>>2|e<<30)^(e>>>13|e<<19)^(e>>>22|e<<10)}function q_(e){return(e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7)}function G_(e){return(e>>>7|e<<25)^(e>>>18|e<<14)^e>>>3}function Y_(e){return(e>>>17|e<<15)^(e>>>19|e<<13)^e>>>10}Zo.prototype._update=function(e){for(var t=this._w,r=this._a|0,n=this._b|0,i=this._c|0,o=this._d|0,a=this._e|0,s=this._f|0,u=this._g|0,d=this._h|0,_=0;_<16;++_)t[_]=e.readInt32BE(_*4);for(;_<64;++_)t[_]=Y_(t[_-2])+t[_-7]+G_(t[_-15])+t[_-16]|0;for(var m=0;m<64;++m){var E=d+q_(a)+W_(a,s,u)+$_[m]+t[m]|0,B=K_(r)+V_(r,n,i)|0;d=u,u=s,s=a,a=o+E|0,o=i,i=n,n=r,r=E+B|0}this._a=r+this._a|0,this._b=n+this._b|0,this._c=i+this._c|0,this._d=o+this._d|0,this._e=a+this._e|0,this._f=s+this._f|0,this._g=u+this._g|0,this._h=d+this._h|0};Zo.prototype._hash=function(){var e=z_.allocUnsafe(32);return e.writeInt32BE(this._a,0),e.writeInt32BE(this._b,4),e.writeInt32BE(this._c,8),e.writeInt32BE(this._d,12),e.writeInt32BE(this._e,16),e.writeInt32BE(this._f,20),e.writeInt32BE(this._g,24),e.writeInt32BE(this._h,28),e};var B1=Zo,Q_=yt,X_=B1,Z_=Pi,J_=Qt.Buffer,e6=new Array(64);function Ql(){this.init(),this._w=e6,Z_.call(this,64,56)}Q_(Ql,X_);Ql.prototype.init=function(){return this._a=3238371032,this._b=914150663,this._c=812702999,this._d=4144912697,this._e=4290775857,this._f=1750603025,this._g=1694076839,this._h=3204075428,this};Ql.prototype._hash=function(){var e=J_.allocUnsafe(28);return e.writeInt32BE(this._a,0),e.writeInt32BE(this._b,4),e.writeInt32BE(this._c,8),e.writeInt32BE(this._d,12),e.writeInt32BE(this._e,16),e.writeInt32BE(this._f,20),e.writeInt32BE(this._g,24),e};var t6=Ql,r6=yt,P1=Pi,n6=Qt.Buffer,Vh=[1116352408,3609767458,1899447441,602891725,3049323471,3964484399,3921009573,2173295548,961987163,4081628472,1508970993,3053834265,2453635748,2937671579,2870763221,3664609560,3624381080,2734883394,310598401,1164996542,607225278,1323610764,1426881987,3590304994,1925078388,4068182383,2162078206,991336113,2614888103,633803317,3248222580,3479774868,3835390401,2666613458,4022224774,944711139,264347078,2341262773,604807628,2007800933,770255983,1495990901,1249150122,1856431235,1555081692,3175218132,1996064986,2198950837,2554220882,3999719339,2821834349,766784016,2952996808,2566594879,3210313671,3203337956,3336571891,1034457026,3584528711,2466948901,113926993,3758326383,338241895,168717936,666307205,1188179964,773529912,1546045734,1294757372,1522805485,1396182291,2643833823,1695183700,2343527390,1986661051,1014477480,2177026350,1206759142,2456956037,344077627,2730485921,1290863460,2820302411,3158454273,3259730800,3505952657,3345764771,106217008,3516065817,3606008344,3600352804,1432725776,4094571909,1467031594,275423344,851169720,430227734,3100823752,506948616,1363258195,659060556,3750685593,883997877,3785050280,958139571,3318307427,1322822218,3812723403,1537002063,2003034995,1747873779,3602036899,1955562222,1575990012,2024104815,1125592928,2227730452,2716904306,2361852424,442776044,2428436474,593698344,2756734187,3733110249,3204031479,2999351573,3329325298,3815920427,3391569614,3928383900,3515267271,566280711,3940187606,3454069534,4118630271,4000239992,116418474,1914138554,174292421,2731055270,289380356,3203993006,460393269,320620315,685471733,587496836,852142971,1086792851,1017036298,365543100,1126000580,2618297676,1288033470,3409855158,1501505948,4234509866,1607167915,987167468,1816402316,1246189591],i6=new Array(160);function Jo(){this.init(),this._w=i6,P1.call(this,128,112)}r6(Jo,P1);Jo.prototype.init=function(){return this._ah=1779033703,this._bh=3144134277,this._ch=1013904242,this._dh=2773480762,this._eh=1359893119,this._fh=2600822924,this._gh=528734635,this._hh=1541459225,this._al=4089235720,this._bl=2227873595,this._cl=4271175723,this._dl=1595750129,this._el=2917565137,this._fl=725511199,this._gl=4215389547,this._hl=327033209,this};function Kh(e,t,r){return r^e&(t^r)}function qh(e,t,r){return e&t|r&(e|t)}function Gh(e,t){return(e>>>28|t<<4)^(t>>>2|e<<30)^(t>>>7|e<<25)}function Yh(e,t){return(e>>>14|t<<18)^(e>>>18|t<<14)^(t>>>9|e<<23)}function o6(e,t){return(e>>>1|t<<31)^(e>>>8|t<<24)^e>>>7}function a6(e,t){return(e>>>1|t<<31)^(e>>>8|t<<24)^(e>>>7|t<<25)}function l6(e,t){return(e>>>19|t<<13)^(t>>>29|e<<3)^e>>>6}function s6(e,t){return(e>>>19|t<<13)^(t>>>29|e<<3)^(e>>>6|t<<26)}function Et(e,t){return e>>>0<t>>>0?1:0}Jo.prototype._update=function(e){for(var t=this._w,r=this._ah|0,n=this._bh|0,i=this._ch|0,o=this._dh|0,a=this._eh|0,s=this._fh|0,u=this._gh|0,d=this._hh|0,_=this._al|0,m=this._bl|0,E=this._cl|0,B=this._dl|0,R=this._el|0,N=this._fl|0,P=this._gl|0,p=this._hl|0,v=0;v<32;v+=2)t[v]=e.readInt32BE(v*4),t[v+1]=e.readInt32BE(v*4+4);for(;v<160;v+=2){var x=t[v-30],C=t[v-15*2+1],O=o6(x,C),H=a6(C,x);x=t[v-2*2],C=t[v-2*2+1];var Q=l6(x,C),V=s6(C,x),X=t[v-7*2],pe=t[v-7*2+1],De=t[v-16*2],$e=t[v-16*2+1],_e=H+pe|0,He=O+X+Et(_e,H)|0;_e=_e+V|0,He=He+Q+Et(_e,V)|0,_e=_e+$e|0,He=He+De+Et(_e,$e)|0,t[v]=He,t[v+1]=_e}for(var nt=0;nt<160;nt+=2){He=t[nt],_e=t[nt+1];var tt=qh(r,n,i),I=qh(_,m,E),A=Gh(r,_),D=Gh(_,r),J=Yh(a,R),le=Yh(R,a),de=Vh[nt],Ne=Vh[nt+1],Re=Kh(a,s,u),ge=Kh(R,N,P),T=p+le|0,h=d+J+Et(T,p)|0;T=T+ge|0,h=h+Re+Et(T,ge)|0,T=T+Ne|0,h=h+de+Et(T,Ne)|0,T=T+_e|0,h=h+He+Et(T,_e)|0;var b=D+I|0,F=A+tt+Et(b,D)|0;d=u,p=P,u=s,P=N,s=a,N=R,R=B+T|0,a=o+h+Et(R,B)|0,o=i,B=E,i=n,E=m,n=r,m=_,_=T+b|0,r=h+F+Et(_,T)|0}this._al=this._al+_|0,this._bl=this._bl+m|0,this._cl=this._cl+E|0,this._dl=this._dl+B|0,this._el=this._el+R|0,this._fl=this._fl+N|0,this._gl=this._gl+P|0,this._hl=this._hl+p|0,this._ah=this._ah+r+Et(this._al,_)|0,this._bh=this._bh+n+Et(this._bl,m)|0,this._ch=this._ch+i+Et(this._cl,E)|0,this._dh=this._dh+o+Et(this._dl,B)|0,this._eh=this._eh+a+Et(this._el,R)|0,this._fh=this._fh+s+Et(this._fl,N)|0,this._gh=this._gh+u+Et(this._gl,P)|0,this._hh=this._hh+d+Et(this._hl,p)|0};Jo.prototype._hash=function(){var e=n6.allocUnsafe(64);function t(r,n,i){e.writeInt32BE(r,i),e.writeInt32BE(n,i+4)}return t(this._ah,this._al,0),t(this._bh,this._bl,8),t(this._ch,this._cl,16),t(this._dh,this._dl,24),t(this._eh,this._el,32),t(this._fh,this._fl,40),t(this._gh,this._gl,48),t(this._hh,this._hl,56),e};var M1=Jo,u6=yt,f6=M1,c6=Pi,d6=Qt.Buffer,h6=new Array(160);function Xl(){this.init(),this._w=h6,c6.call(this,128,112)}u6(Xl,f6);Xl.prototype.init=function(){return this._ah=3418070365,this._bh=1654270250,this._ch=2438529370,this._dh=355462360,this._eh=1731405415,this._fh=2394180231,this._gh=3675008525,this._hh=1203062813,this._al=3238371032,this._bl=914150663,this._cl=812702999,this._dl=4144912697,this._el=4290775857,this._fl=1750603025,this._gl=1694076839,this._hl=3204075428,this};Xl.prototype._hash=function(){var e=d6.allocUnsafe(48);function t(r,n,i){e.writeInt32BE(r,i),e.writeInt32BE(n,i+4)}return t(this._ah,this._al,0),t(this._bh,this._bl,8),t(this._ch,this._cl,16),t(this._dh,this._dl,24),t(this._eh,this._el,32),t(this._fh,this._fl,40),e};var p6=Xl;(function(e){e.exports=function(r){var n=r.toLowerCase(),i=e.exports[n];if(!i)throw new Error(n+" is not supported (we accept pull requests)");return new i},e.exports.sha=R_,e.exports.sha1=U_,e.exports.sha224=t6,e.exports.sha256=B1,e.exports.sha384=p6,e.exports.sha512=M1})(N1);var v6=N1.exports,y6=yt,g6=Bw,O1=p1,oo=Qt.Buffer,m6=g_,_f=b_,kf=v6,x6=oo.alloc(128);function Io(e,t){O1.call(this,"digest"),typeof t=="string"&&(t=oo.from(t));var r=e==="sha512"||e==="sha384"?128:64;if(this._alg=e,this._key=t,t.length>r){var n=e==="rmd160"?new _f:kf(e);t=n.update(t).digest()}else t.length<r&&(t=oo.concat([t,x6],r));for(var i=this._ipad=oo.allocUnsafe(r),o=this._opad=oo.allocUnsafe(r),a=0;a<r;a++)i[a]=t[a]^54,o[a]=t[a]^92;this._hash=e==="rmd160"?new _f:kf(e),this._hash.update(i)}y6(Io,O1);Io.prototype._update=function(e){this._hash.update(e)};Io.prototype._final=function(){var e=this._hash.digest(),t=this._alg==="rmd160"?new _f:kf(this._alg);return t.update(this._opad).update(e).digest()};var b6=function(t,r){return t=t.toLowerCase(),t==="rmd160"||t==="ripemd160"?new Io("rmd160",r):t==="md5"?new g6(m6,r):new Io(t,r)};function w6(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var I1={exports:{}};(function(e){(function(t){var r=function(c){var g,y=new Float64Array(16);if(c)for(g=0;g<c.length;g++)y[g]=c[g];return y},n=function(){throw new Error("no PRNG")},i=new Uint8Array(16),o=new Uint8Array(32);o[0]=9;var a=r(),s=r([1]),u=r([56129,1]),d=r([30883,4953,19914,30187,55467,16705,2637,112,59544,30585,16505,36039,65139,11119,27886,20995]),_=r([61785,9906,39828,60374,45398,33411,5274,224,53552,61171,33010,6542,64743,22239,55772,9222]),m=r([54554,36645,11616,51542,42930,38181,51040,26924,56412,64982,57905,49316,21502,52590,14035,8553]),E=r([26200,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214,26214]),B=r([41136,18958,6951,50414,58488,44335,6150,12099,55207,15867,153,11085,57099,20417,9344,11139]);function R(c,g,y,l){c[g]=y>>24&255,c[g+1]=y>>16&255,c[g+2]=y>>8&255,c[g+3]=y&255,c[g+4]=l>>24&255,c[g+5]=l>>16&255,c[g+6]=l>>8&255,c[g+7]=l&255}function N(c,g,y,l,w){var L,M=0;for(L=0;L<w;L++)M|=c[g+L]^y[l+L];return(1&M-1>>>8)-1}function P(c,g,y,l){return N(c,g,y,l,16)}function p(c,g,y,l){return N(c,g,y,l,32)}function v(c,g,y,l){for(var w=l[0]&255|(l[1]&255)<<8|(l[2]&255)<<16|(l[3]&255)<<24,L=y[0]&255|(y[1]&255)<<8|(y[2]&255)<<16|(y[3]&255)<<24,M=y[4]&255|(y[5]&255)<<8|(y[6]&255)<<16|(y[7]&255)<<24,G=y[8]&255|(y[9]&255)<<8|(y[10]&255)<<16|(y[11]&255)<<24,re=y[12]&255|(y[13]&255)<<8|(y[14]&255)<<16|(y[15]&255)<<24,ye=l[4]&255|(l[5]&255)<<8|(l[6]&255)<<16|(l[7]&255)<<24,ae=g[0]&255|(g[1]&255)<<8|(g[2]&255)<<16|(g[3]&255)<<24,qe=g[4]&255|(g[5]&255)<<8|(g[6]&255)<<16|(g[7]&255)<<24,ue=g[8]&255|(g[9]&255)<<8|(g[10]&255)<<16|(g[11]&255)<<24,we=g[12]&255|(g[13]&255)<<8|(g[14]&255)<<16|(g[15]&255)<<24,ke=l[8]&255|(l[9]&255)<<8|(l[10]&255)<<16|(l[11]&255)<<24,Te=y[16]&255|(y[17]&255)<<8|(y[18]&255)<<16|(y[19]&255)<<24,Ae=y[20]&255|(y[21]&255)<<8|(y[22]&255)<<16|(y[23]&255)<<24,Se=y[24]&255|(y[25]&255)<<8|(y[26]&255)<<16|(y[27]&255)<<24,je=y[28]&255|(y[29]&255)<<8|(y[30]&255)<<16|(y[31]&255)<<24,Ee=l[12]&255|(l[13]&255)<<8|(l[14]&255)<<16|(l[15]&255)<<24,ce=w,me=L,se=M,he=G,ve=re,oe=ye,z=ae,$=qe,Z=ue,q=we,Y=ke,ee=Te,be=Ae,Le=Se,Pe=je,Be=Ee,j,Ie=0;Ie<20;Ie+=2)j=ce+be|0,ve^=j<<7|j>>>25,j=ve+ce|0,Z^=j<<9|j>>>23,j=Z+ve|0,be^=j<<13|j>>>19,j=be+Z|0,ce^=j<<18|j>>>14,j=oe+me|0,q^=j<<7|j>>>25,j=q+oe|0,Le^=j<<9|j>>>23,j=Le+q|0,me^=j<<13|j>>>19,j=me+Le|0,oe^=j<<18|j>>>14,j=Y+z|0,Pe^=j<<7|j>>>25,j=Pe+Y|0,se^=j<<9|j>>>23,j=se+Pe|0,z^=j<<13|j>>>19,j=z+se|0,Y^=j<<18|j>>>14,j=Be+ee|0,he^=j<<7|j>>>25,j=he+Be|0,$^=j<<9|j>>>23,j=$+he|0,ee^=j<<13|j>>>19,j=ee+$|0,Be^=j<<18|j>>>14,j=ce+he|0,me^=j<<7|j>>>25,j=me+ce|0,se^=j<<9|j>>>23,j=se+me|0,he^=j<<13|j>>>19,j=he+se|0,ce^=j<<18|j>>>14,j=oe+ve|0,z^=j<<7|j>>>25,j=z+oe|0,$^=j<<9|j>>>23,j=$+z|0,ve^=j<<13|j>>>19,j=ve+$|0,oe^=j<<18|j>>>14,j=Y+q|0,ee^=j<<7|j>>>25,j=ee+Y|0,Z^=j<<9|j>>>23,j=Z+ee|0,q^=j<<13|j>>>19,j=q+Z|0,Y^=j<<18|j>>>14,j=Be+Pe|0,be^=j<<7|j>>>25,j=be+Be|0,Le^=j<<9|j>>>23,j=Le+be|0,Pe^=j<<13|j>>>19,j=Pe+Le|0,Be^=j<<18|j>>>14;ce=ce+w|0,me=me+L|0,se=se+M|0,he=he+G|0,ve=ve+re|0,oe=oe+ye|0,z=z+ae|0,$=$+qe|0,Z=Z+ue|0,q=q+we|0,Y=Y+ke|0,ee=ee+Te|0,be=be+Ae|0,Le=Le+Se|0,Pe=Pe+je|0,Be=Be+Ee|0,c[0]=ce>>>0&255,c[1]=ce>>>8&255,c[2]=ce>>>16&255,c[3]=ce>>>24&255,c[4]=me>>>0&255,c[5]=me>>>8&255,c[6]=me>>>16&255,c[7]=me>>>24&255,c[8]=se>>>0&255,c[9]=se>>>8&255,c[10]=se>>>16&255,c[11]=se>>>24&255,c[12]=he>>>0&255,c[13]=he>>>8&255,c[14]=he>>>16&255,c[15]=he>>>24&255,c[16]=ve>>>0&255,c[17]=ve>>>8&255,c[18]=ve>>>16&255,c[19]=ve>>>24&255,c[20]=oe>>>0&255,c[21]=oe>>>8&255,c[22]=oe>>>16&255,c[23]=oe>>>24&255,c[24]=z>>>0&255,c[25]=z>>>8&255,c[26]=z>>>16&255,c[27]=z>>>24&255,c[28]=$>>>0&255,c[29]=$>>>8&255,c[30]=$>>>16&255,c[31]=$>>>24&255,c[32]=Z>>>0&255,c[33]=Z>>>8&255,c[34]=Z>>>16&255,c[35]=Z>>>24&255,c[36]=q>>>0&255,c[37]=q>>>8&255,c[38]=q>>>16&255,c[39]=q>>>24&255,c[40]=Y>>>0&255,c[41]=Y>>>8&255,c[42]=Y>>>16&255,c[43]=Y>>>24&255,c[44]=ee>>>0&255,c[45]=ee>>>8&255,c[46]=ee>>>16&255,c[47]=ee>>>24&255,c[48]=be>>>0&255,c[49]=be>>>8&255,c[50]=be>>>16&255,c[51]=be>>>24&255,c[52]=Le>>>0&255,c[53]=Le>>>8&255,c[54]=Le>>>16&255,c[55]=Le>>>24&255,c[56]=Pe>>>0&255,c[57]=Pe>>>8&255,c[58]=Pe>>>16&255,c[59]=Pe>>>24&255,c[60]=Be>>>0&255,c[61]=Be>>>8&255,c[62]=Be>>>16&255,c[63]=Be>>>24&255}function x(c,g,y,l){for(var w=l[0]&255|(l[1]&255)<<8|(l[2]&255)<<16|(l[3]&255)<<24,L=y[0]&255|(y[1]&255)<<8|(y[2]&255)<<16|(y[3]&255)<<24,M=y[4]&255|(y[5]&255)<<8|(y[6]&255)<<16|(y[7]&255)<<24,G=y[8]&255|(y[9]&255)<<8|(y[10]&255)<<16|(y[11]&255)<<24,re=y[12]&255|(y[13]&255)<<8|(y[14]&255)<<16|(y[15]&255)<<24,ye=l[4]&255|(l[5]&255)<<8|(l[6]&255)<<16|(l[7]&255)<<24,ae=g[0]&255|(g[1]&255)<<8|(g[2]&255)<<16|(g[3]&255)<<24,qe=g[4]&255|(g[5]&255)<<8|(g[6]&255)<<16|(g[7]&255)<<24,ue=g[8]&255|(g[9]&255)<<8|(g[10]&255)<<16|(g[11]&255)<<24,we=g[12]&255|(g[13]&255)<<8|(g[14]&255)<<16|(g[15]&255)<<24,ke=l[8]&255|(l[9]&255)<<8|(l[10]&255)<<16|(l[11]&255)<<24,Te=y[16]&255|(y[17]&255)<<8|(y[18]&255)<<16|(y[19]&255)<<24,Ae=y[20]&255|(y[21]&255)<<8|(y[22]&255)<<16|(y[23]&255)<<24,Se=y[24]&255|(y[25]&255)<<8|(y[26]&255)<<16|(y[27]&255)<<24,je=y[28]&255|(y[29]&255)<<8|(y[30]&255)<<16|(y[31]&255)<<24,Ee=l[12]&255|(l[13]&255)<<8|(l[14]&255)<<16|(l[15]&255)<<24,ce=w,me=L,se=M,he=G,ve=re,oe=ye,z=ae,$=qe,Z=ue,q=we,Y=ke,ee=Te,be=Ae,Le=Se,Pe=je,Be=Ee,j,Ie=0;Ie<20;Ie+=2)j=ce+be|0,ve^=j<<7|j>>>25,j=ve+ce|0,Z^=j<<9|j>>>23,j=Z+ve|0,be^=j<<13|j>>>19,j=be+Z|0,ce^=j<<18|j>>>14,j=oe+me|0,q^=j<<7|j>>>25,j=q+oe|0,Le^=j<<9|j>>>23,j=Le+q|0,me^=j<<13|j>>>19,j=me+Le|0,oe^=j<<18|j>>>14,j=Y+z|0,Pe^=j<<7|j>>>25,j=Pe+Y|0,se^=j<<9|j>>>23,j=se+Pe|0,z^=j<<13|j>>>19,j=z+se|0,Y^=j<<18|j>>>14,j=Be+ee|0,he^=j<<7|j>>>25,j=he+Be|0,$^=j<<9|j>>>23,j=$+he|0,ee^=j<<13|j>>>19,j=ee+$|0,Be^=j<<18|j>>>14,j=ce+he|0,me^=j<<7|j>>>25,j=me+ce|0,se^=j<<9|j>>>23,j=se+me|0,he^=j<<13|j>>>19,j=he+se|0,ce^=j<<18|j>>>14,j=oe+ve|0,z^=j<<7|j>>>25,j=z+oe|0,$^=j<<9|j>>>23,j=$+z|0,ve^=j<<13|j>>>19,j=ve+$|0,oe^=j<<18|j>>>14,j=Y+q|0,ee^=j<<7|j>>>25,j=ee+Y|0,Z^=j<<9|j>>>23,j=Z+ee|0,q^=j<<13|j>>>19,j=q+Z|0,Y^=j<<18|j>>>14,j=Be+Pe|0,be^=j<<7|j>>>25,j=be+Be|0,Le^=j<<9|j>>>23,j=Le+be|0,Pe^=j<<13|j>>>19,j=Pe+Le|0,Be^=j<<18|j>>>14;c[0]=ce>>>0&255,c[1]=ce>>>8&255,c[2]=ce>>>16&255,c[3]=ce>>>24&255,c[4]=oe>>>0&255,c[5]=oe>>>8&255,c[6]=oe>>>16&255,c[7]=oe>>>24&255,c[8]=Y>>>0&255,c[9]=Y>>>8&255,c[10]=Y>>>16&255,c[11]=Y>>>24&255,c[12]=Be>>>0&255,c[13]=Be>>>8&255,c[14]=Be>>>16&255,c[15]=Be>>>24&255,c[16]=z>>>0&255,c[17]=z>>>8&255,c[18]=z>>>16&255,c[19]=z>>>24&255,c[20]=$>>>0&255,c[21]=$>>>8&255,c[22]=$>>>16&255,c[23]=$>>>24&255,c[24]=Z>>>0&255,c[25]=Z>>>8&255,c[26]=Z>>>16&255,c[27]=Z>>>24&255,c[28]=q>>>0&255,c[29]=q>>>8&255,c[30]=q>>>16&255,c[31]=q>>>24&255}function C(c,g,y,l){v(c,g,y,l)}function O(c,g,y,l){x(c,g,y,l)}var H=new Uint8Array([101,120,112,97,110,100,32,51,50,45,98,121,116,101,32,107]);function Q(c,g,y,l,w,L,M){var G=new Uint8Array(16),re=new Uint8Array(64),ye,ae;for(ae=0;ae<16;ae++)G[ae]=0;for(ae=0;ae<8;ae++)G[ae]=L[ae];for(;w>=64;){for(C(re,G,M,H),ae=0;ae<64;ae++)c[g+ae]=y[l+ae]^re[ae];for(ye=1,ae=8;ae<16;ae++)ye=ye+(G[ae]&255)|0,G[ae]=ye&255,ye>>>=8;w-=64,g+=64,l+=64}if(w>0)for(C(re,G,M,H),ae=0;ae<w;ae++)c[g+ae]=y[l+ae]^re[ae];return 0}function V(c,g,y,l,w){var L=new Uint8Array(16),M=new Uint8Array(64),G,re;for(re=0;re<16;re++)L[re]=0;for(re=0;re<8;re++)L[re]=l[re];for(;y>=64;){for(C(M,L,w,H),re=0;re<64;re++)c[g+re]=M[re];for(G=1,re=8;re<16;re++)G=G+(L[re]&255)|0,L[re]=G&255,G>>>=8;y-=64,g+=64}if(y>0)for(C(M,L,w,H),re=0;re<y;re++)c[g+re]=M[re];return 0}function X(c,g,y,l,w){var L=new Uint8Array(32);O(L,l,w,H);for(var M=new Uint8Array(8),G=0;G<8;G++)M[G]=l[G+16];return V(c,g,y,M,L)}function pe(c,g,y,l,w,L,M){var G=new Uint8Array(32);O(G,L,M,H);for(var re=new Uint8Array(8),ye=0;ye<8;ye++)re[ye]=L[ye+16];return Q(c,g,y,l,w,re,G)}var De=function(c){this.buffer=new Uint8Array(16),this.r=new Uint16Array(10),this.h=new Uint16Array(10),this.pad=new Uint16Array(8),this.leftover=0,this.fin=0;var g,y,l,w,L,M,G,re;g=c[0]&255|(c[1]&255)<<8,this.r[0]=g&8191,y=c[2]&255|(c[3]&255)<<8,this.r[1]=(g>>>13|y<<3)&8191,l=c[4]&255|(c[5]&255)<<8,this.r[2]=(y>>>10|l<<6)&7939,w=c[6]&255|(c[7]&255)<<8,this.r[3]=(l>>>7|w<<9)&8191,L=c[8]&255|(c[9]&255)<<8,this.r[4]=(w>>>4|L<<12)&255,this.r[5]=L>>>1&8190,M=c[10]&255|(c[11]&255)<<8,this.r[6]=(L>>>14|M<<2)&8191,G=c[12]&255|(c[13]&255)<<8,this.r[7]=(M>>>11|G<<5)&8065,re=c[14]&255|(c[15]&255)<<8,this.r[8]=(G>>>8|re<<8)&8191,this.r[9]=re>>>5&127,this.pad[0]=c[16]&255|(c[17]&255)<<8,this.pad[1]=c[18]&255|(c[19]&255)<<8,this.pad[2]=c[20]&255|(c[21]&255)<<8,this.pad[3]=c[22]&255|(c[23]&255)<<8,this.pad[4]=c[24]&255|(c[25]&255)<<8,this.pad[5]=c[26]&255|(c[27]&255)<<8,this.pad[6]=c[28]&255|(c[29]&255)<<8,this.pad[7]=c[30]&255|(c[31]&255)<<8};De.prototype.blocks=function(c,g,y){for(var l=this.fin?0:2048,w,L,M,G,re,ye,ae,qe,ue,we,ke,Te,Ae,Se,je,Ee,ce,me,se,he=this.h[0],ve=this.h[1],oe=this.h[2],z=this.h[3],$=this.h[4],Z=this.h[5],q=this.h[6],Y=this.h[7],ee=this.h[8],be=this.h[9],Le=this.r[0],Pe=this.r[1],Be=this.r[2],j=this.r[3],Ie=this.r[4],Ge=this.r[5],Ye=this.r[6],Me=this.r[7],We=this.r[8],Ve=this.r[9];y>=16;)w=c[g+0]&255|(c[g+1]&255)<<8,he+=w&8191,L=c[g+2]&255|(c[g+3]&255)<<8,ve+=(w>>>13|L<<3)&8191,M=c[g+4]&255|(c[g+5]&255)<<8,oe+=(L>>>10|M<<6)&8191,G=c[g+6]&255|(c[g+7]&255)<<8,z+=(M>>>7|G<<9)&8191,re=c[g+8]&255|(c[g+9]&255)<<8,$+=(G>>>4|re<<12)&8191,Z+=re>>>1&8191,ye=c[g+10]&255|(c[g+11]&255)<<8,q+=(re>>>14|ye<<2)&8191,ae=c[g+12]&255|(c[g+13]&255)<<8,Y+=(ye>>>11|ae<<5)&8191,qe=c[g+14]&255|(c[g+15]&255)<<8,ee+=(ae>>>8|qe<<8)&8191,be+=qe>>>5|l,ue=0,we=ue,we+=he*Le,we+=ve*(5*Ve),we+=oe*(5*We),we+=z*(5*Me),we+=$*(5*Ye),ue=we>>>13,we&=8191,we+=Z*(5*Ge),we+=q*(5*Ie),we+=Y*(5*j),we+=ee*(5*Be),we+=be*(5*Pe),ue+=we>>>13,we&=8191,ke=ue,ke+=he*Pe,ke+=ve*Le,ke+=oe*(5*Ve),ke+=z*(5*We),ke+=$*(5*Me),ue=ke>>>13,ke&=8191,ke+=Z*(5*Ye),ke+=q*(5*Ge),ke+=Y*(5*Ie),ke+=ee*(5*j),ke+=be*(5*Be),ue+=ke>>>13,ke&=8191,Te=ue,Te+=he*Be,Te+=ve*Pe,Te+=oe*Le,Te+=z*(5*Ve),Te+=$*(5*We),ue=Te>>>13,Te&=8191,Te+=Z*(5*Me),Te+=q*(5*Ye),Te+=Y*(5*Ge),Te+=ee*(5*Ie),Te+=be*(5*j),ue+=Te>>>13,Te&=8191,Ae=ue,Ae+=he*j,Ae+=ve*Be,Ae+=oe*Pe,Ae+=z*Le,Ae+=$*(5*Ve),ue=Ae>>>13,Ae&=8191,Ae+=Z*(5*We),Ae+=q*(5*Me),Ae+=Y*(5*Ye),Ae+=ee*(5*Ge),Ae+=be*(5*Ie),ue+=Ae>>>13,Ae&=8191,Se=ue,Se+=he*Ie,Se+=ve*j,Se+=oe*Be,Se+=z*Pe,Se+=$*Le,ue=Se>>>13,Se&=8191,Se+=Z*(5*Ve),Se+=q*(5*We),Se+=Y*(5*Me),Se+=ee*(5*Ye),Se+=be*(5*Ge),ue+=Se>>>13,Se&=8191,je=ue,je+=he*Ge,je+=ve*Ie,je+=oe*j,je+=z*Be,je+=$*Pe,ue=je>>>13,je&=8191,je+=Z*Le,je+=q*(5*Ve),je+=Y*(5*We),je+=ee*(5*Me),je+=be*(5*Ye),ue+=je>>>13,je&=8191,Ee=ue,Ee+=he*Ye,Ee+=ve*Ge,Ee+=oe*Ie,Ee+=z*j,Ee+=$*Be,ue=Ee>>>13,Ee&=8191,Ee+=Z*Pe,Ee+=q*Le,Ee+=Y*(5*Ve),Ee+=ee*(5*We),Ee+=be*(5*Me),ue+=Ee>>>13,Ee&=8191,ce=ue,ce+=he*Me,ce+=ve*Ye,ce+=oe*Ge,ce+=z*Ie,ce+=$*j,ue=ce>>>13,ce&=8191,ce+=Z*Be,ce+=q*Pe,ce+=Y*Le,ce+=ee*(5*Ve),ce+=be*(5*We),ue+=ce>>>13,ce&=8191,me=ue,me+=he*We,me+=ve*Me,me+=oe*Ye,me+=z*Ge,me+=$*Ie,ue=me>>>13,me&=8191,me+=Z*j,me+=q*Be,me+=Y*Pe,me+=ee*Le,me+=be*(5*Ve),ue+=me>>>13,me&=8191,se=ue,se+=he*Ve,se+=ve*We,se+=oe*Me,se+=z*Ye,se+=$*Ge,ue=se>>>13,se&=8191,se+=Z*Ie,se+=q*j,se+=Y*Be,se+=ee*Pe,se+=be*Le,ue+=se>>>13,se&=8191,ue=(ue<<2)+ue|0,ue=ue+we|0,we=ue&8191,ue=ue>>>13,ke+=ue,he=we,ve=ke,oe=Te,z=Ae,$=Se,Z=je,q=Ee,Y=ce,ee=me,be=se,g+=16,y-=16;this.h[0]=he,this.h[1]=ve,this.h[2]=oe,this.h[3]=z,this.h[4]=$,this.h[5]=Z,this.h[6]=q,this.h[7]=Y,this.h[8]=ee,this.h[9]=be},De.prototype.finish=function(c,g){var y=new Uint16Array(10),l,w,L,M;if(this.leftover){for(M=this.leftover,this.buffer[M++]=1;M<16;M++)this.buffer[M]=0;this.fin=1,this.blocks(this.buffer,0,16)}for(l=this.h[1]>>>13,this.h[1]&=8191,M=2;M<10;M++)this.h[M]+=l,l=this.h[M]>>>13,this.h[M]&=8191;for(this.h[0]+=l*5,l=this.h[0]>>>13,this.h[0]&=8191,this.h[1]+=l,l=this.h[1]>>>13,this.h[1]&=8191,this.h[2]+=l,y[0]=this.h[0]+5,l=y[0]>>>13,y[0]&=8191,M=1;M<10;M++)y[M]=this.h[M]+l,l=y[M]>>>13,y[M]&=8191;for(y[9]-=8192,w=(l^1)-1,M=0;M<10;M++)y[M]&=w;for(w=~w,M=0;M<10;M++)this.h[M]=this.h[M]&w|y[M];for(this.h[0]=(this.h[0]|this.h[1]<<13)&65535,this.h[1]=(this.h[1]>>>3|this.h[2]<<10)&65535,this.h[2]=(this.h[2]>>>6|this.h[3]<<7)&65535,this.h[3]=(this.h[3]>>>9|this.h[4]<<4)&65535,this.h[4]=(this.h[4]>>>12|this.h[5]<<1|this.h[6]<<14)&65535,this.h[5]=(this.h[6]>>>2|this.h[7]<<11)&65535,this.h[6]=(this.h[7]>>>5|this.h[8]<<8)&65535,this.h[7]=(this.h[8]>>>8|this.h[9]<<5)&65535,L=this.h[0]+this.pad[0],this.h[0]=L&65535,M=1;M<8;M++)L=(this.h[M]+this.pad[M]|0)+(L>>>16)|0,this.h[M]=L&65535;c[g+0]=this.h[0]>>>0&255,c[g+1]=this.h[0]>>>8&255,c[g+2]=this.h[1]>>>0&255,c[g+3]=this.h[1]>>>8&255,c[g+4]=this.h[2]>>>0&255,c[g+5]=this.h[2]>>>8&255,c[g+6]=this.h[3]>>>0&255,c[g+7]=this.h[3]>>>8&255,c[g+8]=this.h[4]>>>0&255,c[g+9]=this.h[4]>>>8&255,c[g+10]=this.h[5]>>>0&255,c[g+11]=this.h[5]>>>8&255,c[g+12]=this.h[6]>>>0&255,c[g+13]=this.h[6]>>>8&255,c[g+14]=this.h[7]>>>0&255,c[g+15]=this.h[7]>>>8&255},De.prototype.update=function(c,g,y){var l,w;if(this.leftover){for(w=16-this.leftover,w>y&&(w=y),l=0;l<w;l++)this.buffer[this.leftover+l]=c[g+l];if(y-=w,g+=w,this.leftover+=w,this.leftover<16)return;this.blocks(this.buffer,0,16),this.leftover=0}if(y>=16&&(w=y-y%16,this.blocks(c,g,w),g+=w,y-=w),y){for(l=0;l<y;l++)this.buffer[this.leftover+l]=c[g+l];this.leftover+=y}};function $e(c,g,y,l,w,L){var M=new De(L);return M.update(y,l,w),M.finish(c,g),0}function _e(c,g,y,l,w,L){var M=new Uint8Array(16);return $e(M,0,y,l,w,L),P(c,g,M,0)}function He(c,g,y,l,w){var L;if(y<32)return-1;for(pe(c,0,g,0,y,l,w),$e(c,16,c,32,y-32,c),L=0;L<16;L++)c[L]=0;return 0}function nt(c,g,y,l,w){var L,M=new Uint8Array(32);if(y<32||(X(M,0,32,l,w),_e(g,16,g,32,y-32,M)!==0))return-1;for(pe(c,0,g,0,y,l,w),L=0;L<32;L++)c[L]=0;return 0}function tt(c,g){var y;for(y=0;y<16;y++)c[y]=g[y]|0}function I(c){var g,y,l=1;for(g=0;g<16;g++)y=c[g]+l+65535,l=Math.floor(y/65536),c[g]=y-l*65536;c[0]+=l-1+37*(l-1)}function A(c,g,y){for(var l,w=~(y-1),L=0;L<16;L++)l=w&(c[L]^g[L]),c[L]^=l,g[L]^=l}function D(c,g){var y,l,w,L=r(),M=r();for(y=0;y<16;y++)M[y]=g[y];for(I(M),I(M),I(M),l=0;l<2;l++){for(L[0]=M[0]-65517,y=1;y<15;y++)L[y]=M[y]-65535-(L[y-1]>>16&1),L[y-1]&=65535;L[15]=M[15]-32767-(L[14]>>16&1),w=L[15]>>16&1,L[14]&=65535,A(M,L,1-w)}for(y=0;y<16;y++)c[2*y]=M[y]&255,c[2*y+1]=M[y]>>8}function J(c,g){var y=new Uint8Array(32),l=new Uint8Array(32);return D(y,c),D(l,g),p(y,0,l,0)}function le(c){var g=new Uint8Array(32);return D(g,c),g[0]&1}function de(c,g){var y;for(y=0;y<16;y++)c[y]=g[2*y]+(g[2*y+1]<<8);c[15]&=32767}function Ne(c,g,y){for(var l=0;l<16;l++)c[l]=g[l]+y[l]}function Re(c,g,y){for(var l=0;l<16;l++)c[l]=g[l]-y[l]}function ge(c,g,y){var l,w,L=0,M=0,G=0,re=0,ye=0,ae=0,qe=0,ue=0,we=0,ke=0,Te=0,Ae=0,Se=0,je=0,Ee=0,ce=0,me=0,se=0,he=0,ve=0,oe=0,z=0,$=0,Z=0,q=0,Y=0,ee=0,be=0,Le=0,Pe=0,Be=0,j=y[0],Ie=y[1],Ge=y[2],Ye=y[3],Me=y[4],We=y[5],Ve=y[6],mt=y[7],Je=y[8],ct=y[9],dt=y[10],ht=y[11],_t=y[12],Bt=y[13],Pt=y[14],Mt=y[15];l=g[0],L+=l*j,M+=l*Ie,G+=l*Ge,re+=l*Ye,ye+=l*Me,ae+=l*We,qe+=l*Ve,ue+=l*mt,we+=l*Je,ke+=l*ct,Te+=l*dt,Ae+=l*ht,Se+=l*_t,je+=l*Bt,Ee+=l*Pt,ce+=l*Mt,l=g[1],M+=l*j,G+=l*Ie,re+=l*Ge,ye+=l*Ye,ae+=l*Me,qe+=l*We,ue+=l*Ve,we+=l*mt,ke+=l*Je,Te+=l*ct,Ae+=l*dt,Se+=l*ht,je+=l*_t,Ee+=l*Bt,ce+=l*Pt,me+=l*Mt,l=g[2],G+=l*j,re+=l*Ie,ye+=l*Ge,ae+=l*Ye,qe+=l*Me,ue+=l*We,we+=l*Ve,ke+=l*mt,Te+=l*Je,Ae+=l*ct,Se+=l*dt,je+=l*ht,Ee+=l*_t,ce+=l*Bt,me+=l*Pt,se+=l*Mt,l=g[3],re+=l*j,ye+=l*Ie,ae+=l*Ge,qe+=l*Ye,ue+=l*Me,we+=l*We,ke+=l*Ve,Te+=l*mt,Ae+=l*Je,Se+=l*ct,je+=l*dt,Ee+=l*ht,ce+=l*_t,me+=l*Bt,se+=l*Pt,he+=l*Mt,l=g[4],ye+=l*j,ae+=l*Ie,qe+=l*Ge,ue+=l*Ye,we+=l*Me,ke+=l*We,Te+=l*Ve,Ae+=l*mt,Se+=l*Je,je+=l*ct,Ee+=l*dt,ce+=l*ht,me+=l*_t,se+=l*Bt,he+=l*Pt,ve+=l*Mt,l=g[5],ae+=l*j,qe+=l*Ie,ue+=l*Ge,we+=l*Ye,ke+=l*Me,Te+=l*We,Ae+=l*Ve,Se+=l*mt,je+=l*Je,Ee+=l*ct,ce+=l*dt,me+=l*ht,se+=l*_t,he+=l*Bt,ve+=l*Pt,oe+=l*Mt,l=g[6],qe+=l*j,ue+=l*Ie,we+=l*Ge,ke+=l*Ye,Te+=l*Me,Ae+=l*We,Se+=l*Ve,je+=l*mt,Ee+=l*Je,ce+=l*ct,me+=l*dt,se+=l*ht,he+=l*_t,ve+=l*Bt,oe+=l*Pt,z+=l*Mt,l=g[7],ue+=l*j,we+=l*Ie,ke+=l*Ge,Te+=l*Ye,Ae+=l*Me,Se+=l*We,je+=l*Ve,Ee+=l*mt,ce+=l*Je,me+=l*ct,se+=l*dt,he+=l*ht,ve+=l*_t,oe+=l*Bt,z+=l*Pt,$+=l*Mt,l=g[8],we+=l*j,ke+=l*Ie,Te+=l*Ge,Ae+=l*Ye,Se+=l*Me,je+=l*We,Ee+=l*Ve,ce+=l*mt,me+=l*Je,se+=l*ct,he+=l*dt,ve+=l*ht,oe+=l*_t,z+=l*Bt,$+=l*Pt,Z+=l*Mt,l=g[9],ke+=l*j,Te+=l*Ie,Ae+=l*Ge,Se+=l*Ye,je+=l*Me,Ee+=l*We,ce+=l*Ve,me+=l*mt,se+=l*Je,he+=l*ct,ve+=l*dt,oe+=l*ht,z+=l*_t,$+=l*Bt,Z+=l*Pt,q+=l*Mt,l=g[10],Te+=l*j,Ae+=l*Ie,Se+=l*Ge,je+=l*Ye,Ee+=l*Me,ce+=l*We,me+=l*Ve,se+=l*mt,he+=l*Je,ve+=l*ct,oe+=l*dt,z+=l*ht,$+=l*_t,Z+=l*Bt,q+=l*Pt,Y+=l*Mt,l=g[11],Ae+=l*j,Se+=l*Ie,je+=l*Ge,Ee+=l*Ye,ce+=l*Me,me+=l*We,se+=l*Ve,he+=l*mt,ve+=l*Je,oe+=l*ct,z+=l*dt,$+=l*ht,Z+=l*_t,q+=l*Bt,Y+=l*Pt,ee+=l*Mt,l=g[12],Se+=l*j,je+=l*Ie,Ee+=l*Ge,ce+=l*Ye,me+=l*Me,se+=l*We,he+=l*Ve,ve+=l*mt,oe+=l*Je,z+=l*ct,$+=l*dt,Z+=l*ht,q+=l*_t,Y+=l*Bt,ee+=l*Pt,be+=l*Mt,l=g[13],je+=l*j,Ee+=l*Ie,ce+=l*Ge,me+=l*Ye,se+=l*Me,he+=l*We,ve+=l*Ve,oe+=l*mt,z+=l*Je,$+=l*ct,Z+=l*dt,q+=l*ht,Y+=l*_t,ee+=l*Bt,be+=l*Pt,Le+=l*Mt,l=g[14],Ee+=l*j,ce+=l*Ie,me+=l*Ge,se+=l*Ye,he+=l*Me,ve+=l*We,oe+=l*Ve,z+=l*mt,$+=l*Je,Z+=l*ct,q+=l*dt,Y+=l*ht,ee+=l*_t,be+=l*Bt,Le+=l*Pt,Pe+=l*Mt,l=g[15],ce+=l*j,me+=l*Ie,se+=l*Ge,he+=l*Ye,ve+=l*Me,oe+=l*We,z+=l*Ve,$+=l*mt,Z+=l*Je,q+=l*ct,Y+=l*dt,ee+=l*ht,be+=l*_t,Le+=l*Bt,Pe+=l*Pt,Be+=l*Mt,L+=38*me,M+=38*se,G+=38*he,re+=38*ve,ye+=38*oe,ae+=38*z,qe+=38*$,ue+=38*Z,we+=38*q,ke+=38*Y,Te+=38*ee,Ae+=38*be,Se+=38*Le,je+=38*Pe,Ee+=38*Be,w=1,l=L+w+65535,w=Math.floor(l/65536),L=l-w*65536,l=M+w+65535,w=Math.floor(l/65536),M=l-w*65536,l=G+w+65535,w=Math.floor(l/65536),G=l-w*65536,l=re+w+65535,w=Math.floor(l/65536),re=l-w*65536,l=ye+w+65535,w=Math.floor(l/65536),ye=l-w*65536,l=ae+w+65535,w=Math.floor(l/65536),ae=l-w*65536,l=qe+w+65535,w=Math.floor(l/65536),qe=l-w*65536,l=ue+w+65535,w=Math.floor(l/65536),ue=l-w*65536,l=we+w+65535,w=Math.floor(l/65536),we=l-w*65536,l=ke+w+65535,w=Math.floor(l/65536),ke=l-w*65536,l=Te+w+65535,w=Math.floor(l/65536),Te=l-w*65536,l=Ae+w+65535,w=Math.floor(l/65536),Ae=l-w*65536,l=Se+w+65535,w=Math.floor(l/65536),Se=l-w*65536,l=je+w+65535,w=Math.floor(l/65536),je=l-w*65536,l=Ee+w+65535,w=Math.floor(l/65536),Ee=l-w*65536,l=ce+w+65535,w=Math.floor(l/65536),ce=l-w*65536,L+=w-1+37*(w-1),w=1,l=L+w+65535,w=Math.floor(l/65536),L=l-w*65536,l=M+w+65535,w=Math.floor(l/65536),M=l-w*65536,l=G+w+65535,w=Math.floor(l/65536),G=l-w*65536,l=re+w+65535,w=Math.floor(l/65536),re=l-w*65536,l=ye+w+65535,w=Math.floor(l/65536),ye=l-w*65536,l=ae+w+65535,w=Math.floor(l/65536),ae=l-w*65536,l=qe+w+65535,w=Math.floor(l/65536),qe=l-w*65536,l=ue+w+65535,w=Math.floor(l/65536),ue=l-w*65536,l=we+w+65535,w=Math.floor(l/65536),we=l-w*65536,l=ke+w+65535,w=Math.floor(l/65536),ke=l-w*65536,l=Te+w+65535,w=Math.floor(l/65536),Te=l-w*65536,l=Ae+w+65535,w=Math.floor(l/65536),Ae=l-w*65536,l=Se+w+65535,w=Math.floor(l/65536),Se=l-w*65536,l=je+w+65535,w=Math.floor(l/65536),je=l-w*65536,l=Ee+w+65535,w=Math.floor(l/65536),Ee=l-w*65536,l=ce+w+65535,w=Math.floor(l/65536),ce=l-w*65536,L+=w-1+37*(w-1),c[0]=L,c[1]=M,c[2]=G,c[3]=re,c[4]=ye,c[5]=ae,c[6]=qe,c[7]=ue,c[8]=we,c[9]=ke,c[10]=Te,c[11]=Ae,c[12]=Se,c[13]=je,c[14]=Ee,c[15]=ce}function T(c,g){ge(c,g,g)}function h(c,g){var y=r(),l;for(l=0;l<16;l++)y[l]=g[l];for(l=253;l>=0;l--)T(y,y),l!==2&&l!==4&&ge(y,y,g);for(l=0;l<16;l++)c[l]=y[l]}function b(c,g){var y=r(),l;for(l=0;l<16;l++)y[l]=g[l];for(l=250;l>=0;l--)T(y,y),l!==1&&ge(y,y,g);for(l=0;l<16;l++)c[l]=y[l]}function F(c,g,y){var l=new Uint8Array(32),w=new Float64Array(80),L,M,G=r(),re=r(),ye=r(),ae=r(),qe=r(),ue=r();for(M=0;M<31;M++)l[M]=g[M];for(l[31]=g[31]&127|64,l[0]&=248,de(w,y),M=0;M<16;M++)re[M]=w[M],ae[M]=G[M]=ye[M]=0;for(G[0]=ae[0]=1,M=254;M>=0;--M)L=l[M>>>3]>>>(M&7)&1,A(G,re,L),A(ye,ae,L),Ne(qe,G,ye),Re(G,G,ye),Ne(ye,re,ae),Re(re,re,ae),T(ae,qe),T(ue,G),ge(G,ye,G),ge(ye,re,qe),Ne(qe,G,ye),Re(G,G,ye),T(re,G),Re(ye,ae,ue),ge(G,ye,u),Ne(G,G,ae),ge(ye,ye,G),ge(G,ae,ue),ge(ae,re,w),T(re,qe),A(G,re,L),A(ye,ae,L);for(M=0;M<16;M++)w[M+16]=G[M],w[M+32]=ye[M],w[M+48]=re[M],w[M+64]=ae[M];var we=w.subarray(32),ke=w.subarray(16);return h(we,we),ge(ke,ke,we),D(c,ke),0}function K(c,g){return F(c,g,o)}function S(c,g){return n(g,32),K(c,g)}function k(c,g,y){var l=new Uint8Array(32);return F(l,y,g),O(c,i,l,H)}var U=He,ie=nt;function Xe(c,g,y,l,w,L){var M=new Uint8Array(32);return k(M,w,L),U(c,g,y,l,M)}function Ce(c,g,y,l,w,L){var M=new Uint8Array(32);return k(M,w,L),ie(c,g,y,l,M)}var Ke=[1116352408,3609767458,1899447441,602891725,3049323471,3964484399,3921009573,2173295548,961987163,4081628472,1508970993,3053834265,2453635748,2937671579,2870763221,3664609560,3624381080,2734883394,310598401,1164996542,607225278,1323610764,1426881987,3590304994,1925078388,4068182383,2162078206,991336113,2614888103,633803317,3248222580,3479774868,3835390401,2666613458,4022224774,944711139,264347078,2341262773,604807628,2007800933,770255983,1495990901,1249150122,1856431235,1555081692,3175218132,1996064986,2198950837,2554220882,3999719339,2821834349,766784016,2952996808,2566594879,3210313671,3203337956,3336571891,1034457026,3584528711,2466948901,113926993,3758326383,338241895,168717936,666307205,1188179964,773529912,1546045734,1294757372,1522805485,1396182291,2643833823,1695183700,2343527390,1986661051,1014477480,2177026350,1206759142,2456956037,344077627,2730485921,1290863460,2820302411,3158454273,3259730800,3505952657,3345764771,106217008,3516065817,3606008344,3600352804,1432725776,4094571909,1467031594,275423344,851169720,430227734,3100823752,506948616,1363258195,659060556,3750685593,883997877,3785050280,958139571,3318307427,1322822218,3812723403,1537002063,2003034995,1747873779,3602036899,1955562222,1575990012,2024104815,1125592928,2227730452,2716904306,2361852424,442776044,2428436474,593698344,2756734187,3733110249,3204031479,2999351573,3329325298,3815920427,3391569614,3928383900,3515267271,566280711,3940187606,3454069534,4118630271,4000239992,116418474,1914138554,174292421,2731055270,289380356,3203993006,460393269,320620315,685471733,587496836,852142971,1086792851,1017036298,365543100,1126000580,2618297676,1288033470,3409855158,1501505948,4234509866,1607167915,987167468,1816402316,1246189591];function Wt(c,g,y,l){for(var w=new Int32Array(16),L=new Int32Array(16),M,G,re,ye,ae,qe,ue,we,ke,Te,Ae,Se,je,Ee,ce,me,se,he,ve,oe,z,$,Z,q,Y,ee,be=c[0],Le=c[1],Pe=c[2],Be=c[3],j=c[4],Ie=c[5],Ge=c[6],Ye=c[7],Me=g[0],We=g[1],Ve=g[2],mt=g[3],Je=g[4],ct=g[5],dt=g[6],ht=g[7],_t=0;l>=128;){for(ve=0;ve<16;ve++)oe=8*ve+_t,w[ve]=y[oe+0]<<24|y[oe+1]<<16|y[oe+2]<<8|y[oe+3],L[ve]=y[oe+4]<<24|y[oe+5]<<16|y[oe+6]<<8|y[oe+7];for(ve=0;ve<80;ve++)if(M=be,G=Le,re=Pe,ye=Be,ae=j,qe=Ie,ue=Ge,we=Ye,ke=Me,Te=We,Ae=Ve,Se=mt,je=Je,Ee=ct,ce=dt,me=ht,z=Ye,$=ht,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=(j>>>14|Je<<18)^(j>>>18|Je<<14)^(Je>>>9|j<<23),$=(Je>>>14|j<<18)^(Je>>>18|j<<14)^(j>>>9|Je<<23),Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,z=j&Ie^~j&Ge,$=Je&ct^~Je&dt,Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,z=Ke[ve*2],$=Ke[ve*2+1],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,z=w[ve%16],$=L[ve%16],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,se=Y&65535|ee<<16,he=Z&65535|q<<16,z=se,$=he,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=(be>>>28|Me<<4)^(Me>>>2|be<<30)^(Me>>>7|be<<25),$=(Me>>>28|be<<4)^(be>>>2|Me<<30)^(be>>>7|Me<<25),Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,z=be&Le^be&Pe^Le&Pe,$=Me&We^Me&Ve^We&Ve,Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,we=Y&65535|ee<<16,me=Z&65535|q<<16,z=ye,$=Se,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=se,$=he,Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,ye=Y&65535|ee<<16,Se=Z&65535|q<<16,Le=M,Pe=G,Be=re,j=ye,Ie=ae,Ge=qe,Ye=ue,be=we,We=ke,Ve=Te,mt=Ae,Je=Se,ct=je,dt=Ee,ht=ce,Me=me,ve%16===15)for(oe=0;oe<16;oe++)z=w[oe],$=L[oe],Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=w[(oe+9)%16],$=L[(oe+9)%16],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,se=w[(oe+1)%16],he=L[(oe+1)%16],z=(se>>>1|he<<31)^(se>>>8|he<<24)^se>>>7,$=(he>>>1|se<<31)^(he>>>8|se<<24)^(he>>>7|se<<25),Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,se=w[(oe+14)%16],he=L[(oe+14)%16],z=(se>>>19|he<<13)^(he>>>29|se<<3)^se>>>6,$=(he>>>19|se<<13)^(se>>>29|he<<3)^(he>>>6|se<<26),Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,w[oe]=Y&65535|ee<<16,L[oe]=Z&65535|q<<16;z=be,$=Me,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[0],$=g[0],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[0]=be=Y&65535|ee<<16,g[0]=Me=Z&65535|q<<16,z=Le,$=We,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[1],$=g[1],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[1]=Le=Y&65535|ee<<16,g[1]=We=Z&65535|q<<16,z=Pe,$=Ve,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[2],$=g[2],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[2]=Pe=Y&65535|ee<<16,g[2]=Ve=Z&65535|q<<16,z=Be,$=mt,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[3],$=g[3],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[3]=Be=Y&65535|ee<<16,g[3]=mt=Z&65535|q<<16,z=j,$=Je,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[4],$=g[4],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[4]=j=Y&65535|ee<<16,g[4]=Je=Z&65535|q<<16,z=Ie,$=ct,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[5],$=g[5],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[5]=Ie=Y&65535|ee<<16,g[5]=ct=Z&65535|q<<16,z=Ge,$=dt,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[6],$=g[6],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[6]=Ge=Y&65535|ee<<16,g[6]=dt=Z&65535|q<<16,z=Ye,$=ht,Z=$&65535,q=$>>>16,Y=z&65535,ee=z>>>16,z=c[7],$=g[7],Z+=$&65535,q+=$>>>16,Y+=z&65535,ee+=z>>>16,q+=Z>>>16,Y+=q>>>16,ee+=Y>>>16,c[7]=Ye=Y&65535|ee<<16,g[7]=ht=Z&65535|q<<16,_t+=128,l-=128}return l}function Nt(c,g,y){var l=new Int32Array(8),w=new Int32Array(8),L=new Uint8Array(256),M,G=y;for(l[0]=1779033703,l[1]=3144134277,l[2]=1013904242,l[3]=2773480762,l[4]=1359893119,l[5]=2600822924,l[6]=528734635,l[7]=1541459225,w[0]=4089235720,w[1]=2227873595,w[2]=4271175723,w[3]=1595750129,w[4]=2917565137,w[5]=725511199,w[6]=4215389547,w[7]=327033209,Wt(l,w,g,y),y%=128,M=0;M<y;M++)L[M]=g[G-y+M];for(L[y]=128,y=256-128*(y<112?1:0),L[y-9]=0,R(L,y-8,G/536870912|0,G<<3),Wt(l,w,L,y),M=0;M<8;M++)R(c,8*M,l[M],w[M]);return 0}function rr(c,g){var y=r(),l=r(),w=r(),L=r(),M=r(),G=r(),re=r(),ye=r(),ae=r();Re(y,c[1],c[0]),Re(ae,g[1],g[0]),ge(y,y,ae),Ne(l,c[0],c[1]),Ne(ae,g[0],g[1]),ge(l,l,ae),ge(w,c[3],g[3]),ge(w,w,_),ge(L,c[2],g[2]),Ne(L,L,L),Re(M,l,y),Re(G,L,w),Ne(re,L,w),Ne(ye,l,y),ge(c[0],M,G),ge(c[1],ye,re),ge(c[2],re,G),ge(c[3],M,ye)}function Rr(c,g,y){var l;for(l=0;l<4;l++)A(c[l],g[l],y)}function cr(c,g){var y=r(),l=r(),w=r();h(w,g[2]),ge(y,g[0],w),ge(l,g[1],w),D(c,l),c[31]^=le(y)<<7}function Vt(c,g,y){var l,w;for(tt(c[0],a),tt(c[1],s),tt(c[2],s),tt(c[3],a),w=255;w>=0;--w)l=y[w/8|0]>>(w&7)&1,Rr(c,g,l),rr(g,c),rr(c,c),Rr(c,g,l)}function W(c,g){var y=[r(),r(),r(),r()];tt(y[0],m),tt(y[1],E),tt(y[2],s),ge(y[3],m,E),Vt(c,y,g)}function ne(c,g,y){var l=new Uint8Array(64),w=[r(),r(),r(),r()],L;for(y||n(g,32),Nt(l,g,32),l[0]&=248,l[31]&=127,l[31]|=64,W(w,l),cr(c,w),L=0;L<32;L++)g[L+32]=c[L];return 0}var ze=new Float64Array([237,211,245,92,26,99,18,88,214,156,247,162,222,249,222,20,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16]);function Ze(c,g){var y,l,w,L;for(l=63;l>=32;--l){for(y=0,w=l-32,L=l-12;w<L;++w)g[w]+=y-16*g[l]*ze[w-(l-32)],y=Math.floor((g[w]+128)/256),g[w]-=y*256;g[w]+=y,g[l]=0}for(y=0,w=0;w<32;w++)g[w]+=y-(g[31]>>4)*ze[w],y=g[w]>>8,g[w]&=255;for(w=0;w<32;w++)g[w]-=y*ze[w];for(l=0;l<32;l++)g[l+1]+=g[l]>>8,c[l]=g[l]&255}function gt(c){var g=new Float64Array(64),y;for(y=0;y<64;y++)g[y]=c[y];for(y=0;y<64;y++)c[y]=0;Ze(c,g)}function Mi(c,g,y,l){var w=new Uint8Array(64),L=new Uint8Array(64),M=new Uint8Array(64),G,re,ye=new Float64Array(64),ae=[r(),r(),r(),r()];Nt(w,l,32),w[0]&=248,w[31]&=127,w[31]|=64;var qe=y+64;for(G=0;G<y;G++)c[64+G]=g[G];for(G=0;G<32;G++)c[32+G]=w[32+G];for(Nt(M,c.subarray(32),y+32),gt(M),W(ae,M),cr(c,ae),G=32;G<64;G++)c[G]=l[G];for(Nt(L,c,y+64),gt(L),G=0;G<64;G++)ye[G]=0;for(G=0;G<32;G++)ye[G]=M[G];for(G=0;G<32;G++)for(re=0;re<32;re++)ye[G+re]+=L[G]*w[re];return Ze(c.subarray(32),ye),qe}function nr(c,g){var y=r(),l=r(),w=r(),L=r(),M=r(),G=r(),re=r();return tt(c[2],s),de(c[1],g),T(w,c[1]),ge(L,w,d),Re(w,w,c[2]),Ne(L,c[2],L),T(M,L),T(G,M),ge(re,G,M),ge(y,re,w),ge(y,y,L),b(y,y),ge(y,y,w),ge(y,y,L),ge(y,y,L),ge(c[0],y,L),T(l,c[0]),ge(l,l,L),J(l,w)&&ge(c[0],c[0],B),T(l,c[0]),ge(l,l,L),J(l,w)?-1:(le(c[0])===g[31]>>7&&Re(c[0],a,c[0]),ge(c[3],c[0],c[1]),0)}function Dr(c,g,y,l){var w,L=new Uint8Array(32),M=new Uint8Array(64),G=[r(),r(),r(),r()],re=[r(),r(),r(),r()];if(y<64||nr(re,l))return-1;for(w=0;w<y;w++)c[w]=g[w];for(w=0;w<32;w++)c[w+32]=l[w];if(Nt(M,c,y),gt(M),Vt(G,re,M),W(re,g.subarray(32)),rr(G,re),cr(L,G),y-=64,p(g,0,L,0)){for(w=0;w<y;w++)c[w]=0;return-1}for(w=0;w<y;w++)c[w]=g[w+64];return y}var Jl=32,ta=24,Oi=32,Wn=16,Ii=32,ra=32,Di=32,Ui=32,es=32,Pc=ta,Z1=Oi,J1=Wn,Ur=64,En=32,Vn=64,ts=32,rs=64;t.lowlevel={crypto_core_hsalsa20:O,crypto_stream_xor:pe,crypto_stream:X,crypto_stream_salsa20_xor:Q,crypto_stream_salsa20:V,crypto_onetimeauth:$e,crypto_onetimeauth_verify:_e,crypto_verify_16:P,crypto_verify_32:p,crypto_secretbox:He,crypto_secretbox_open:nt,crypto_scalarmult:F,crypto_scalarmult_base:K,crypto_box_beforenm:k,crypto_box_afternm:U,crypto_box:Xe,crypto_box_open:Ce,crypto_box_keypair:S,crypto_hash:Nt,crypto_sign:Mi,crypto_sign_keypair:ne,crypto_sign_open:Dr,crypto_secretbox_KEYBYTES:Jl,crypto_secretbox_NONCEBYTES:ta,crypto_secretbox_ZEROBYTES:Oi,crypto_secretbox_BOXZEROBYTES:Wn,crypto_scalarmult_BYTES:Ii,crypto_scalarmult_SCALARBYTES:ra,crypto_box_PUBLICKEYBYTES:Di,crypto_box_SECRETKEYBYTES:Ui,crypto_box_BEFORENMBYTES:es,crypto_box_NONCEBYTES:Pc,crypto_box_ZEROBYTES:Z1,crypto_box_BOXZEROBYTES:J1,crypto_sign_BYTES:Ur,crypto_sign_PUBLICKEYBYTES:En,crypto_sign_SECRETKEYBYTES:Vn,crypto_sign_SEEDBYTES:ts,crypto_hash_BYTES:rs,gf:r,D:d,L:ze,pack25519:D,unpack25519:de,M:ge,A:Ne,S:T,Z:Re,pow2523:b,add:rr,set25519:tt,modL:Ze,scalarmult:Vt,scalarbase:W};function Mc(c,g){if(c.length!==Jl)throw new Error("bad key size");if(g.length!==ta)throw new Error("bad nonce size")}function ey(c,g){if(c.length!==Di)throw new Error("bad public key size");if(g.length!==Ui)throw new Error("bad secret key size")}function ir(){for(var c=0;c<arguments.length;c++)if(!(arguments[c]instanceof Uint8Array))throw new TypeError("unexpected type, use Uint8Array")}function Oc(c){for(var g=0;g<c.length;g++)c[g]=0}t.randomBytes=function(c){var g=new Uint8Array(c);return n(g,c),g},t.secretbox=function(c,g,y){ir(c,g,y),Mc(y,g);for(var l=new Uint8Array(Oi+c.length),w=new Uint8Array(l.length),L=0;L<c.length;L++)l[L+Oi]=c[L];return He(w,l,l.length,g,y),w.subarray(Wn)},t.secretbox.open=function(c,g,y){ir(c,g,y),Mc(y,g);for(var l=new Uint8Array(Wn+c.length),w=new Uint8Array(l.length),L=0;L<c.length;L++)l[L+Wn]=c[L];return l.length<32||nt(w,l,l.length,g,y)!==0?null:w.subarray(Oi)},t.secretbox.keyLength=Jl,t.secretbox.nonceLength=ta,t.secretbox.overheadLength=Wn,t.scalarMult=function(c,g){if(ir(c,g),c.length!==ra)throw new Error("bad n size");if(g.length!==Ii)throw new Error("bad p size");var y=new Uint8Array(Ii);return F(y,c,g),y},t.scalarMult.base=function(c){if(ir(c),c.length!==ra)throw new Error("bad n size");var g=new Uint8Array(Ii);return K(g,c),g},t.scalarMult.scalarLength=ra,t.scalarMult.groupElementLength=Ii,t.box=function(c,g,y,l){var w=t.box.before(y,l);return t.secretbox(c,g,w)},t.box.before=function(c,g){ir(c,g),ey(c,g);var y=new Uint8Array(es);return k(y,c,g),y},t.box.after=t.secretbox,t.box.open=function(c,g,y,l){var w=t.box.before(y,l);return t.secretbox.open(c,g,w)},t.box.open.after=t.secretbox.open,t.box.keyPair=function(){var c=new Uint8Array(Di),g=new Uint8Array(Ui);return S(c,g),{publicKey:c,secretKey:g}},t.box.keyPair.fromSecretKey=function(c){if(ir(c),c.length!==Ui)throw new Error("bad secret key size");var g=new Uint8Array(Di);return K(g,c),{publicKey:g,secretKey:new Uint8Array(c)}},t.box.publicKeyLength=Di,t.box.secretKeyLength=Ui,t.box.sharedKeyLength=es,t.box.nonceLength=Pc,t.box.overheadLength=t.secretbox.overheadLength,t.sign=function(c,g){if(ir(c,g),g.length!==Vn)throw new Error("bad secret key size");var y=new Uint8Array(Ur+c.length);return Mi(y,c,c.length,g),y},t.sign.open=function(c,g){if(ir(c,g),g.length!==En)throw new Error("bad public key size");var y=new Uint8Array(c.length),l=Dr(y,c,c.length,g);if(l<0)return null;for(var w=new Uint8Array(l),L=0;L<w.length;L++)w[L]=y[L];return w},t.sign.detached=function(c,g){for(var y=t.sign(c,g),l=new Uint8Array(Ur),w=0;w<l.length;w++)l[w]=y[w];return l},t.sign.detached.verify=function(c,g,y){if(ir(c,g,y),g.length!==Ur)throw new Error("bad signature size");if(y.length!==En)throw new Error("bad public key size");var l=new Uint8Array(Ur+c.length),w=new Uint8Array(Ur+c.length),L;for(L=0;L<Ur;L++)l[L]=g[L];for(L=0;L<c.length;L++)l[L+Ur]=c[L];return Dr(w,l,l.length,y)>=0},t.sign.keyPair=function(){var c=new Uint8Array(En),g=new Uint8Array(Vn);return ne(c,g),{publicKey:c,secretKey:g}},t.sign.keyPair.fromSecretKey=function(c){if(ir(c),c.length!==Vn)throw new Error("bad secret key size");for(var g=new Uint8Array(En),y=0;y<g.length;y++)g[y]=c[32+y];return{publicKey:g,secretKey:new Uint8Array(c)}},t.sign.keyPair.fromSeed=function(c){if(ir(c),c.length!==ts)throw new Error("bad seed size");for(var g=new Uint8Array(En),y=new Uint8Array(Vn),l=0;l<32;l++)y[l]=c[l];return ne(g,y,!0),{publicKey:g,secretKey:y}},t.sign.publicKeyLength=En,t.sign.secretKeyLength=Vn,t.sign.seedLength=ts,t.sign.signatureLength=Ur,t.hash=function(c){ir(c);var g=new Uint8Array(rs);return Nt(g,c,c.length),g},t.hash.hashLength=rs,t.verify=function(c,g){return ir(c,g),c.length===0||g.length===0||c.length!==g.length?!1:N(c,0,g,0,c.length)===0},t.setPRNG=function(c){n=c},function(){var c=typeof self<"u"?self.crypto||self.msCrypto:null;if(c&&c.getRandomValues){var g=65536;t.setPRNG(function(y,l){var w,L=new Uint8Array(l);for(w=0;w<l;w+=g)c.getRandomValues(L.subarray(w,w+Math.min(l-w,g)));for(w=0;w<l;w++)y[w]=L[w];Oc(L)})}else typeof w6<"u"&&(c=Ho,c&&c.randomBytes&&t.setPRNG(function(y,l){var w,L=c.randomBytes(l);for(w=0;w<l;w++)y[w]=L[w];Oc(L)}))}()})(e.exports?e.exports:self.nacl=self.nacl||{})})(I1);var _6=I1.exports,Ni={};Object.defineProperty(Ni,"__esModule",{value:!0});Ni.replaceDerive=Ni.pathRegex=void 0;Ni.pathRegex=new RegExp("^m(\\/[0-9]+')+$");Ni.replaceDerive=e=>e.replace("'","");(function(e){Object.defineProperty(e,"__esModule",{value:!0}),e.derivePath=e.isValidPath=e.getPublicKey=e.CKDPriv=e.getMasterKeyFromSeed=void 0;const t=b6,r=_6,n=Ni,i="ed25519 seed",o=2147483648;e.getMasterKeyFromSeed=a=>{const u=t("sha512",i).update(Buffer.from(a,"hex")).digest(),d=u.slice(0,32),_=u.slice(32);return{key:d,chainCode:_}},e.CKDPriv=({key:a,chainCode:s},u)=>{const d=Buffer.allocUnsafe(4);d.writeUInt32BE(u,0);const _=Buffer.concat([Buffer.alloc(1,0),a,d]),m=t("sha512",s).update(_).digest(),E=m.slice(0,32),B=m.slice(32);return{key:E,chainCode:B}},e.getPublicKey=(a,s=!0)=>{const d=r.sign.keyPair.fromSeed(a).secretKey.subarray(32),_=Buffer.alloc(1,0);return s?Buffer.concat([_,Buffer.from(d)]):Buffer.from(d)},e.isValidPath=a=>n.pathRegex.test(a)?!a.split("/").slice(1).map(n.replaceDerive).some(isNaN):!1,e.derivePath=(a,s,u=o)=>{if(!e.isValidPath(a))throw new Error("Invalid derivation path");const{key:d,chainCode:_}=e.getMasterKeyFromSeed(s);return a.split("/").slice(1).map(n.replaceDerive).map(E=>parseInt(E,10)).reduce((E,B)=>e.CKDPriv(E,B+u),{key:d,chainCode:_})}})(Bv);function k6(e){let t="";for(let r=0;r<e.length;r++)t+=e[r].toString(16).padStart(2,"0");return t}function S6(){return zx(wc,256)}function E6(e){return Lv((e||"").trim(),wc)}function D1(e,t=0){const r=(e||"").trim().replace(/\s+/g," ");if(!Lv(r,wc))throw new Error("invalid mnemonic");const n=Kx(r),{key:i}=Bv.derivePath(`m/44'/148'/${t}'`,k6(n));return Jh.fromRawEd25519Seed(i)}function U1(e){const t=(e||"").trim();if(!ep.isValidEd25519SecretSeed(t))throw new Error("invalid secret");return Jh.fromSecret(t)}function F1(e){const t=(e||"").trim().replace(/\s+/g," ");if(ep.isValidEd25519SecretSeed(t))return{kind:"secret",normalized:t};const r=t.split(" ").filter(Boolean);return r.length===12||r.length===24?E6(t)?{kind:"mnemonic",normalized:t}:{kind:"invalid",error:"Recovery phrase checksum failed. Check for a mistyped word."}:{kind:"invalid",error:"Enter a 12/24-word recovery phrase or an S… secret key."}}function j6({onImport:e,busy:t,error:r}){const[n,i]=xe.useState(""),[o,a]=xe.useState(""),[s,u]=xe.useState("Imported"),d=n.trim()?F1(n):{kind:"invalid",error:""},_=d.kind!=="invalid"&&o.length>=12;return f.jsxs("div",{className:"vf-screen vf-import",children:[f.jsxs("div",{style:{textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",gap:"6px"},children:[f.jsx("div",{style:{width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(135deg, var(--bg-elev) 0%, var(--bg-card) 100%)",border:"1px solid var(--border-strong)",marginBottom:4,boxShadow:"0 4px 16px rgba(0,0,0,.25)"},children:f.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("polyline",{points:"21 15 16 10 11 15"}),f.jsx("line",{x1:"16",y1:"10",x2:"16",y2:"22"}),f.jsx("path",{d:"M18 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4"})]})}),f.jsx("h2",{style:{margin:0},children:"Import wallet"}),f.jsx("p",{className:"vf-hint",style:{textAlign:"center",margin:0},children:"Restore using a secret key or recovery phrase."})]}),f.jsx(Pr,{scope:"global"}),f.jsxs("label",{children:["Secret key or recovery phrase",f.jsx("textarea",{rows:3,spellCheck:!1,autoComplete:"off",placeholder:"Starts with S... or 12/24 words separated by spaces",value:n,onChange:m=>i(m.target.value)})]}),n.trim()&&d.kind==="invalid"&&f.jsx("p",{className:"vf-error",children:d.error}),d.kind!=="invalid"&&f.jsxs("p",{className:"vf-hint",style:{color:"var(--ok)",display:"flex",alignItems:"center",gap:"4px",fontWeight:"500"},children:["Detected format: ",d.kind]}),f.jsxs("label",{children:["Wallet label",f.jsx("input",{placeholder:"Example: Imported",value:s,onChange:m=>u(m.target.value)})]}),f.jsxs("label",{children:["Password",f.jsx("input",{type:"password",autoComplete:"new-password",placeholder:"12+ characters to encrypt keys",value:o,onChange:m=>a(m.target.value)})]}),r&&f.jsx("p",{className:"vf-error",children:r}),f.jsx("button",{className:"vf-btn primary",disabled:t||!_,onClick:()=>e(d.normalized,o,s),style:{marginTop:8},children:t?"Importing…":"Import wallet"})]})}function C6({onGetStarted:e}){const[t,r]=xe.useState(1),[n,i]=xe.useState("forward"),o=[{id:1,title:"Coordination Swarm",desc:"Venice AI coordinator maps strategy, while parallel worker agents execute swap and deposit actions autonomously.",icon:f.jsxs("svg",{width:"64",height:"64",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("circle",{cx:"12",cy:"12",r:"4"}),f.jsx("path",{d:"M12 2v6M12 16v6M4.93 4.93l4.24 4.24M14.83 14.83l4.24 4.24M2 12h6M16 12h6M4.93 19.07l4.24-4.24M14.83 9.17l4.24-4.24"})]})},{id:2,title:"Secure Boundaries",desc:"Enforce ed25519 session-key limits on-chain. Smart contracts prevent agents from exceeding approved amount limits.",icon:f.jsxs("svg",{width:"64",height:"64",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),f.jsx("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"}),f.jsx("path",{d:"M12 15v3"})]})},{id:3,title:"Gasless Relaying",desc:"Pay zero transaction fees. Every agent operation is fee-bump relayer sponsored on Stellar testnet.",icon:f.jsxs("svg",{width:"64",height:"64",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("line",{x1:"12",y1:"1",x2:"12",y2:"23"}),f.jsx("path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"})]})}],a=o[t-1],s=()=>{t<3?(i("forward"),r(t+1)):e()},u=()=>{t>1&&(i("back"),r(t-1))},d=_=>{_!==t&&(i(_>t?"forward":"back"),r(_))};return f.jsxs("div",{className:"vf-screen vf-onboarding",children:[f.jsx(A6,{}),t<3&&f.jsx("button",{className:"ob-skip-btn",onClick:e,children:"Skip"}),f.jsxs("div",{className:"ob-content","data-direction":n,children:[f.jsx("div",{className:"ob-icon-wrapper",children:a.icon}),f.jsx("h2",{className:"ob-title",children:a.title}),f.jsx("p",{className:"ob-desc",children:a.desc})]},t),f.jsx("div",{className:"ob-dots",children:o.map(_=>f.jsx("button",{type:"button",className:"ob-dot"+(_.id===t?" active":""),"aria-label":`Go to onboarding step ${_.id}`,"aria-current":_.id===t?"step":void 0,onClick:()=>d(_.id)},_.id))}),f.jsxs("div",{className:"ob-actions",children:[t>1&&f.jsxs("button",{className:"vf-btn ghost",onClick:u,style:{flex:1},children:[f.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginRight:6},children:f.jsx("path",{d:"M19 12H5M12 19l-7-7 7-7"})}),"Back"]}),f.jsx("button",{className:"vf-btn primary",onClick:s,style:{flex:t>1?2:1},children:t===3?f.jsxs(f.Fragment,{children:["Get Started",f.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginLeft:6},children:f.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})})]}):f.jsxs(f.Fragment,{children:["Next",f.jsx("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",style:{marginLeft:6},children:f.jsx("path",{d:"M5 12h14M12 5l7 7-7 7"})})]})})]}),f.jsxs("div",{className:"ob-foot",children:[f.jsx("span",{className:"ob-foot-mark",children:"vibing / farmer"}),f.jsx("span",{className:"ob-foot-tag",children:"Set once. Vibe forever."})]})]})}function A6(){return f.jsx("style",{children:`
.vf-onboarding {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  justify-content: space-between;
  flex: 1;
  min-height: 480px;
  position: relative;
}

.ob-skip-btn {
  position: absolute;
  top: -8px; right: -4px;
  background: transparent;
  border: none;
  font-family: var(--mono);
  font-size: 11px;
  color: var(--text-faint);
  cursor: pointer;
  padding: 8px 12px;
  transition: color 200ms ease;
  z-index: 10;
}
.ob-skip-btn:hover {
  color: var(--text);
}

.ob-content {
  --ob-enter-x: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 32px 12px 16px;
  flex: 1;
  justify-content: center;
  animation: ob-fade-in 220ms cubic-bezier(.23,1,.32,1) both;
}
.ob-content[data-direction="back"] { --ob-enter-x: -12px; }
@keyframes ob-fade-in {
  from { opacity: 0; transform: translateX(var(--ob-enter-x)); }
  to   { opacity: 1; transform: translateX(0); }
}

.ob-icon-wrapper {
  width: 96px; height: 96px;
  border-radius: 24px;
  background: var(--bg-elev);
  border: 1px solid var(--border-strong);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 24px;
}

.ob-title {
  font-family: var(--font-display, "Geist", sans-serif);
  font-size: 20px; font-weight: 700;
  color: var(--text);
  margin: 0 0 12px;
  letter-spacing: -.02em;
}

.ob-desc {
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--text-muted);
  max-width: 28ch;
  margin: 0;
}

.ob-dots {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-bottom: 24px;
}
.ob-dot {
  appearance: none;
  width: 32px; height: 32px;
  padding: 0;
  border: 0;
  display: grid;
  place-items: center;
  background: transparent;
  cursor: pointer;
}
.ob-dot::before {
  content: "";
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--border-strong);
  transition: background-color 160ms ease, transform 160ms cubic-bezier(.23,1,.32,1);
}
.ob-dot.active::before {
  background: var(--accent, #cfff3d);
  transform: scale(1.25);
}

.ob-actions {
  display: flex;
  gap: 12px;
  align-items: center;
}

.ob-foot {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  margin-top: 24px;
  padding-top: 12px;
  border-top: 1px solid var(--border);
}
.ob-foot-mark {
  font-family: var(--mono);
  font-size: 10px;
  color: var(--text-faint);
}
.ob-foot-tag {
  font-family: var(--font-script, "Newsreader", serif);
  font-style: italic;
  font-size: 11px;
  color: var(--text-faint);
}

@media (prefers-reduced-motion: reduce) {
  .ob-content { animation: none; }
  .ob-dot::before { transition: background-color 160ms ease; }
}
`})}function N6({publicKey:e,portfolio:t,unfunded:r,onFund:n,onSend:i,onReceive:o,busy:a}){const[s,u]=xe.useState(!1),d=()=>{var _;(_=navigator.clipboard)==null||_.writeText(e),u(!0),setTimeout(()=>u(!1),1500)};return f.jsxs("div",{className:"vf-screen vf-home",children:[f.jsxs("div",{className:"vf-balance-card",children:[f.jsx("div",{className:"vf-portfolio",children:t==null?"N/A":t.complete?`$${t.total.toFixed(2)}`:`~$${t.total.toFixed(2)}`}),f.jsxs("div",{className:"vf-address-container",children:[f.jsxs("span",{className:"vf-address",title:e,children:[e.slice(0,6),"…",e.slice(-6)]}),f.jsx("button",{className:"vf-address-copy-btn",onClick:d,title:"Copy address",children:s?f.jsx("span",{style:{color:"var(--ok)",fontWeight:600},children:"Copied"}):f.jsxs(f.Fragment,{children:[f.jsxs("svg",{width:"11",height:"11",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),f.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]}),f.jsx("span",{children:"Copy"})]})})]})]}),r&&f.jsxs("div",{className:"vf-fund",children:[f.jsx("p",{style:{margin:0},children:"This testnet account is not funded yet."}),f.jsx("button",{className:"vf-btn",disabled:a,onClick:n,children:"Fund via Friendbot"})]}),f.jsxs("div",{className:"vf-actions",children:[f.jsxs("button",{className:"vf-btn primary",onClick:i,children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("line",{x1:"12",y1:"19",x2:"12",y2:"5"}),f.jsx("polyline",{points:"5 12 12 5 19 12"})]}),"Send"]}),f.jsxs("button",{className:"vf-btn",onClick:o,children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("line",{x1:"12",y1:"5",x2:"12",y2:"19"}),f.jsx("polyline",{points:"19 12 12 19 5 12"})]}),"Receive"]})]}),f.jsx("ul",{className:"vf-tokens",children:((t==null?void 0:t.rows)??[]).map(_=>{const m=_.code.toLowerCase(),E=m==="xlm",B=m==="usdc",R=E?"xlm":B?"usdc":"unknown",N=E?"Stellar Lumens":B?"USD Coin":"Token";return f.jsxs("li",{className:"vf-token-row",children:[f.jsxs("div",{className:"vf-token-left",children:[f.jsx("div",{className:`vf-token-icon ${R}`,children:_.code.slice(0,2)}),f.jsxs("div",{className:"vf-token-meta",children:[f.jsx("span",{className:"vf-token-code",children:_.code}),f.jsx("span",{className:"vf-token-name",children:N})]})]}),f.jsxs("div",{className:"vf-token-right",children:[f.jsx("span",{className:"vf-token-balance",children:_.balance}),f.jsx("span",{className:"vf-token-usd",children:_.usd==null?"N/A":`$${_.usd.toFixed(2)}`})]})]},_.asset)})})]})}function R6({from:e,onPreview:t,onConfirm:r,preview:n,busy:i,error:o}){var v,x,C,O;const[a,s]=xe.useState(""),[u,d]=xe.useState(""),[_,m]=xe.useState(""),[E,B]=xe.useState(null),[R,N]=xe.useState(""),P=!!n&&!!E&&(a!==E.to||u!==E.amount||_!==E.memo);function p(){N("");const H=parseFloat(u);if(isNaN(H)||H<=0)return N("Amount must be greater than 0"),!1;const Q=a.includes("*"),V=a.length<10;return!Q&&!V&&!/^[GC][A-Z2-7]{55}$/i.test(a)?(N("Invalid destination address"),!1):!0}return f.jsxs("div",{className:"vf-screen vf-send",children:[f.jsx("h2",{children:"Send"}),f.jsxs("label",{children:["Destination",f.jsx("input",{"aria-label":"Destination",placeholder:"G... or federation address",value:a,onChange:H=>{s(H.target.value),N("")}})]}),f.jsxs("label",{children:["Amount (XLM)",f.jsx("input",{"aria-label":"Amount",placeholder:"0.00",value:u,onChange:H=>{d(H.target.value),N("")}})]}),f.jsxs("label",{children:["Memo (optional)",f.jsx("input",{placeholder:"Text, ID, or hash",value:_,onChange:H=>{m(H.target.value),N("")}})]}),R&&f.jsx("p",{className:"vf-error",children:R}),f.jsx("button",{className:"vf-btn primary",disabled:i||!a||!u,onClick:()=>{p()&&(B({to:a,amount:u,memo:_}),t({from:e,to:a,asset:"XLM",amount:u,memo:_}))},children:i?"Building…":"Review transaction"}),n&&f.jsxs("div",{className:"vf-confirm-card",children:[f.jsxs("h3",{children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("path",{d:"M9 11l3 3L22 4"}),f.jsx("path",{d:"M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"})]}),"Confirm transaction"]}),f.jsxs("dl",{children:[f.jsx("dt",{children:"To"}),f.jsx("dd",{children:(v=n.confirm.ops[0])==null?void 0:v.destination}),f.jsx("dt",{children:"Asset"}),f.jsx("dd",{children:(x=n.confirm.ops[0])==null?void 0:x.asset}),f.jsx("dt",{children:"Amount"}),f.jsx("dd",{children:(C=n.confirm.ops[0])==null?void 0:C.amount}),f.jsx("dt",{children:"Memo"}),f.jsx("dd",{children:n.confirm.memo||"None"}),f.jsx("dt",{children:"Fee"}),f.jsxs("dd",{children:[n.confirm.fee," stroops"]})]}),((O=n.vault)==null?void 0:O.hit)&&f.jsxs(f.Fragment,{children:[f.jsx(mv,{verdict:n.vault,onApprove:()=>{P||r({from:e,to:a,asset:"XLM",amount:u,memo:_})},onReject:()=>{}}),f.jsxs("p",{className:"vf-warn",children:['This is the vault "',n.vault.name,'". A plain payment does not deposit funds. Use Deposit instead.']})]}),o&&f.jsx("p",{className:"vf-error",children:o}),P&&f.jsx("p",{className:"vf-hint",children:"Inputs changed. Select Review transaction again."}),f.jsx("button",{className:"vf-btn primary",disabled:i||P,onClick:()=>r({from:e,to:a,asset:"XLM",amount:u,memo:_}),children:i?"Sending…":"Confirm and send"})]})]})}function T6({publicKey:e}){const[t,r]=xe.useState(""),[n,i]=xe.useState(!1);xe.useEffect(()=>{ny(async()=>{const{addressQrDataUrl:a}=await import("./assets/qr-B2QwpcFi.js");return{addressQrDataUrl:a}},[]).then(({addressQrDataUrl:a})=>a(e).then(r))},[e]);const o=()=>{var a;(a=navigator.clipboard)==null||a.writeText(e),i(!0),setTimeout(()=>i(!1),1500)};return f.jsxs("div",{className:"vf-screen vf-receive",children:[f.jsx("h2",{children:"Receive"}),f.jsx("p",{className:"vf-hint",children:"Scan or share your Stellar address"}),t?f.jsx("img",{className:"vf-qr",src:t,alt:"Wallet address QR",width:176,height:176}):f.jsx("div",{style:{width:176,height:176,margin:"0 auto",borderRadius:"var(--r-lg)",background:"var(--bg-elev)",border:"1px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"center",color:"var(--text-faint)",fontSize:"11px"},children:"Loading QR…"}),f.jsx("code",{className:"vf-address-full",children:e}),f.jsx("button",{className:`vf-btn ${n?"primary":""}`,style:{width:"100%",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px"},onClick:o,children:n?f.jsx("span",{style:{fontWeight:"bold"},children:"Copied to clipboard"}):f.jsxs(f.Fragment,{children:[f.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2.5",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"9",y:"9",width:"13",height:"13",rx:"2",ry:"2"}),f.jsx("path",{d:"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"})]}),f.jsx("span",{children:"Copy address"})]})})]})}function L6({items:e}){const t=r=>!r||typeof r!="string"?"-":r.length<=12?r:`${r.slice(0,6)}…${r.slice(-6)}`;return e!=null&&e.length?f.jsx("ul",{className:"vf-screen vf-history",children:e.map(r=>{const n=r.direction==="in",i=n?"in":"out",o=n?"In":"Out",a=r.asset==="XLM"?"XLM":r.asset.split(":")[0],s=n?`Received ${a}`:`Sent ${a}`,u=n?r.from:r.to,d=n?`From: ${t(u)}`:`To: ${t(u)}`;return f.jsx("li",{children:f.jsxs("div",{className:"vf-history-row",children:[f.jsxs("div",{className:"vf-history-left",children:[f.jsx("div",{className:`vf-history-badge ${i}`,children:o}),f.jsxs("div",{className:"vf-history-meta",children:[f.jsx("span",{className:"vf-history-title",children:s}),f.jsx("span",{className:"vf-history-address",children:d})]})]}),f.jsxs("div",{className:"vf-history-right",children:[f.jsxs("span",{className:`vf-history-amount ${i}`,children:[n?"+":"-",r.amount," ",a]}),f.jsx("span",{className:"vf-history-time",children:r.createdAt})]})]})},r.id)})}):f.jsxs("div",{className:"vf-screen",style:{justifyContent:"center",alignItems:"center",minHeight:"240px",gap:"12px"},children:[f.jsx("div",{style:{width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg-elev)",border:"1px solid var(--border)",boxShadow:"0 4px 16px rgba(0,0,0,.2)"},children:f.jsx("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"var(--text-faint)",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:f.jsx("polyline",{points:"22 12 18 12 15 21 9 3 6 12 2 12"})})}),f.jsx("p",{style:{margin:0,color:"var(--text-muted)",fontSize:"14px",fontWeight:"500"},children:"No activity yet"}),f.jsx("p",{style:{margin:0,color:"var(--text-faint)",fontSize:"11px"},children:"Transactions will appear here once you send or receive."})]})}function B6({publicKey:e,onUnlock:t,error:r,busy:n}){const[i,o]=xe.useState("");return f.jsxs("div",{className:"vf-screen vf-unlock",style:{justifyContent:"center",minHeight:"320px"},children:[f.jsxs("div",{style:{textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",gap:"6px"},children:[f.jsx("div",{style:{width:48,height:48,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(135deg, var(--bg-elev) 0%, var(--bg-card) 100%)",border:"1px solid var(--border-strong)",marginBottom:4,boxShadow:"0 4px 16px rgba(0,0,0,.25)"},children:f.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 24 24",fill:"none",stroke:"var(--accent)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),f.jsx("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]})}),f.jsx("h2",{style:{margin:0},children:"Unlock wallet"}),f.jsxs("p",{className:"vf-muted",style:{margin:0},children:[e==null?void 0:e.slice(0,6),"…",e==null?void 0:e.slice(-6)]})]}),f.jsx("input",{type:"password",autoComplete:"current-password",placeholder:"Enter password",value:i,onChange:a=>o(a.target.value),onKeyDown:a=>a.key==="Enter"&&t(i)}),f.jsx("p",{className:"vf-hint",style:{textAlign:"center"},children:"This password unlocks the local vault in this browser."}),r&&f.jsx("p",{className:"vf-error",children:r}),f.jsx("button",{className:"vf-btn primary",disabled:n||!i,onClick:()=>t(i),children:n?"Unlocking…":"Unlock"})]})}const Sf="vf_wallet_api_key";function z1(){try{return typeof localStorage<"u"?localStorage:null}catch{return null}}function Ef(e=z1()){try{return(e==null?void 0:e.getItem(Sf))||""}catch{return""}}function P6(e,t=z1()){try{const r=(e||"").trim();r?t==null||t.setItem(Sf,r):t==null||t.removeItem(Sf)}catch{}}function M6({onLock:e,onExport:t,onReset:r,autoLockMin:n,onSetAutoLock:i}){const[o,a]=xe.useState(Ef()),[s,u]=xe.useState(!1);return f.jsxs("div",{className:"vf-screen vf-settings",children:[f.jsx("h2",{children:"Settings"}),f.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"2px",background:"var(--bg-elev)",borderRadius:"var(--r-lg)",border:"1px solid var(--border)",overflow:"hidden"},children:[f.jsxs("button",{className:"vf-btn",style:{borderRadius:0,border:"none",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",gap:"8px",justifyContent:"flex-start",background:"transparent",padding:"14px 14px"},onClick:e,children:[f.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"var(--warn)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("rect",{x:"3",y:"11",width:"18",height:"11",rx:"2",ry:"2"}),f.jsx("path",{d:"M7 11V7a5 5 0 0 1 10 0v4"})]}),"Lock now"]}),f.jsxs("label",{style:{padding:"14px",borderBottom:"1px solid var(--border)",display:"flex",flexDirection:"row",alignItems:"center",gap:"8px"},children:[f.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"var(--text-muted)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("circle",{cx:"12",cy:"12",r:"10"}),f.jsx("polyline",{points:"12 6 12 12 16 14"})]}),f.jsx("span",{style:{flex:1},children:"Auto-lock (min)"}),f.jsx("input",{type:"number",min:1,max:60,value:n,onChange:d=>i(Number(d.target.value)),style:{width:56,textAlign:"center"}})]}),f.jsxs("label",{style:{padding:"14px",borderBottom:"1px solid var(--border)",display:"flex",flexDirection:"column",gap:"8px"},children:[f.jsxs("span",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[f.jsx("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"var(--text-muted)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:f.jsx("path",{d:"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"})}),f.jsx("span",{style:{flex:1},children:"VF API key (F8 gate)"})]}),f.jsxs("span",{style:{display:"flex",gap:"6px"},children:[f.jsx("input",{type:"password",placeholder:"vf_…",value:o,onChange:d=>{a(d.target.value),u(!1)},style:{flex:1,fontFamily:"monospace"}}),f.jsx("button",{className:"vf-btn",onClick:()=>{P6(o),a(Ef()),u(!0)},children:"Save"})]}),f.jsx("span",{style:{fontSize:11,color:"var(--text-muted)"},children:s?"Saved. Vault eligibility (F8) now checks via the VF gateway.":"Generate at /developers → Keys (scope: market). Empty = local F8 check."})]}),f.jsxs("button",{className:"vf-btn ghost",style:{borderRadius:0,border:"none",display:"flex",alignItems:"center",gap:"8px",justifyContent:"flex-start",padding:"14px 14px"},onClick:t,children:[f.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"var(--text-muted)",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}),f.jsx("polyline",{points:"17 8 12 3 7 8"}),f.jsx("line",{x1:"12",y1:"3",x2:"12",y2:"15"})]}),"Export secret"]}),f.jsxs("button",{className:"vf-btn ghost",style:{borderRadius:0,border:"none",borderTop:"1px solid var(--border)",display:"flex",alignItems:"center",gap:"8px",justifyContent:"flex-start",padding:"14px 14px",color:"var(--danger)"},onClick:()=>{window.confirm("Are you sure you want to reset this wallet? All local keys will be deleted. Make sure you have backed up your recovery phrase!")&&r()},children:[f.jsxs("svg",{width:"16",height:"16",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[f.jsx("polyline",{points:"3 6 5 6 21 6"}),f.jsx("path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"})]}),"Reset Wallet"]})]})]})}const jf="vf_classic_wallets",$1=new TextEncoder,O6=new TextDecoder;function du(e){const t=e instanceof Uint8Array?e:new Uint8Array(e);let r="";for(let n=0;n<t.length;n++)r+=String.fromCharCode(t[n]);return btoa(r)}function xl(e){const t=atob(e),r=new Uint8Array(t.length);for(let n=0;n<t.length;n++)r[n]=t.charCodeAt(n);return r}async function Rc(e,t,r=6e5){const n=await crypto.subtle.importKey("raw",$1.encode(e),"PBKDF2",!1,["deriveKey"]);return crypto.subtle.deriveKey({name:"PBKDF2",salt:t,iterations:r,hash:"SHA-256"},n,{name:"AES-GCM",length:256},!0,["encrypt","decrypt"])}async function H1(e,t){const r=crypto.getRandomValues(new Uint8Array(16)),n=crypto.getRandomValues(new Uint8Array(12)),i=await Rc(t,r,6e5),o=await crypto.subtle.encrypt({name:"AES-GCM",iv:n},i,$1.encode(e));return{version:1,kdf:{name:"PBKDF2",hash:"SHA-256",iters:6e5},salt:du(r),iv:du(n),ciphertext:du(o)}}async function Tc(e,t){const r=await crypto.subtle.decrypt({name:"AES-GCM",iv:xl(e.iv)},t,xl(e.ciphertext));return O6.decode(r)}async function W1(e,t){const r=await Rc(t,xl(e.salt),e.kdf.iters);return Tc(e,r)}async function Lc(){const e=await chrome.storage.local.get(jf);return(e==null?void 0:e[jf])??{}}async function V1(e){const t=await Lc();t[e.publicKey]=e,await chrome.storage.local.set({[jf]:t})}async function ea(e){return(await Lc())[e]}async function I6(){return Object.values(await Lc())}const Ri="vf_classic_session",K1=6e5;async function q1(e,t){var o,a;const r=await ea(e);if(!r)throw new Error("wallet not found");const n=await Rc(t,xl(r.blob.salt),r.blob.kdf.iters);await Tc(r.blob,n);const i=await crypto.subtle.exportKey("jwk",n);await((a=(o=chrome.storage.session).setAccessLevel)==null?void 0:a.call(o,{accessLevel:"TRUSTED_CONTEXTS"})),await chrome.storage.session.set({[Ri]:{publicKey:e,jwk:i}}),Y1()}async function D6(){const e=await chrome.storage.session.get(Ri),t=e==null?void 0:e[Ri];if(!t)return null;const r=await ea(t.publicKey);if(!r)return null;const n=await crypto.subtle.importKey("jwk",t.jwk,{name:"AES-GCM"},!0,["encrypt","decrypt"]);return{publicKey:t.publicKey,key:n,blob:r.blob}}async function G1(){await chrome.storage.session.remove(Ri)}async function U6(){const e=await chrome.storage.session.get(Ri);return!!(e!=null&&e[Ri])}function Y1(e=K1){var t,r;(r=(t=chrome.alarms)==null?void 0:t.create)==null||r.call(t,"vf_classic_autolock",{when:F6(e)})}function F6(e){return Date.now()+e}function z6({idleMs:e=K1}={}){var t,r,n;(n=(r=(t=chrome.alarms)==null?void 0:t.onAlarm)==null?void 0:r.addListener)==null||n.call(r,i=>{(i==null?void 0:i.name)==="vf_classic_autolock"&&G1()}),Y1(e)}let hu;function Zl(){return hu||(hu=new hy(tp)),hu}async function Bc({keypair:e,label:t,password:r,extra:n={}}){const i=e.publicKey(),o=await H1(e.secret(),r);return await V1({label:t,publicKey:i,blob:o,createdAt:Date.now(),...n}),await q1(i,r),i}async function $6({label:e,password:t,pendingBackup:r=!1}){const n=S6(),i=D1(n,0),o=r?{needsBackup:!0,mnemonicBlob:await H1(n,t)}:{};return{publicKey:await Bc({keypair:i,label:e,password:t,extra:o}),mnemonic:n}}async function H6({secret:e,password:t,label:r}){const n=U1(e);return{publicKey:await Bc({keypair:n,label:r,password:t})}}async function W6({mnemonic:e,password:t,label:r,index:n=0}){const i=D1(e,n);return{publicKey:await Bc({keypair:i,label:r,password:t})}}async function V6(e,t){return q1(e,t)}async function K6(e){const t=await D6();if(!t)throw new Error("locked");let r=null,n=null;try{r=await Tc(t.blob,t.key),n=new TextEncoder().encode(r);const i=U1(r);return await e(i)}finally{n&&n.fill(0),r=null}}async function q6(e,{horizon:t=Zl()}={}){var r;try{return(await t.loadAccount(e)).balances.map(i=>i.asset_type==="native"?{asset:"XLM",code:"XLM",issuer:null,balance:i.balance}:{asset:`${i.asset_code}:${i.asset_issuer}`,code:i.asset_code,issuer:i.asset_issuer,balance:i.balance})}catch(n){if(((r=n==null?void 0:n.response)==null?void 0:r.status)===404)return null;throw n}}async function G6(e,{fetchImpl:t=fetch}={}){return(await t(`https://friendbot.stellar.org/?addr=${encodeURIComponent(e)}`)).ok}const Y6=[{name:"Aave v3 USDC",protocol:"aave-v3",address:na,apy:4.8,risk:"low",yield_source:"lending",drawdown:"-1.2",min_capital:100,description:"Overcollateralized pooled lending. Battle-tested, highest TVL in DeFi. Best for principal preservation."},{name:"Morpho Blue USDC",protocol:"morpho-blue",address:na,apy:6.1,risk:"medium",yield_source:"curated",drawdown:"-2.8",min_capital:500,description:"Curator-managed isolated lending markets. Better yield than Aave, curator-dependent risk."},{name:"Pendle PT-USDC",protocol:"pendle-v2",address:na,apy:9.4,risk:"high",yield_source:"structured",drawdown:"-6.5",min_capital:1e3,description:"Fixed-rate yield via zero-coupon bond mechanics. Hold to maturity or face AMM exit loss."},{name:"Fluid USDC",protocol:"fluid",address:na,apy:5.2,risk:"high",yield_source:"hybrid",drawdown:"-4.1",min_capital:2e3,description:"Unified lending + DEX architecture. Highest capital efficiency, highest architectural risk."}],Q6=/^0x[a-fA-F0-9]{40}$/;function pu(e,t){if(!t||!Q6.test(t))throw new Error(`${e} is missing or is not a 0x address. Set VITE_${e} (see docs/deploy-checklist.md).`);return t}pu("BASE_POOL_1_ADDRESS","0x389250872044368759D3db5C09b2706A6628d4e0"),pu("BASE_POOL_2_ADDRESS","0x5E843A639F0555E2A6669601621befC887Bdb479"),pu("BASE_POOL_3_ADDRESS","0xadD3c1A75c7Cef2516b51750959BD829a4AD4761");function X6({apiKey:e,base:t="/api/vf"}){const r={"Content-Type":"application/json",Authorization:`Bearer ${e}`};async function n(i,{method:o="GET",body:a}={}){const s=await fetch(`${t}${i}`,{method:o,headers:r,...a!==void 0?{body:JSON.stringify(a)}:{}}),u=await s.json().catch(()=>({}));if(!s.ok)throw new Error(u.error||`HTTP ${s.status}`);return u}return{strategy:i=>n("/strategy",{method:"POST",body:i}),eligibility:i=>n("/eligibility",{method:"POST",body:i}),vaultFacts:i=>n(`/vault-facts?protocol=${encodeURIComponent(i)}`),prices:i=>n(`/prices?coins=${encodeURIComponent(i)}`),buildTx:i=>n("/build-tx",{method:"POST",body:i}),simulate:i=>n("/simulate",{method:"POST",body:{xdr:i}}),submit:i=>n("/submit",{method:"POST",body:{xdr:i}}),scan:i=>n("/scan",{method:"POST",body:i})}}function Z6(e){var t;return!e||(t=e.isNative)!=null&&t.call(e)?"XLM":`${e.getCode()}:${e.getIssuer()}`}function J6(e){return e.type==="payment"?{type:"payment",decodable:!0,destination:e.destination,asset:Z6(e.asset),amount:e.amount}:e.type==="createAccount"?{type:"createAccount",decodable:!0,destination:e.destination,amount:e.startingBalance}:{type:e.type,decodable:!1}}function e3(e,t=rp){var o;const r=np.fromXDR(e,t),n=r.operations.map(J6),i=r.memo&&r.memo.value?String(r.memo.value):"";return{source:r.source,fee:r.fee,memo:i,ops:n,kind:((o=n[0])==null?void 0:o.type)??"other",decodable:n.length>0&&n.every(a=>a.decodable)}}function t3(e){const t=Y6.find(r=>r.address===e);return t?{hit:!0,vault:t}:{hit:!1}}async function Q1(e,t){const r=t3(e);if(!r.hit)return{hit:!1};const n={hit:!0,name:r.vault.name},i=Ef();if(i)try{const a=BigInt(Math.round(Number(t)*10**iy)),s=await X6({apiKey:i}).eligibility({vault:e,protocol:r.vault.protocol,amount:a.toString()});return{...n,allow:s.allow===!0,reasons:s.reasons??[],source:"api"}}catch(a){return{...n,allow:!1,reasons:[`eligibility API: ${a.message}`],source:"api"}}const o=await mu({vault:r.vault.protocol,amount:t});return{...n,allow:o.allow,reasons:o.reasons,source:"local"}}function r3(e){return e==="XLM"?Ic.native():new Ic(e.code,e.issuer)}async function X1({from:e,to:t,asset:r,amount:n,memo:i,horizon:o=Zl()}){const a=await o.loadAccount(e),s=new np(a,{fee:ip,networkPassphrase:rp}).addOperation(oy.payment({destination:t,asset:r3(r),amount:String(n)})).setTimeout(300);i&&s.addMemo(py.text(i));const u=s.build();return{xdr:u.toXDR(),tx:u}}async function n3({from:e,to:t,asset:r,amount:n,memo:i,horizon:o=Zl()}){const a=await Q1(t,n);if(a.hit)return{confirm:{fee:ip,memo:i||"",ops:[{destination:t,asset:r==="XLM"?"XLM":r.code,amount:String(n)}],kind:"vault",decodable:!1},vault:a};const{xdr:s}=await X1({from:e,to:t,asset:r,amount:n,memo:i,horizon:o});return{confirm:e3(s),vault:a}}async function i3({from:e,to:t,asset:r,amount:n,memo:i,horizon:o=Zl()}){const a=await Q1(t,n);if(a.hit&&!a.allow)throw new Error(`ineligible: ${(a.reasons??[]).join("; ")}`);const{tx:s}=await X1({from:e,to:t,asset:r,amount:n,memo:i,horizon:o});return await K6(async d=>s.sign(d)),{hash:(await o.submitTransaction(s)).hash,status:"SUCCESS"}}const o3="https://api.coingecko.com/api/v3/simple/price?ids=stellar&vs_currencies=usd";async function Qh({fetchImpl:e=fetch,endpoint:t=o3}={}){var r;try{const n=await e(t);if(!n.ok)return null;const i=await n.json();return((r=i==null?void 0:i.stellar)==null?void 0:r.usd)??null}catch{return null}}function a3(e,t){return e.code==="XLM"?t==null?null:Number(e.balance)*t:e.code==="USDC"?Number(e.balance):null}function l3(e,t){const r=e.map(o=>({...o,usd:a3(o,t)})),n=r.reduce((o,a)=>a.usd==null?o:o+a.usd,0),i=r.every(o=>o.usd!=null);return{total:n,complete:i,rows:r}}async function s3(e,{fetchImpl:t=fetch,limit:r=20,horizonUrl:n=tp}={}){var i;try{const o=`${n}/accounts/${e}/payments?order=desc&limit=${r}`,a=await t(o);if(!a.ok)return[];const s=await a.json();return(((i=s==null?void 0:s._embedded)==null?void 0:i.records)??[]).filter(d=>d.type==="payment"||d.type==="create_account").map(d=>{const _=d.to??d.account;return{id:d.id,type:d.type,from:d.from??d.funder,to:_,asset:d.asset_type==="native"||d.type==="create_account"?"XLM":`${d.asset_code}:${d.asset_issuer}`,amount:d.amount??d.starting_balance,createdAt:d.created_at,direction:_===e?"in":"out"}})}catch{return[]}}async function vu(){const t=(await I6())[0];return{hasWallet:!!t,publicKey:(t==null?void 0:t.publicKey)??null,unlocked:await U6(),needsBackup:!!(t!=null&&t.needsBackup)}}async function u3(e,t){const{publicKey:r,mnemonic:n}=await $6({label:e,password:t,pendingBackup:!0});return{publicKey:r,mnemonic:n,needsBackup:!0,indices:xv(24,3)}}async function yu(e){const t=await ea(e);if(!t)throw new Error("wallet not found");const{mnemonicBlob:r,...n}=t;return await V1({...n,needsBackup:!1}),!0}async function f3(e,t){const r=await ea(e);if(!(r!=null&&r.mnemonicBlob))throw new Error("no pending backup for this wallet");return W1(r.mnemonicBlob,t)}async function c3(e,t,r){const n=F1(e);if(n.kind==="secret")return H6({secret:n.normalized,password:t,label:r});if(n.kind==="mnemonic")return W6({mnemonic:n.normalized,password:t,label:r});throw new Error(n.error)}async function d3(e,t){await V6(e,t)}async function h3(){await G1()}function p3(){z6({idleMs:6e5})}async function v3(e){const t=await q6(e);if(t==null)return{unfunded:!0,portfolio:null};let r=await Qh();return r==null&&(r=await Qh({endpoint:"/api/price?ids=stellar&vs_currencies=usd"}).catch(()=>null)),{unfunded:!1,portfolio:l3(t,r)}}async function y3(e){return G6(e)}async function g3(e){return n3(e)}async function m3(e){return i3(e)}async function Xh(e){return s3(e)}async function x3(e,t){const r=await ea(e);if(!r)throw new Error("wallet not found");return W1(r.blob,t)}const gu="blend-usdc";function Zh(e,t){chrome.runtime.sendMessage({type:"SIGN_REQUEST",action:e,params:t})}const b3=`
:root{
  --bg-base:#0a0b09; --bg-canvas:#0e100c; --bg-card:#161813; --bg-elev:#1e201a; --bg-elev-2:#262821;
  --border:rgba(236,235,225,.06); --border-strong:rgba(236,235,225,.12); --border-accent:rgba(207,255,61,.45);
  --text:#f0efe6; --text-muted:#a0a096; --text-faint:#5a5a52;
  --accent:#cfff3d; --accent-soft:rgba(207,255,61,.07); --accent-fg:#0a0b09;
  --accent-glow:rgba(207,255,61,.12); --accent-glow-strong:rgba(207,255,61,.22);
  --info:#7aa2ff; --warn:#f0b54a; --danger:#ff7479; --ok:#6fe39a;
  --font:"Geist",system-ui,-apple-system,sans-serif;
  --mono:"JetBrains Mono","Geist Mono",ui-monospace,"SF Mono",monospace;
  --r-sm:6px; --r-md:10px; --r-lg:16px; --r-xl:20px;
  --ease:cubic-bezier(0.16, 1, 0.3, 1);
}
.vf *{box-sizing:border-box}
.vf{width:360px;min-height:540px;display:flex;flex-direction:column;background:var(--bg-canvas);color:var(--text);
  font-family:var(--font);font-size:13px;line-height:1.45;-webkit-font-smoothing:antialiased}
.vf .tnum{font-variant-numeric:tabular-nums;font-feature-settings:"tnum" 1,"lnum" 1}
.vf .mono{font-family:var(--mono);letter-spacing:-.01em}

/* ───── header ───── */
.vf-head{display:flex;align-items:center;gap:10px;padding:12px 16px;
  border-bottom:1px solid var(--border);background:var(--bg-canvas)}
.vf-logo{width:34px;height:34px;flex:0 0 34px;border-radius:var(--r-md);overflow:hidden;display:grid;place-items:center;
  border:1px solid var(--border-strong)}
.vf-logo img{width:100%;height:100%;display:block}
.vf-brand{display:flex;flex-direction:column;line-height:1.2;flex:1;min-width:0}
.vf-brand-name{font-weight:600;font-size:14px;letter-spacing:-.01em}
.vf-brand-sub{font-family:var(--mono);font-size:10px;color:var(--text-faint);letter-spacing:.02em}
.vf-net{font-family:var(--mono);font-size:9.5px;color:var(--ok);padding:3px 8px;letter-spacing:.03em;
  border:1px solid rgba(111,227,154,.15);border-radius:999px;display:flex;align-items:center;gap:5px;
  background:rgba(111,227,154,.04);text-transform:uppercase;font-weight:500}

.net-dot{width:5px;height:5px;border-radius:50%;background:var(--ok)}

/* ───── main ───── */
.vf-main{padding:16px;display:flex;flex-direction:column;gap:14px;flex:1}
@keyframes screenIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

/* screen transition */
.vf-screen{display:flex;flex-direction:column;gap:14px;animation:screenIn 220ms var(--ease) forwards}

/* ───── typography ───── */
.eyebrow{display:flex;align-items:center;gap:8px;font-family:var(--mono);font-size:11px;color:var(--text-faint)}
.eyebrow .dot{color:var(--accent)}.eyebrow .sec{color:var(--text-muted)}.eyebrow .rule{flex:1;height:1px;background:var(--border)}
.vf-h{margin:0;font-size:21px;font-weight:600;letter-spacing:-.02em;text-wrap:balance}
.lede{margin:0;font-size:13px;color:var(--text-muted);text-wrap:pretty}
.note{margin:0;font-size:11.5px;color:var(--text-faint);line-height:1.5}
.info{margin:0;font-size:12px;color:var(--text-muted)}
.err{margin:0;font-size:12px;color:var(--danger)}
.link{font-family:var(--mono);font-size:11.5px;color:var(--accent);text-decoration:none;border-bottom:1px solid transparent}
.link:hover{border-bottom-color:var(--accent)}

/* signature figure */
.figure-block{display:flex;align-items:baseline;gap:8px}
.figure{font-family:var(--mono);font-weight:500;font-size:clamp(34px,12vw,46px);letter-spacing:-.02em;line-height:1}
.ticker{font-family:var(--mono);font-size:14px;color:var(--text-faint)}

/* document rows */
.doc{border-top:1px solid var(--border)}
.row{display:flex;align-items:center;gap:10px;padding:11px 0;border-bottom:1px solid var(--border)}
.row-k{font-family:var(--mono);font-size:11px;color:var(--text-faint);min-width:88px}
.row-v{font-size:13px;color:var(--text);flex:1;min-width:0}
.addr{font-family:var(--mono);font-size:12px;word-break:break-all}

/* ───── fields ───── */
.field{display:flex;flex-direction:column;gap:6px}
.field .row-k{min-width:0}
.input{width:100%;padding:10px 12px;background:var(--bg-elev);color:var(--text);
  border:1px solid var(--border);border-radius:var(--r-md);font-size:13px;transition:border-color 160ms ease,box-shadow 160ms ease}
.input.mono{font-family:var(--mono);font-size:12px}
.input:focus{border-color:var(--border-accent);outline:none;box-shadow:0 0 0 3px var(--accent-soft)}
.input::placeholder{color:var(--text-faint)}
.vf :focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:var(--r-sm)}

/* amount-input */
.amount-row{display:flex;align-items:baseline;gap:10px;border-bottom:1px solid var(--border-strong);padding-bottom:8px}
.amount-row:focus-within{border-bottom-color:var(--border-accent)}
.amount{flex:1;min-width:0;background:none;border:none;color:var(--text);
  font-family:var(--mono);font-weight:500;font-size:clamp(30px,11vw,42px);letter-spacing:-.02em}
.amount::placeholder{color:var(--text-faint)}
.amount::-webkit-outer-spin-button,.amount::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
.amount{-moz-appearance:textfield}

/* ───── buttons (passkey) ───── */
.btn{font-family:var(--font);font-size:13px;font-weight:500;padding:11px 18px;border-radius:var(--r-md);
  border:1px solid transparent;cursor:pointer;transition:background-color 160ms ease,border-color 160ms ease,color 160ms ease,transform 160ms var(--ease);text-align:center}
.btn-primary{color:var(--accent-fg);border-color:transparent;background-color:var(--accent);
  background-image:linear-gradient(120deg,var(--accent) 0%,#e8ff6a 18%,#b8f07a 36%,#d4ff55 54%,#a8ee88 72%,#f0ff9c 86%,var(--accent) 100%);
  background-size:300% 300%;background-position:0% 50%;background-repeat:no-repeat;animation:btn-lava 6s ease infinite}
.btn-primary:hover:not(:disabled){animation:btn-lava 3s ease infinite}
.btn-primary:active:not(:disabled){transform:scale(.97)}
.btn-ghost{background:transparent;color:var(--text);border-color:var(--border-strong)}
.btn-ghost:hover:not(:disabled){background-color:var(--bg-elev);
  background-image:linear-gradient(120deg,var(--bg-elev) 0%,color-mix(in srgb,var(--accent) 22%,var(--bg-elev)) 30%,color-mix(in srgb,var(--ok) 16%,var(--bg-elev)) 55%,var(--bg-elev) 100%);
  background-size:300% 300%;background-repeat:no-repeat;animation:btn-lava 5s ease infinite}
.btn:disabled{opacity:.4;cursor:not-allowed}
.btn-primary:disabled,.vf-btn.primary:disabled{animation:none;background-image:none;background-color:var(--accent)}
.btn-row{display:flex;gap:8px;flex-wrap:wrap}
.btn-row .btn{flex:1}
.btn-row.col{flex-direction:column}
.copy{font-family:var(--mono);font-size:11px;color:var(--text-muted);background:transparent;
  border:1px solid var(--border);border-radius:var(--r-sm);padding:4px 8px;cursor:pointer;transition:color 150ms ease,border-color 150ms ease,background-color 150ms ease,transform 160ms var(--ease)}
.copy:hover{color:var(--text);border-color:var(--border-strong);background:rgba(236,235,225,0.03)}
.copy:active{transform:scale(.97)}

/* approve overlay */
.approve{display:flex;flex-direction:column;gap:12px;background:var(--bg-card);border:1px solid var(--border-strong);
  border-radius:var(--r-lg);padding:16px}
.approve-verdict{margin:0;font-size:12px}
.approve-verdict.ok{color:var(--ok)}.approve-verdict.bad{color:var(--danger)}

/* pending marker */
.pending{display:flex;align-items:center;gap:8px;font-family:var(--mono);font-size:12px;color:var(--text-muted)}
.marker{width:9px;height:9px;border-radius:50%;background:var(--accent)}
.blink{animation:blink 1.1s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.25}}
@keyframes btn-lava{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

/* ───── bottom nav — frosted glass ───── */
.vf-nav{display:flex;justify-content:space-around;padding:6px 8px 8px;
  background:var(--bg-base);
  border-top:1px solid var(--border)}
.vf-tab{display:flex;flex-direction:column;align-items:center;gap:3px;font-family:var(--font);
  font-size:9.5px;font-weight:500;text-transform:capitalize;color:var(--text-faint);
  padding:6px 8px;border:none;background:transparent;cursor:pointer;transition:color 160ms ease,transform 160ms var(--ease);position:relative;
  letter-spacing:.02em}
.vf-tab:hover{color:var(--text-muted)}
.vf-tab.active{color:var(--accent)}
.vf-tab-icon{width:20px;height:20px;display:flex;align-items:center;justify-content:center;transition:transform .2s var(--ease)}
.vf-tab.active .vf-tab-icon{transform:scale(1.1)}
.vf-tab.active::after{content:'';position:absolute;bottom:0;left:25%;right:25%;height:2px;
  background:var(--accent);border-radius:2px}

/* inline link button */
button.link{background:none;border:none;padding:0;cursor:pointer;font:inherit}

/* ════════════════════════════════════════════════════════════════════ */
/* Classic (seed / ed25519) wallet screens                            */
/* ════════════════════════════════════════════════════════════════════ */
.vf-screen{display:flex;flex-direction:column;gap:14px}
.vf-screen h2{margin:0;font-size:17px;font-weight:600;letter-spacing:-.01em;color:var(--text)}
.vf-screen > label{display:flex;flex-direction:column;gap:5px;font-family:var(--mono);font-size:10.5px;
  color:var(--text-faint);letter-spacing:.01em;text-transform:uppercase}
.vf-screen input,.vf-screen textarea{font-family:var(--font);font-size:13px;color:var(--text);
  background:var(--bg-elev);border:1px solid var(--border);border-radius:var(--r-md);padding:11px 12px;
  transition:border-color 160ms ease,box-shadow 160ms ease}
.vf-screen input:focus,.vf-screen textarea:focus{border-color:var(--border-accent);outline:none;
  box-shadow:0 0 0 3px var(--accent-soft)}
.vf-screen input[type=password]{font-family:var(--mono)}
.vf-screen input[type=number]{width:76px;font-family:var(--mono)}

/* buttons (classic) */
.vf-btn{font-family:var(--font);font-size:13px;font-weight:600;padding:12px 18px;border-radius:var(--r-md);
  border:1px solid var(--border-strong);background:var(--bg-elev);color:var(--text);cursor:pointer;
  transition:background-color 160ms ease,border-color 160ms ease,color 160ms ease,transform 160ms var(--ease);text-align:center;letter-spacing:-.01em}
.vf-btn:hover:not(:disabled){background:var(--bg-elev-2)}
.vf-btn:active:not(:disabled){transform:scale(.97)}
.vf-btn:disabled{opacity:.35;cursor:not-allowed}
.vf-btn.primary{color:var(--accent-fg);border-color:transparent;background-color:var(--accent);
  background-image:linear-gradient(120deg,var(--accent) 0%,#e8ff6a 18%,#b8f07a 36%,#d4ff55 54%,#a8ee88 72%,#f0ff9c 86%,var(--accent) 100%);
  background-size:300% 300%;background-position:0% 50%;background-repeat:no-repeat;animation:btn-lava 6s ease infinite}
.vf-btn.primary:hover:not(:disabled){animation:btn-lava 3s ease infinite}
.vf-btn.primary:active:not(:disabled){transform:scale(.97)}
.vf-btn.ghost{background:transparent;border-color:transparent;color:var(--text-muted)}
.vf-btn.ghost:hover:not(:disabled){color:var(--text);background-color:var(--bg-elev);
  background-image:linear-gradient(120deg,var(--bg-elev) 0%,color-mix(in srgb,var(--accent) 22%,var(--bg-elev)) 30%,color-mix(in srgb,var(--ok) 16%,var(--bg-elev)) 55%,var(--bg-elev) 100%);
  background-size:300% 300%;background-repeat:no-repeat;transform:none;box-shadow:none;animation:btn-lava 5s ease infinite}

/* feedback text */
.vf-hint{margin:0;font-size:11.5px;color:var(--text-faint)}
.vf-error{margin:0;font-size:12px;color:var(--danger)}
.vf-muted{color:var(--text-faint);font-family:var(--mono);font-size:11px}
.vf-warn{margin:0;font-family:var(--mono);font-size:11px;line-height:1.5;color:var(--warn);
  background:rgba(240,181,74,.06);border:1px solid rgba(240,181,74,.2);border-radius:var(--r-md);padding:10px 12px}

/* backup phrase grid + confirm */
.vf-phrase{display:grid;grid-template-columns:repeat(3,1fr);gap:8px 10px;padding:14px;
  background:var(--bg-card);border:1px solid var(--border-strong);border-radius:var(--r-lg)}
.vf-phrase.blurred{display:flex;justify-content:center;padding:24px 12px}
.vf-word{font-family:var(--mono);font-size:12px;display:flex;gap:4px;color:var(--text)}
.vf-word-idx{color:var(--text-faint)}.vf-word-text{color:var(--text)}
.vf-confirm{display:flex;flex-direction:column;gap:10px;padding-top:8px;border-top:1px solid var(--border)}

/* ───── home: balance card ───── */
.vf-balance-card{display:flex;flex-direction:column;gap:8px;padding:22px 20px;position:relative;overflow:hidden;
  background:var(--bg-card);border:1px solid var(--border-strong);border-radius:var(--r-xl)}
.vf-portfolio{font-family:var(--mono);font-weight:600;font-size:clamp(30px,10vw,40px);
  letter-spacing:-.03em;color:var(--text)}
.vf-address{font-family:var(--mono);font-size:11px;color:var(--text-faint)}
.vf-address-container{display:flex;align-items:center;gap:8px}
.vf-address-copy-btn{background:rgba(236,235,225,.04);border:1px solid var(--border);color:var(--text-faint);cursor:pointer;
  display:flex;align-items:center;gap:4px;padding:3px 8px;border-radius:999px;transition:color 150ms ease,border-color 150ms ease,background-color 150ms ease,transform 160ms var(--ease);font-family:var(--mono);font-size:10px}
.vf-address-copy-btn:hover{color:var(--accent);border-color:rgba(207,255,61,.2);background:var(--accent-soft)}
.vf-address-copy-btn:active{transform:scale(.97)}

.vf-fund{display:flex;flex-direction:column;gap:8px;padding:12px;border:1px dashed var(--border-strong);
  border-radius:var(--r-md);font-size:12px;color:var(--text-muted)}
.vf-actions{display:flex;gap:8px}
.vf-actions .vf-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;border-radius:var(--r-lg)}

/* ───── token list ───── */
.vf-tokens{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}
.vf-token-row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 10px;
  border-radius:var(--r-md);transition:background-color 160ms ease;cursor:default}
.vf-token-row:hover{background:rgba(236,235,225,.03)}
.vf-token-left{display:flex;align-items:center;gap:10px;flex:1;min-width:0}
.vf-token-icon{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;
  justify-content:center;font-family:var(--mono);font-weight:700;font-size:11px;color:#fff;
  flex-shrink:0;text-transform:uppercase;box-shadow:0 2px 8px rgba(0,0,0,.25)}
.vf-token-icon.xlm{background:linear-gradient(135deg, #5c6bc0 0%, #283593 100%);border:1px solid rgba(92,107,192,.25)}
.vf-token-icon.usdc{background:linear-gradient(135deg, #42a5f5 0%, #1565c0 100%);border:1px solid rgba(66,165,245,.25)}
.vf-token-icon.unknown{background:linear-gradient(135deg, #78909c 0%, #37474f 100%);border:1px solid rgba(120,144,156,.2)}
.vf-token-meta{display:flex;flex-direction:column;line-height:1.3;min-width:0}
.vf-token-code{font-family:var(--font);font-weight:600;font-size:13px;color:var(--text)}
.vf-token-name{font-size:11px;color:var(--text-muted)}
.vf-token-right{display:flex;flex-direction:column;align-items:flex-end;line-height:1.3;font-family:var(--mono)}
.vf-token-balance{font-weight:500;font-size:13px;color:var(--text)}
.vf-token-usd{font-size:11px;color:var(--text-faint)}

/* ───── send confirm card ───── */
.vf-confirm-card{display:flex;flex-direction:column;gap:12px;padding:16px;
  background:var(--bg-card);border:1px solid var(--border-strong);border-radius:var(--r-lg)}
.vf-confirm-card h3{margin:0 0 4px 0;font-size:13px;font-weight:600;color:var(--accent);
  display:flex;align-items:center;gap:6px;letter-spacing:-.01em}
.vf-confirm-card dl{margin:0;display:grid;grid-template-columns:auto 1fr;gap:6px 12px}
.vf-confirm-card dt{font-family:var(--mono);font-size:10.5px;color:var(--text-faint);text-transform:uppercase;letter-spacing:.02em}
.vf-confirm-card dd{margin:0;font-family:var(--mono);font-size:12px;color:var(--text);word-break:break-all}

/* ───── receive ───── */
.vf-qr{display:block;margin:0 auto;border-radius:var(--r-lg);background:#fff;padding:10px;
  border:1px solid var(--border-strong);transition:transform 160ms var(--ease)}
.vf-address-full{display:block;font-family:var(--mono);font-size:10.5px;word-break:break-all;
  color:var(--text-muted);background:var(--bg-elev);border:1px solid var(--border);
  border-radius:var(--r-md);padding:10px 12px;user-select:all;line-height:1.5}

/* ───── history ───── */
.vf-history{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2px}
.vf-history li{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px 10px;
  border-radius:var(--r-md);transition:background-color 160ms ease;cursor:default}
.vf-history li:hover{background:rgba(236,235,225,.03)}
.vf-history-row{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%}
.vf-history-left{display:flex;align-items:center;gap:10px;flex:1;min-width:0}
.vf-history-badge{width:32px;height:32px;border-radius:var(--r-md);display:flex;align-items:center;
  justify-content:center;font-size:14px;font-weight:600;flex-shrink:0}
.vf-history-badge.in{background:rgba(111,227,154,.08);color:var(--ok);border:1px solid rgba(111,227,154,.15)}
.vf-history-badge.out{background:rgba(236,235,225,.04);color:var(--text-muted);border:1px solid rgba(236,235,225,.06)}
.vf-history-meta{display:flex;flex-direction:column;line-height:1.3;min-width:0}
.vf-history-title{font-weight:500;font-size:13px;color:var(--text)}
.vf-history-address{font-family:var(--mono);font-size:10.5px;color:var(--text-faint)}
.vf-history-right{display:flex;flex-direction:column;align-items:flex-end;line-height:1.3;font-family:var(--mono)}
.vf-history-amount{font-weight:500;font-size:13px}
.vf-history-amount.in{color:var(--ok)}.vf-history-amount.out{color:var(--text)}
.vf-history-time{font-size:10px;color:var(--text-faint)}

/* unlock / settings / export */
.vf-unlock,.vf-settings,.vf-export{gap:16px}
.vf-settings label{flex-direction:row;align-items:center;justify-content:space-between;
  font-family:var(--font);font-size:13px;color:var(--text);text-transform:none}

/* screen-root tweaks */
.vf-create{gap:16px}
.vf-backup h2{color:var(--warn)}
.vf-import textarea{font-family:var(--mono);font-size:12px;resize:vertical}
.vf-home{gap:16px}
.vf-send label{gap:5px}
.vf-receive{align-items:center;text-align:center}
.vf-receive .vf-address-full{text-align:left}

@media (hover:hover) and (pointer:fine){
  .btn-primary:hover:not(:disabled),.btn-ghost:hover:not(:disabled),
  .vf-btn:hover:not(:disabled){transform:translateY(-1px)}
  .btn:active:not(:disabled),.vf-btn:active:not(:disabled){transform:scale(.97)}
  .vf-tab:hover .vf-tab-icon{transform:translateY(-1px)}
  .vf-qr:hover{transform:scale(1.02)}
}

@media (prefers-reduced-motion:reduce){
  .vf-screen,.blink{animation:none}
  .btn-primary,.btn-ghost:hover:not(:disabled),.vf-btn.primary,.vf-btn.ghost:hover:not(:disabled){animation:none;background-image:none}
  .btn,.copy,.vf-tab,.vf-tab-icon,.vf-btn,.vf-address-copy-btn,.vf-qr{transition:color 160ms ease,background-color 160ms ease,border-color 160ms ease,opacity 160ms ease}
  .btn:hover,.btn:active,.vf-btn:hover,.vf-btn:active,.vf-tab:hover .vf-tab-icon,.vf-tab.active .vf-tab-icon,.vf-qr:hover,.vf-address-copy-btn:active,.copy:active{transform:none}
  .btn:active:not(:disabled),.vf-btn:active:not(:disabled){opacity:.82}
}

@media (prefers-contrast:more){
  .vf-head,.vf-nav{border-color:var(--border-strong)}
}
`,w3=["home","send","deposit","signers","recovery","activity","agent"],eo=["home","send","receive","activity","settings"],_3={home:f.jsx("path",{d:"M3 10.5L10 4l7 6.5V17a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-6.5z"}),send:f.jsxs(f.Fragment,{children:[f.jsx("path",{d:"M17 3L3 10l5 2 2 5 7-14z"}),f.jsx("line",{x1:"17",y1:"3",x2:"8",y2:"12"})]}),receive:f.jsxs(f.Fragment,{children:[f.jsx("path",{d:"M4 16v1a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-1"}),f.jsx("polyline",{points:"7 10 10 13 13 10"}),f.jsx("line",{x1:"10",y1:"3",x2:"10",y2:"13"})]}),activity:f.jsx("polyline",{points:"3 14 7 10 11 13 17 6"}),settings:f.jsxs(f.Fragment,{children:[f.jsx("circle",{cx:"10",cy:"10",r:"3"}),f.jsx("path",{d:"M17.4 11.4a1.2 1.2 0 0 0 .24 1.32l.04.04a1.44 1.44 0 1 1-2.04 2.04l-.04-.04a1.2 1.2 0 0 0-1.32-.24 1.2 1.2 0 0 0-.72 1.08v.12a1.44 1.44 0 0 1-2.88 0v-.06a1.2 1.2 0 0 0-.78-1.08 1.2 1.2 0 0 0-1.32.24l-.04.04a1.44 1.44 0 1 1-2.04-2.04l.04-.04a1.2 1.2 0 0 0 .24-1.32 1.2 1.2 0 0 0-1.08-.72H5.28a1.44 1.44 0 0 1 0-2.88h.06a1.2 1.2 0 0 0 1.08-.78 1.2 1.2 0 0 0-.24-1.32L6.14 5.66a1.44 1.44 0 1 1 2.04-2.04l.04.04a1.2 1.2 0 0 0 1.32.24h.06A1.2 1.2 0 0 0 10.32 2.82V2.7a1.44 1.44 0 0 1 2.88 0v.06a1.2 1.2 0 0 0 .72 1.08 1.2 1.2 0 0 0 1.32-.24l.04-.04a1.44 1.44 0 1 1 2.04 2.04l-.04.04a1.2 1.2 0 0 0-.24 1.32v.06a1.2 1.2 0 0 0 1.08.72h.12a1.44 1.44 0 0 1 0 2.88h-.06a1.2 1.2 0 0 0-1.08.72z"})]})};function dr({sec:e,meta:t}){return f.jsxs("div",{className:"eyebrow",children:[f.jsx("span",{className:"dot",children:"·"}),f.jsx("span",{className:"sec",children:e}),f.jsx("span",{className:"rule"}),f.jsx("span",{children:t})]})}function k3({tabs:e=w3,onNav:t,active:r}){return f.jsx("nav",{className:"vf-nav",children:e.map(n=>f.jsxs("button",{className:"vf-tab"+(n===r?" active":""),"aria-current":n===r?"page":void 0,onClick:()=>t(n),children:[f.jsx("span",{className:"vf-tab-icon",children:f.jsx("svg",{width:"18",height:"18",viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round",children:_3[n]||f.jsx("circle",{cx:"10",cy:"10",r:"6"})})}),n]},n))})}function pt({children:e,nav:t,active:r,tabs:n,onNav:i,sub:o="passkey · secp256r1"}){return f.jsxs("div",{className:"vf",children:[f.jsx("style",{children:b3}),f.jsxs("header",{className:"vf-head",children:[f.jsx("div",{className:"vf-logo",children:f.jsx("img",{src:"./vibing_farmer.logo.svg",alt:"Vibing Farmer"})}),f.jsxs("div",{className:"vf-brand",children:[f.jsx("div",{className:"vf-brand-name",children:"VF Wallet"}),f.jsx("div",{className:"vf-brand-sub",children:o})]}),f.jsxs("span",{className:"vf-net",children:[f.jsx("span",{className:"net-dot"}),"testnet"]})]}),f.jsx("div",{className:"vf-main",children:e}),t&&f.jsx(k3,{tabs:n,onNav:i,active:r})]})}function S3(){const[e,t]=xe.useState("loading"),[r,n]=xe.useState(null),[i,o]=xe.useState(null),[a,s]=xe.useState(""),[u,d]=xe.useState(""),[_,m]=xe.useState({ready:!1,hasWallet:!1,publicKey:null,unlocked:!1,needsBackup:!1}),[E,B]=xe.useState(null),[R,N]=xe.useState(null),[P,p]=xe.useState(null),[v,x]=xe.useState(!1),[C,O]=xe.useState([]),[H,Q]=xe.useState(!1),[V,X]=xe.useState(""),[pe,De]=xe.useState(10),[$e,_e]=xe.useState({open:!1,pw:"",secret:null,error:""}),[He,nt]=xe.useState(""),[tt,I]=xe.useState(""),[A,D]=xe.useState(""),[J,le]=xe.useState(null),[de,Ne]=xe.useState(""),[Re,ge]=xe.useState(""),[T,h]=xe.useState(""),[b,F]=xe.useState(null);function K(){d(""),s("")}function S(W){K(),le(null),t(W)}function k(W){ly(W).then(ne=>o(ne)).catch(()=>o("-"))}async function U(W){X("");try{const ne=await v3(W);x(ne.unfunded),p(ne.portfolio)}catch(ne){X(String((ne==null?void 0:ne.message)||ne))}}xe.useEffect(()=>{p3(),vu().then(W=>{m({ready:!0,hasWallet:W.hasWallet,publicKey:W.publicKey,unlocked:W.unlocked,needsBackup:W.needsBackup}),localStorage.getItem("vf_wallet_type")!=="passkey"&&(W.hasWallet&&(W.needsBackup||!W.unlocked)?t("classic-unlock"):W.hasWallet?(t("classic-home"),U(W.publicKey)):t("classic-onboarding"))})},[]);function ie(W){if(X(""),N(null),_e({open:!1,pw:"",secret:null,error:""}),W==="activity"){t("classic-activity"),Xh(_.publicKey).then(O).catch(ne=>X(String((ne==null?void 0:ne.message)||ne)));return}t("classic-"+W)}xe.useEffect(()=>{var ne;if(localStorage.getItem("vf_wallet_type")==="passkey"){const ze=localStorage.getItem("vf_wallet_contract");ze?(n({contractId:ze}),t("home"),k(ze)):typeof chrome<"u"&&((ne=chrome.storage)!=null&&ne.local)?chrome.storage.local.get("vf_wallet_contract").then(Ze=>{const gt=Ze.vf_wallet_contract;gt?(n({contractId:gt}),t("home"),k(gt)):t("welcome")}):t("welcome")}},[]),xe.useEffect(()=>{var ne,ze,Ze,gt,Mi;(Ze=(ze=(ne=chrome.storage)==null?void 0:ne.session)==null?void 0:ze.get)==null||Ze.call(ze,"vf_last_result").then(nr=>{const Dr=nr==null?void 0:nr.vf_last_result;Dr&&Xe(Dr)});const W=nr=>{(nr==null?void 0:nr.type)==="SIGN_RESULT"&&Xe(nr)};return(Mi=(gt=chrome.runtime)==null?void 0:gt.onMessage)==null||Mi.addListener(W),()=>{var nr,Dr;return(Dr=(nr=chrome.runtime)==null?void 0:nr.onMessage)==null?void 0:Dr.removeListener(W)}},[]);function Xe(W){if(!W.ok){d(W.error||"Ceremony failed"),t("home");return}if(W.action==="deposit"){const ne=BigInt(W.sharesAfter??"0")-BigInt(W.sharesBefore??"0");s(`Minted ${ne} shares. tx: ${W.hash}`)}else W.action==="approve"&&s("Deposits enabled. You can deposit now.");F(W.hash||null),t("result")}async function Ce(){K(),t("creating");try{const W=await sy({appName:"VF Wallet",userName:"VF User"});localStorage.setItem("vf_wallet_type","passkey"),n(W),t("home"),k(W.contractId)}catch(W){d(W.message),t("welcome")}}async function Ke(){K();try{const W=await uy();localStorage.setItem("vf_wallet_type","passkey"),n(W),t("home"),k(W.contractId)}catch(W){const ne=/credential|could not determine/i.test(W.message||"");d(ne?'No wallet found on this device. Tap "Create new wallet · Face ID" to make one first.':W.message)}}async function Wt(){K();const W=parseFloat(tt);if(isNaN(W)||W<=0){d("Amount must be greater than 0");return}if(!He.includes("*")&&!/^[GC][A-Z2-7]{55}$/i.test(He)){d("Invalid Stellar destination address");return}try{await fy({contractId:r.contractId,to:He,amount:tt}),s("Built the unsigned transfer XDR. On-chain send isn't wired in this build. Deposit is the live on-chain path.")}catch(ze){d(ze.message)}}async function Nt(){K(),le(null);const W=parseFloat(A);if(isNaN(W)||W<=0){d("Amount must be greater than 0");return}try{const ne=await mu({vault:Dc,protocol:gu,amount:BigInt(Math.round(W*1e7))});le(ne)}catch(ne){d(ne.message)}}async function rr(){K(),s("Opening Enable-deposits ceremony…"),Zh("approve",{contractId:r.contractId}),t("signing-pending")}async function Rr(){K();const W=parseFloat(A);if(isNaN(W)||W<=0){d("Amount must be greater than 0");return}try{await cy({contractId:r.contractId,amount:BigInt(Math.round(W*1e7)),eligibility:ne=>mu({...ne,protocol:gu})}),Zh("deposit",{contractId:r.contractId,amount:A,protocol:gu}),s("Opening deposit ceremony. Approve with Face ID in the new tab…"),le(null),t("signing-pending")}catch(ne){/allowance|balance|insufficient/i.test(ne.message)?d('Deposits not enabled yet. Tap "Enable deposits" first.'):d(ne.message)}}async function cr(){if(K(),!/^[G][A-Z2-7]{55}$/i.test(de)){d("Invalid recovery G-address");return}try{await $m({accountId:r.contractId,recoveryG:de}),s("Recovery signer added (VF-custodied; testnet-grade)."),Ne("")}catch(W){d(W.message)}}async function Vt(){if(K(),!/^[G][A-Z2-7]{55}$/i.test(Re)){d("Invalid agent G-address");return}const W=parseFloat(T);if(isNaN(W)||W<=0){d("Spending cap must be greater than 0");return}try{await dy({agentAddress:Re,cap:T,vault:Dc,expiry:Math.floor(Date.now()/1e3)+86400*7}),s("Agent scope granted. Ceremony required on next deposit."),ge(""),h("")}catch(ne){d(ne.message)}}if(e==="classic-onboarding")return f.jsx(pt,{sub:"classic · onboarding",children:f.jsx(C6,{onGetStarted:()=>t("classic-create")})});if(e==="classic-create")return f.jsxs(pt,{sub:"classic · ed25519",children:[f.jsx(Hm,{busy:H,error:V,onGoImport:()=>{X(""),t("classic-import")},onCreate:async(W,ne)=>{Q(!0),X("");try{const ze=await u3(W,ne);B({mnemonic:ze.mnemonic,indices:ze.indices,publicKey:ze.publicKey}),t("classic-backup")}catch(ze){X(String((ze==null?void 0:ze.message)||ze))}finally{Q(!1)}}}),f.jsxs("p",{className:"vf-hint",children:["Prefer Face ID?"," ",f.jsx("button",{className:"link",onClick:()=>{localStorage.setItem("vf_wallet_type","passkey"),t("welcome")},children:"Use a passkey wallet instead"})]})]});if(e==="classic-backup")return f.jsx(pt,{sub:"classic · ed25519",children:f.jsx(Vm,{mnemonic:E.mnemonic,indices:E.indices,error:V,onConfirm:async()=>{X(""),await yu(E.publicKey),m(W=>({...W,hasWallet:!0,publicKey:E.publicKey,unlocked:!0,needsBackup:!1})),B(null),t("classic-home"),U(E.publicKey)},onSkip:async()=>{X(""),await yu(E.publicKey),m(W=>({...W,hasWallet:!0,publicKey:E.publicKey,unlocked:!0,needsBackup:!1})),B(null),t("classic-home"),U(E.publicKey)}})});if(e==="classic-import")return f.jsx(pt,{sub:"classic · ed25519",children:f.jsx(j6,{busy:H,error:V,onImport:async(W,ne,ze)=>{Q(!0),X("");try{const Ze=await c3(W,ne,ze);m({ready:!0,hasWallet:!0,publicKey:Ze.publicKey,unlocked:!0}),t("classic-home"),U(Ze.publicKey)}catch(Ze){X(String((Ze==null?void 0:Ze.message)||Ze))}finally{Q(!1)}}})});if(e==="classic-unlock")return f.jsx(pt,{sub:"classic · ed25519",children:f.jsx(B6,{publicKey:_.publicKey,busy:H,error:V,onUnlock:async W=>{Q(!0),X("");try{await d3(_.publicKey,W)}catch{X("Wrong password."),Q(!1);return}if(m(ne=>({...ne,unlocked:!0})),!_.needsBackup){t("classic-home"),U(_.publicKey),Q(!1);return}try{const ne=await f3(_.publicKey,W);B({mnemonic:ne,indices:xv(24,3),publicKey:_.publicKey}),t("classic-backup")}catch{await yu(_.publicKey),m(ze=>({...ze,needsBackup:!1})),t("classic-home"),U(_.publicKey),X("Backup phrase unavailable. Use Settings → Export secret as your wallet backup.")}finally{Q(!1)}}})});if(e==="classic-home")return f.jsxs(pt,{nav:!0,active:"home",tabs:eo,onNav:ie,sub:"classic · ed25519",children:[f.jsx(N6,{publicKey:_.publicKey,portfolio:P,unfunded:v,busy:H,onFund:async()=>{Q(!0),X("");try{await y3(_.publicKey),await U(_.publicKey)}catch(W){X(String((W==null?void 0:W.message)||W))}finally{Q(!1)}},onSend:()=>{N(null),X(""),t("classic-send")},onReceive:()=>t("classic-receive")}),V&&f.jsx("p",{className:"vf-error",children:V}),f.jsx(Pr,{scope:"global"})]});if(e==="classic-send")return f.jsxs(pt,{nav:!0,active:"send",tabs:eo,onNav:ie,sub:"classic · ed25519",children:[f.jsx(R6,{from:_.publicKey,preview:R,busy:H,error:V,onPreview:async W=>{N(null),Q(!0),X("");try{const ne=await g3(W);N(ne)}catch(ne){X(String((ne==null?void 0:ne.message)||ne))}finally{Q(!1)}},onConfirm:async W=>{Q(!0),X("");try{await m3(W),N(null),await U(_.publicKey);const ne=await Xh(_.publicKey);O(ne),t("classic-activity")}catch(ne){X(String((ne==null?void 0:ne.message)||ne)),N(null)}finally{Q(!1)}}}),V&&f.jsx("p",{className:"vf-error",children:V})]});if(e==="classic-receive")return f.jsx(pt,{nav:!0,active:"receive",tabs:eo,onNav:ie,sub:"classic · ed25519",children:f.jsx(T6,{publicKey:_.publicKey})});if(e==="classic-activity")return f.jsxs(pt,{nav:!0,active:"activity",tabs:eo,onNav:ie,sub:"classic · ed25519",children:[V&&f.jsx("p",{className:"vf-error",children:V}),f.jsx(L6,{items:C})]});if(e==="classic-settings")return f.jsxs(pt,{nav:!0,active:"settings",tabs:eo,onNav:ie,sub:"classic · ed25519",children:[f.jsx(M6,{autoLockMin:pe,onSetAutoLock:De,onLock:async()=>{await h3(),m(W=>({...W,unlocked:!1})),_e({open:!1,pw:"",secret:null,error:""}),t("classic-unlock")},onExport:()=>_e({open:!0,pw:"",secret:null,error:""}),onReset:async()=>{var W;await chrome.storage.local.clear(),await((W=chrome.storage.session)==null?void 0:W.clear()),window.location.reload()}}),f.jsx(Pr,{scope:"session-key"}),$e.open&&f.jsx("div",{className:"vf-screen vf-export",children:$e.secret?f.jsxs(f.Fragment,{children:[f.jsx("p",{className:"vf-warn",children:"This is your ONLY secret key. Anyone with it controls this wallet. Shown once — it will not be shown again."}),f.jsx("code",{className:"vf-address-full",children:$e.secret}),f.jsx("button",{className:"vf-btn primary",onClick:()=>_e({open:!1,pw:"",secret:null,error:""}),children:"Done — hide it"})]}):f.jsxs(f.Fragment,{children:[f.jsxs("label",{children:["Password",f.jsx("input",{type:"password",autoComplete:"current-password",value:$e.pw,onChange:W=>_e(ne=>({...ne,pw:W.target.value,error:""}))})]}),$e.error&&f.jsx("p",{className:"vf-error",children:$e.error}),f.jsxs("div",{className:"vf-actions",children:[f.jsx("button",{className:"vf-btn primary",disabled:!$e.pw,onClick:async()=>{try{const W=await x3(_.publicKey,$e.pw);_e(ne=>({...ne,secret:W,pw:"",error:""}))}catch{_e(W=>({...W,error:"Wrong password."}))}},children:"Reveal secret"}),f.jsx("button",{className:"vf-btn ghost",onClick:()=>_e({open:!1,pw:"",secret:null,error:""}),children:"Cancel"})]})]})}),f.jsx("p",{className:"vf-hint",children:f.jsx("button",{className:"link",onClick:()=>{_e({open:!1,pw:"",secret:null,error:""}),localStorage.setItem("vf_wallet_type","passkey"),t("welcome")},children:"Switch to passkey wallet"})})]});if(e==="welcome")return f.jsxs(pt,{children:[f.jsx(dr,{sec:"welcome",meta:"face id"}),f.jsx("h1",{className:"vf-h",children:"A passkey wallet on Stellar."}),f.jsx("p",{className:"lede",children:"No seed phrase. Your Face ID is the key: a secp256r1 signer on a Soroban smart account."}),u&&f.jsx("p",{className:"err",children:u}),f.jsxs("div",{className:"btn-row col",children:[f.jsx("button",{className:"btn btn-primary",onClick:Ce,children:"Create new wallet · Face ID"}),f.jsx("button",{className:"btn btn-ghost",onClick:Ke,children:"Connect / restore"})]}),f.jsxs("p",{className:"vf-hint",style:{textAlign:"center",marginTop:12},children:["Prefer seed phrase?"," ",f.jsx("button",{className:"link",onClick:()=>{localStorage.setItem("vf_wallet_type","classic"),t("classic-onboarding"),vu().then(W=>{W.hasWallet&&t(W.needsBackup||!W.unlocked?"classic-unlock":"classic-home")})},children:"Use a classic wallet instead"})]}),f.jsx(Pr,{scope:"global"})]});if(e==="creating")return f.jsxs(pt,{children:[f.jsx(dr,{sec:"creating",meta:"testnet"}),f.jsx("h1",{className:"vf-h",children:"Setting up your wallet…"}),f.jsx("p",{className:"lede",children:"Creating the passkey and Friendbot-funding on Stellar testnet. Approve Face ID if prompted."}),f.jsxs("div",{className:"pending",children:[f.jsx("span",{className:"marker blink"})," working…"]})]});if(e==="signing-pending")return f.jsxs(pt,{children:[f.jsx(dr,{sec:"ceremony",meta:"face id"}),f.jsx("h1",{className:"vf-h",children:"Approve in the ceremony tab"}),f.jsxs("div",{className:"pending",children:[f.jsx("span",{className:"marker blink"})," ",a]}),f.jsx("p",{className:"note",children:"Face ID opens in a new tab. This popup may close, so reopen it to see the result."}),f.jsx("button",{className:"btn btn-ghost",onClick:()=>S("home"),children:"Back to home"})]});if(e==="result")return f.jsxs(pt,{nav:!0,active:null,onNav:S,children:[f.jsx(dr,{sec:"result",meta:"testnet"}),f.jsx("h1",{className:"vf-h",children:"Done."}),f.jsx("p",{"data-testid":"result-status",className:"info",children:a}),b&&f.jsx("a",{className:"link",href:`https://stellar.expert/explorer/testnet/tx/${b}`,target:"_blank",rel:"noreferrer",children:"View on Stellar Expert →"}),f.jsx("button",{className:"btn btn-primary",onClick:()=>t("home"),children:"Done"})]});if(e==="home"){let W="-",ne=null;i===null?ne="reading balance…":i==="-"?ne="balance unavailable":W=parseFloat(ay(i).toFixed(7)).toLocaleString("en-US",{maximumFractionDigits:7});const ze=r!=null&&r.contractId?`${r.contractId.slice(0,6)}…${r.contractId.slice(-4)}`:"-";return f.jsxs(pt,{nav:!0,active:"home",onNav:S,children:[f.jsx(dr,{sec:"balance",meta:"usdc · testnet"}),f.jsxs("div",{className:"figure-block",children:[f.jsx("span",{className:"figure tnum",children:W}),f.jsx("span",{className:"ticker",children:"USDC"})]}),ne&&f.jsx("p",{className:"note",children:ne}),f.jsx("div",{className:"doc",children:f.jsxs("div",{className:"row",children:[f.jsx("span",{className:"row-k",children:"address"}),f.jsx("span",{className:"row-v addr",children:ze}),f.jsx("button",{className:"copy","aria-label":"Copy address",onClick:()=>{var Ze;return(Ze=navigator.clipboard)==null?void 0:Ze.writeText((r==null?void 0:r.contractId)??"")},children:"copy"})]})}),u&&f.jsx("p",{className:"err",children:u}),a&&f.jsx("p",{className:"info",children:a}),f.jsx("p",{className:"vf-hint",style:{textAlign:"center",marginTop:12},children:f.jsx("button",{className:"link",onClick:async()=>{var Ze;localStorage.removeItem("vf_wallet_contract"),localStorage.removeItem("vf_wallet_credential"),localStorage.setItem("vf_wallet_type","classic"),typeof chrome<"u"&&((Ze=chrome.storage)!=null&&Ze.local)&&await chrome.storage.local.remove(["vf_wallet_contract","vf_wallet_credential"]),n(null),t("classic-onboarding"),vu().then(gt=>{gt.hasWallet&&t(gt.needsBackup||!gt.unlocked?"classic-unlock":"classic-home")})},children:"Switch to classic wallet / Reset"})}),f.jsx(Pr,{scope:"global"})]})}return e==="send"?f.jsxs(pt,{nav:!0,active:"send",onNav:S,children:[f.jsx(dr,{sec:"send",meta:"usdc"}),f.jsx("h1",{className:"vf-h",children:"Send USDC"}),f.jsxs("div",{className:"field",children:[f.jsx("label",{className:"row-k",children:"to"}),f.jsx("input",{className:"input mono",placeholder:"G-address or C-address",value:He,onChange:W=>nt(W.target.value)})]}),f.jsxs("div",{className:"amount-row",children:[f.jsx("input",{className:"amount tnum",type:"number",placeholder:"0","aria-label":"Amount to send, in USDC",value:tt,onChange:W=>I(W.target.value)}),f.jsx("span",{className:"ticker",children:"USDC"})]}),u&&f.jsx("p",{className:"err",children:u}),f.jsx("button",{className:"btn btn-primary",onClick:Wt,disabled:!He||!tt,children:"Approve with Face ID"}),f.jsx("p",{className:"note",children:"Builds unsigned XDR locally. On-chain send isn't wired in this build. Deposit is the live on-chain path."})]}):e==="deposit"?f.jsxs(pt,{nav:!0,active:"deposit",onNav:S,children:[f.jsx(dr,{sec:"deposit",meta:"vault · blend usdc"}),f.jsx("h1",{className:"vf-h",children:"Deposit to vault"}),f.jsxs("div",{className:"amount-row",children:[f.jsx("input",{className:"amount tnum",type:"number",placeholder:"0","aria-label":"Amount to deposit, in USDC",value:A,onChange:W=>{D(W.target.value),le(null)}}),f.jsx("span",{className:"ticker",children:"USDC"})]}),u&&f.jsx("p",{className:"err",children:u}),f.jsxs("div",{className:"btn-row",children:[!J&&f.jsx("button",{className:"btn btn-ghost",onClick:Nt,disabled:!A,children:"Check eligibility"}),f.jsx("button",{className:"btn btn-ghost",onClick:rr,children:"Enable deposits"})]}),J&&f.jsx(mv,{verdict:J,simulate:null,onApprove:Rr,onReject:()=>le(null)}),f.jsx(Pr,{scope:"deposit"})]}):e==="signers"?f.jsxs(pt,{nav:!0,active:"signers",onNav:S,children:[f.jsx(dr,{sec:"signers",meta:"multi-sig"}),f.jsx("h1",{className:"vf-h",children:"Signers"}),f.jsxs("div",{className:"doc",children:[f.jsxs("div",{className:"row",children:[f.jsx("span",{className:"row-k",children:"primary"}),f.jsx("span",{className:"row-v",children:"Passkey · Face ID"})]}),f.jsxs("div",{className:"row",children:[f.jsx("span",{className:"row-k",children:"curve"}),f.jsx("span",{className:"row-v mono",children:"secp256r1 · on-device"})]})]}),f.jsx("p",{className:"note",children:"Additional signers are managed on the recovery and agent screens."}),u&&f.jsx("p",{className:"err",children:u}),a&&f.jsx("p",{className:"info",children:a})]}):e==="recovery"?f.jsxs(pt,{nav:!0,active:"recovery",onNav:S,children:[f.jsx(dr,{sec:"recovery",meta:"vf-custodied"}),f.jsx("h1",{className:"vf-h",children:"Recovery signer"}),f.jsxs("div",{className:"field",children:[f.jsx("label",{className:"row-k",children:"recovery address"}),f.jsx("input",{className:"input mono",placeholder:"Recovery G-address",value:de,onChange:W=>Ne(W.target.value)})]}),u&&f.jsx("p",{className:"err",children:u}),a&&f.jsx("p",{className:"info",children:a}),f.jsx("button",{className:"btn btn-primary",onClick:cr,disabled:!de,children:"Add recovery signer"}),f.jsx(Pr,{scope:"recovery"})]}):e==="activity"?f.jsxs(pt,{nav:!0,active:"activity",onNav:S,children:[f.jsx(dr,{sec:"activity",meta:"stellar expert"}),f.jsx("h1",{className:"vf-h",children:"Activity"}),f.jsx("p",{className:"lede",children:"On-chain history lives on Stellar Expert (testnet)."}),(r==null?void 0:r.contractId)&&f.jsx("a",{className:"link",href:`https://stellar.expert/explorer/testnet/account/${r.contractId}`,target:"_blank",rel:"noreferrer",children:"View on Stellar Expert →"})]}):e==="agent"?f.jsxs(pt,{nav:!0,active:"agent",onNav:S,children:[f.jsx(dr,{sec:"agent",meta:"scoped · 7d expiry"}),f.jsx("h1",{className:"vf-h",children:"Agent signer"}),f.jsxs("div",{className:"field",children:[f.jsx("label",{className:"row-k",children:"agent address"}),f.jsx("input",{className:"input mono",placeholder:"Agent G-address",value:Re,onChange:W=>ge(W.target.value)})]}),f.jsxs("div",{className:"amount-row",children:[f.jsx("input",{className:"amount tnum",type:"number",placeholder:"0","aria-label":"Agent spending cap, in USDC",value:T,onChange:W=>h(W.target.value)}),f.jsx("span",{className:"ticker",children:"USDC cap"})]}),u&&f.jsx("p",{className:"err",children:u}),a&&f.jsx("p",{className:"info",children:a}),f.jsx("button",{className:"btn btn-primary",onClick:Vt,disabled:!Re||!T,children:"Grant agent scope · ceremony"}),f.jsx("p",{className:"note",children:"Scope: 7-day expiry, capped at the entered amount, vault-restricted."}),f.jsx(Pr,{scope:"agent"})]}):f.jsxs(pt,{children:[f.jsx(dr,{sec:"loading",meta:""}),f.jsxs("div",{className:"pending",children:[f.jsx("span",{className:"marker blink"})," loading…"]})]})}gv(document.getElementById("root")).render(f.jsx(S3,{}));
